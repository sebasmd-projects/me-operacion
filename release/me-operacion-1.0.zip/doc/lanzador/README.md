# Base compartida y lanzador `dame click.bat` — Documentación técnica

> **Versión: v2.3** · Convención de versionado: *fix* `+0.1` · *feature* `+1.0`.

Las cuatro herramientas de operación son archivos HTML independientes, pero **comparten una base**: el mismo marco visual, la misma sesión y el mismo acceso al CM. Esa base son tres archivos (`me-ui.css`, `me-ui.js`, `me-api.js`) más el lanzador `dame click.bat`, que deja la sesión lista antes de que aparezca la primera página.

> Cambiar una URL del CM, una cabecera o el manejo del token se hace **una vez** en `me-api.js`. Cambiar un color, el alto de las tablas o el formato de exportación se hace **una vez** en `me-ui`.

---

## 1. Objetivos

- Que las cuatro herramientas se vean y se usen igual, sin copiar código entre ellas.
- Tener **un solo lugar** para los endpoints, las credenciales y la renovación del token.
- Que el analista abra el lanzador y encuentre la sesión iniciada, sin escribir nada.
- Que cada `.html` sea **solo marcado**: la lógica vive en archivos aparte y se puede editar sin abrir el HTML.

---

## 2. Arquitectura y archivos

```txt
assets\
  me-ui.css                 sistema de diseño: color, shell, pasos, tablas, log
  me-ui.js                  shell (lateral/cabecera/pie), sesión compartida,
                            registro, defaults y alto de DataTables,
                            lectura de líneas/Excel y exportación
  me-api.js                 endpoints, cabeceras, objeto auth y llamadas al CM
  logica-<herramienta>.js    reglas de negocio propias de cada herramienta
  me-<herramienta>-puente.js enganche entre esa lógica y el shell
```

Orden de carga, idéntico en las cuatro páginas:

```html
<script src="assets/me-ui.js"></script>
<script> MEUI.init({ app, version, titulo, sesiones, instrucciones }); </script>
<script src="assets/me-api.js"></script>
<script src="assets/logica-<herramienta>.js"></script>
<script src="assets/me-<herramienta>-puente.js"></script>
```

El orden importa: `MEUI.init()` va **antes** de la lógica porque mueve el contenido dentro del shell y porque consume los parámetros que deja el lanzador en la URL.

---

## 3. Herramientas de terceros

| Librería | Versión | Para qué se usa |
|---|---|---|
| **Bootstrap** | 5.3.3 | Rejilla, formularios, dropdowns, pestañas, modales, badges. |
| **Bootstrap Icons** | 1.11.3 | Iconos del menú, botones y estados. |
| **DataTables** | 2.3.2 (+ integración `bootstrap5`) | Tablas con paginado, búsqueda y orden en pantalla. |
| **jQuery** | 3.7.1 | Dependencia de DataTables. |
| **SheetJS (xlsx)** | 0.18.5 | Leer `.xlsx`/`.csv` y exportar a `.xlsx`. |
| **Tom Select** | 2.4.3 | Selects con búsqueda y etiquetas editables. |
| **marked** | última | Renderiza los README en el inicio. |
| **Archivo / IBM Plex Mono** | — | Tipografías (Google Fonts). |

| Servicio | Para qué se usa |
|---|---|
| **Keycloak** (`optiva`) | Autenticación OpenID Connect del CM: *direct grant* y *refresh token*. |
| **API Gateway OBP** | Todas las consultas al CM de las cuatro herramientas. |
| **SIME / SIME Web** | Solo lo usa el reporte de prepagadas (token `prf` por NTLM). |

CDNs usados: jsdelivr, datatables.net, code.jquery.com, cdnjs. Todos externos (ver §9).

---

## 4. Endpoints

Todos los que centraliza `me-api.js`:

| Método | Endpoint | Para qué |
|---|---|---|
| `POST` | `{kcBase}/auth/realms/{realm}/protocol/openid-connect/token` | Login (`grant_type=password`) y renovación (`grant_type=refresh_token`). |
| `GET` | `{apiBase}{ruta}` vía `MEAPI.getJson(ruta, params)` | Cualquier consulta autenticada al CM. |
| `*` | `{apiBase}{ruta}` vía `MEAPI.api(ruta, {method, body, headers})` | Llamadas con cuerpo: `PATCH`, `POST`, `PUT`. |

Configuración fija:

```js
MEAPI.CONFIG = {
  apiBase : "http://obp-apigw.exito-prod.movil-exito.internal",
  kcBase  : "http://keycloak.exito-prod.movil-exito.internal",
  realm   : "optiva",
  clientId: "optiva",
  locale  : "es",            // cada herramienta lo ajusta con MEAPI.configurar()
  spid    : "410",
  tenant  : "optiva",
  camposUsuario: ["#cfgUser", "#user", "#username"],   // de dónde lee las credenciales
  camposClave  : ["#cfgPass", "#pass", "#password"],
  margenRenovacion: 30       // segundos antes del vencimiento
};
```

Cabeceras que agrega `MEAPI.cabeceras()` a cada llamada: `Accept`, `Cache-Control: private, no-store, max-age=0`, `Pragma: no-cache`, `Expires: 0`, `locale`, `spid`, `tenant` y `Authorization: Bearer …`.

---

## 5. Funcionalidad

### Shell (lo que ve el analista en todas las herramientas)

- **Menú lateral** con las páginas registradas en `APPS`, contraíble a solo iconos (la flecha cambia de sentido) y recordado entre archivos. Bajo 992 px se convierte en menú deslizante con botón hamburguesa. Las rutas de `APPS` están escritas desde `herramientas/`; `rutaNav()` las traduce cuando quien pinta el menú es la portada, que vive en la raíz.
- **Cabecera**: título, descripción y un **chip por sesión** (SIME y/o CM) con semáforo: verde activa, naranja por expirar, rojo expirada, gris sin sesión. Muestra el usuario y los segundos que faltan. Al hacer clic se abre un menú con *iniciar sesión*, *cerrar* y *olvidar credenciales*.
- **Pie** con el título, la versión, la fecha de apertura (la que pasa el lanzador) y el tiempo que lleva abierta.
- **Pasos plegables** (`data-me-paso`): se abren solos según haya sesión o no (`sin-sesion` / `con-sesion` / `siempre` / `nunca`), y muestran un resumen gris a la derecha.
- **Registro** con las instrucciones de uso impresas al abrir, más cada evento con hora y color. Captura además cualquier error de JavaScript de la página, así que no hace falta abrir la consola.
- **Avisos flotantes** y **spinner dentro del botón** para toda acción que tarde.

### Dar de alta una herramienta nueva

Una herramienta se registra en **dos sitios distintos**, y hay que tocar los dos
o queda a medias: si falta el primero no aparece en el menú lateral y **no se
puede llegar a ella navegando**; si falta el segundo no sale en la portada.

| Dónde | Qué se agrega | Para qué |
| --- | --- | --- |
| `assets/me-ui.js` → `APPS` | `{ id, titulo, icono, url }` dentro del grupo que corresponda | El **menú lateral**, que es el mismo en todas las páginas |
| `assets/logica-inicio.js` → `PROYECTOS` | La tarjeta con sus entregables y rutas | La **portada**: descarga de código y documentación |

El `id` debe ser el mismo en los dos sitios y coincidir con el `app` que la
página pasa a `MEUI.init()`; es lo que marca el elemento activo del menú.

El lanzador `dame click.bat` no hace falta tocarlo: abre solo dos páginas de
entrada y desde ahí se navega con el menú.

### Sesión compartida

Cada página maneja su propio token en memoria (no se puede compartir un objeto JS entre archivos abiertos por separado), pero **el estado y las credenciales sí se comparten** por `localStorage` + `BroadcastChannel`: al iniciar sesión en una pestaña, las demás lo reflejan y pueden autenticarse solas.

Si el navegador bloquea el almacenamiento (Edge lo hace en `file://` con la prevención de seguimiento), se usa un **respaldo en memoria**: la herramienta funciona igual y solo se pierde el compartir entre pestañas. Queda avisado en el registro.

### Tablas

`MEUI.tabla()` aplica los mismos defaults: idioma en español, `scrollX`, orden y búsqueda, y un `lengthMenu` con valores pequeños para revisar línea por línea. `MEUI.registrarTabla()` calcula **al píxel** el alto del cuerpo para que filtros, controles, filas y paginación quepan en pantalla sin scroll de página, y lo rehace al cambiar el tamaño de la ventana, al plegar un paso o al contraer el menú. `MEUI.mostrarSiHayDatos()` esconde la tabla mientras no haya datos y la muestra al llegar el primer resultado.

### Entrada y salida de datos

- `MEUI.parseLineas(texto)` acepta espacio, tabulación, salto de línea, `,`, `;` y `|`, y limpia `+57`, guiones y paréntesis.
- `MEUI.leerLibro(file)` / `filasDeHoja` / `detectarColumna` leen Excel y CSV con SheetJS.
- `MEUI.exportarCSV / exportarXLSX / exportarJSON` con separador **`;` por defecto**, cambiable desde cualquier control `data-me-sep` y compartido entre herramientas.

---

## 6. Estructura y lógica general

```txt
dame click.bat
   ├─ credenciales locales (DPAPI)  ──> usuario/clave del CM y, si aplica, de SIME
   ├─ login NTLM a SIME/Web         ──> token prf
   ├─ login Keycloak                ──> valida usuario/clave del CM
   └─ abre Edge con:  ?prf=…&abierto=…#cm_user=…&cm_pass=…
                                  │
                                  v
   me-ui.js  ── init() ──> lee la URL, la limpia, monta el shell,
                           comparte credenciales y estado de sesión
                                  │
                                  v
   me-api.js ── auth ────> token del CM, renovación y re-auth en 401
                                  │
                                  v
   logica-<herramienta>.js ─────> reglas de negocio (consultas propias)
                                  │
                                  v
   me-<herramienta>-puente.js ──> conecta ambas: chips, pasos, tablas,
                                  spinners y exportaciones
```

---

## 7. Flujo del lanzador

1. **Verifica los archivos** en su carpeta. Si falta alguno, lo dice y sigue con los que haya.
2. **Lee las credenciales** del archivo local cifrado; si no existen, las pide por consola.
3. **SIME**: pide el token `prf` a `SIME/Web` con la sesión de Windows (NTLM). Si falla, ofrece reintentar, escribir usuario y clave de dominio, o saltarse el reporte de prepagadas y abrir el resto.
4. **CM**: valida usuario y clave contra Keycloak. Si Keycloak los rechaza, **borra** esas credenciales guardadas para que la próxima ejecución las vuelva a pedir.
5. **Prepara Edge**: borra el perfil temporal de la ejecución anterior.
6. **Abre la página** —una sola pestaña, ventana maximizada (`--start-maximized`)— con el `prf` en la query y las credenciales del CM en el fragmento.

> El cierre masivo de casos **ya no se abre solo**: se pide aparte con `/solo-casos`. La razón es que abrir dos pestañas dejaba una herramienta activa que nadie había pedido.

Cada paso se imprime en pantalla (`[1/6]`…`[6/6]`) y cualquier error queda visible con una pausa antes de cerrar.

### Credenciales

Se guardan en `%APPDATA%\reporte_prepagadas\` con `Export-Clixml` de un `PSCredential`: la contraseña queda cifrada con **DPAPI**, así que el archivo solo lo puede descifrar el mismo usuario de Windows en el mismo equipo. Son dos: `credenciales_cm.xml` (siempre) y `credenciales_sime.xml` (solo si se pide login explícito de SIME).

Todo se pide **por consola**: no se usa `Get-Credential`, porque su cuadro de diálogo puede quedar detrás de la ventana o estar bloqueado por política del equipo, y en ese caso el lanzador se queda mudo. La contraseña se escribe con `Read-Host -AsSecureString`.

### Cómo llegan los datos a la página

El `prf` viaja en la **query** (igual que el redirect de SIME) y las credenciales del CM en el **fragmento** (`#cm_user=…&cm_pass=…`), que no se envía en ninguna petición. Al cargar, `MEUI.init()` los lee, los comparte con las demás herramientas y **limpia la URL** con `history.replaceState`; si el navegador lo bloquea (pasa en `file://`), al menos borra el fragmento.

### Auto-actualización (probada y revertida — ver por qué)

`dame click.bat` tuvo, en la versión 2.2, un paso 0 que revisaba `https://sebasmd.com/me/operacion/version.json`, descargaba un `.zip` si había versión nueva, lo aplicaba con `robocopy` y se relanzaba solo. **Se quitó**: un `.bat` que descarga un paquete de internet, se sobrescribe a sí mismo y se relanza es exactamente el patrón que un antivirus corporativo (Defender/EDR) marca como dropper/self-updating malware, y empezó a hacerlo saltar en los equipos de los analistas — inutilizando el lanzador para todos, un problema peor que el que resolvía.

Los archivos de esa infraestructura **siguen en el repo pero no los usa nada**, por si algún día se retoma (por ejemplo firmando el script o consiguiendo una excepción de antivirus con IT): `empaquetar-release.ps1` / `.bat`, el archivo `VERSION` en la raíz, y el `version.json` + `.zip` que puedan seguir publicados en `sebasmd.com` (hay que bajarlos de ahí para que ningún `.bat` viejo en circulación intente aplicarlos). Mientras tanto, la distribución vuelve a ser la de antes: desde el **inicio** (`index.html`) → botón **Descargar todo** → subir el `.zip` a cPanel → extraerlo → cada analista descarga y reemplaza su copia a mano.

### Parámetros

| Comando | Qué hace |
|---|---|
| `dame click.bat` | Flujo normal: **una sola pestaña** con el reporte de líneas prepagadas, en una ventana **maximizada**. |
| `dame click.bat /solo-reporte` | Lo mismo que sin parámetros (explícito). |
| `dame click.bat /solo-casos` | Solo el cierre masivo de casos. |
| `dame click.bat /sinsesion` | Pide usuario y clave de Windows para SIME en vez de usar la sesión activa. |
| `dame click.bat /reset` | Borra todas las credenciales guardadas. |
| `dame click.bat /resetsime` · `/resetcm` | Borra solo las de SIME o solo las del CM. |
| `dame click.bat /debug` | Muestra la excepción completa y el stack trace. |

> El `.bat` es un archivo mixto: `cmd` ejecuta las primeras líneas y todo lo que va después del marcador `#POWERSHELL#` es el script de PowerShell que se ejecuta sobre sí mismo. No genera archivos temporales.

---

## 8. API de los módulos compartidos

```js
// --- me-ui.js ---
MEUI.init({ app, version, titulo, descripcion, sesiones, instrucciones, apps })
MEUI.log(mensaje, "ok|err|warn|info") / MEUI.limpiarLog() / MEUI.toast(msg, nivel)
MEUI.ocupado(btn, texto) / MEUI.libre(btn) / MEUI.conSpinner(btn, texto, fn)
MEUI.autoSpinner("#btn", texto) / MEUI.enterEjecuta(input, boton)
MEUI.tabla(sel, opciones) / registrarTabla(dt) / ajustarTablas()
MEUI.prepararTabla(sel) / mostrarSiHayDatos(sel, {vacio, tabla})
MEUI.parseLineas(txt) / leerLibro(file) / filasDeHoja(wb, hoja) / detectarColumna(cols)
MEUI.exportarCSV(cab, filas, base) / exportarXLSX(cab, filas, base, hoja, {numFmt})
MEUI.exportarJSON(datos, base) / MEUI.descargar(blob, nombre)
MEUI.sesion.set|caida|cerrar|estado("cm"|"sime") / MEUI.cred.get|set|borrar(...)
MEUI.abrirPaso(n, bool) / MEUI.resumenPaso(n, texto)

// --- me-api.js ---
MEAPI.CONFIG / MEAPI.configurar({ locale: "en" })
MEAPI.auth.ensure() / reauth(version) / leerCampos() / salir()
MEAPI.getJson(ruta, params)
MEAPI.api(ruta, { method, body, headers, params })
MEAPI.cabeceras(extra)
```

Eventos que emite el shell y atiende cada puente: `me:sesion-iniciar`, `me:sesion-renovar` (a 15 s del vencimiento) y `me:sesion-cerrar`, todos con `detail.clave`.

---

## 9. Riesgos

- **Transporte**: los endpoints del CM y de Keycloak son **HTTP plano**. Usuario y clave viajan en el direct grant y el token queda en memoria del navegador.
- **Credenciales compartidas**: para que la sesión se sienta única entre archivos, quedan en `localStorage` ofuscadas (no cifradas) mientras dure la jornada. Es el mismo nivel de exposición que el `#cm_pass` de la URL. «Olvidar credenciales» las borra al instante.
- **`--disable-web-security`**: la ventana de Edge que abre el lanzador no tiene aislamiento de origen. No debe usarse para navegar a nada más.
- **Dependencia de CDNs externos**: si un CDN está bloqueado o caído, las herramientas no cargan. Mezclan red interna con CDN público.
- **Almacenamiento bloqueado**: con la prevención de seguimiento de Edge activa, la sesión no se comparte entre pestañas (funciona igual, pero hay que iniciar sesión en cada una).
- **Dependencia de la sesión de Windows**: obtener el `prf` automáticamente requiere sesión NTLM válida y, normalmente, abrir desde el `.bat`.
- **Un cambio en la base afecta a las cuatro**: es la contraparte de no duplicar código. Conviene probar las cuatro páginas después de tocar `me-ui` o `me-api`.

---

## 10. Historial de cambios

| Versión | Cambios |
|---|---|
| **2.3** | Se **revierte** la auto-actualización de la 2.2: estaba haciendo saltar el antivirus en los equipos de los analistas (patrón dropper: descarga un `.zip`, se sobrescribe, se relanza). `dame click.bat` vuelve a ser solo el flujo de sesión + apertura de Edge; la distribución vuelve a ser manual (Descargar todo → cPanel → cada equipo). La infraestructura (`empaquetar-release.*`, `VERSION`) queda en el repo sin usarse, por si se retoma más adelante con firma de código o una excepción de antivirus. |
| 2.2 | Auto-actualización: `dame click.bat` revisaba `https://sebasmd.com/me/operacion/version.json` antes de todo lo demás y, si había una versión nueva, la descargaba, la aplicaba y se relanzaba solo (flag `/sinupdate` para omitirlo). Versión tipo `1.0`/`1.1` (comparada como `[version]`, no como número entero). Se agregaron `empaquetar-release.ps1` + `empaquetar-release.bat` (este último para no chocar con la `ExecutionPolicy` del equipo) para armar el `.zip` + `version.json` que había que subir, y el archivo `VERSION` en la raíz del proyecto. **Revertida en 2.3** — ver arriba. |
| 2.1 | El lanzador abre **una sola pestaña** (el reporte de líneas prepagadas) y la ventana de Edge sale **maximizada**. El cierre masivo de casos deja de abrirse por defecto: se pide con `/solo-casos`. |
| 2.0 | Se extraen `me-ui.css`, `me-ui.js` y `me-api.js` como base común de las cuatro herramientas: shell, sesión compartida, registro, tablas, importación y exportación, más los endpoints y el `auth` que antes estaban copiados en cada archivo. Los `.html` quedan solo con marcado. El lanzador pasa la marca de apertura (`abierto=`) para el pie. |
| 1.0 | `dame click.bat`: credenciales en archivo local cifrado con DPAPI, login NTLM a SIME, validación del CM contra Keycloak y apertura de Edge con la sesión lista. |