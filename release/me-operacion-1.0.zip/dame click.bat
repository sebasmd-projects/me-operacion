@echo off
REM ============================================================
REM  Abrir herramientas SIME / CM-BSS
REM  Coloca este .bat junto a index.html (la carpeta que contiene
REM  'herramientas', donde estan reporte_prepagadas.html y
REM  reporte_casos_masivos.html).
REM
REM  Uso:
REM    dame click.bat                -> abre UNA pestana: el reporte de lineas
REM                                prepagadas, en una ventana maximizada
REM    dame click.bat /solo-reporte  -> igual que sin parametros (explicito)
REM    dame click.bat /solo-casos    -> solo el cierre masivo de casos
REM    dame click.bat /sinsesion     -> pide usuario/clave de Windows para SIME
REM                                en vez de usar la sesion activa
REM    dame click.bat /reset         -> borra TODAS las credenciales guardadas
REM    dame click.bat /resetsime     -> borra solo las credenciales de SIME
REM    dame click.bat /resetcm       -> borra solo las credenciales del CM
REM    dame click.bat /debug         -> muestra el detalle tecnico de los errores
REM
REM  Si SIME rechaza el login, el lanzador NO se cae: ofrece reintentar
REM  con otras credenciales, con la sesion de Windows, o saltar el reporte
REM  y abrir solo el cierre masivo (que solo necesita el CM).
REM
REM  Las credenciales quedan en un ARCHIVO LOCAL cifrado con DPAPI
REM  (%APPDATA%\reporte_prepagadas\). No usa el Credential Manager.
REM  Todo se pide por CONSOLA: no abre ventanas de Windows.
REM
REM  IMPORTANTE: la ventana de Edge que abre no tiene CORS.
REM  Usarla solo para estas herramientas, no para navegar.
REM ============================================================
@title Herramientas SIME / CM
setlocal
set "CARPETA=%~dp0"
set "ARGS=%*"

where powershell.exe >nul 2>&1
if errorlevel 1 (
  echo No se encontro powershell.exe en el PATH.
  pause
  exit /b 1
)

powershell.exe -NoProfile -NoLogo -ExecutionPolicy Bypass -Command "$c=[IO.File]::ReadAllText('%~f0');$i=$c.LastIndexOf([char]35+'POWERSHELL'+[char]35);if($i -lt 0){Write-Host 'El .bat esta incompleto: falta el bloque de PowerShell.' -ForegroundColor Red;Read-Host 'Enter para cerrar';exit 1};Invoke-Expression $c.Substring($i+12)"

endlocal
exit /b

#POWERSHELL#
# =====================================================================
#  Logica del lanzador (PowerShell embebido despues del marcador)
#  Todo lo interactivo va por consola: nada de cuadros de dialogo, que
#  pueden quedar ocultos o estar bloqueados por politica del equipo.
# =====================================================================
$ErrorActionPreference = 'Stop'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch { }

# ---------- Parametros del entorno (los mismos del HTML) ----------
$SIME_WEB  = 'http://296vnext02.grupo-exito.com/SIME/Web'
$KC_BASE   = 'http://keycloak.exito-prod.movil-exito.internal'
$KC_REALM  = 'optiva'
$KC_CLIENT = 'optiva'

$argumentos = [string]$env:ARGS
$resetSime  = $argumentos -match '/resetsime'
$resetCm    = $argumentos -match '/resetcm'
$reset      = ($argumentos -match '/reset') -and -not ($resetSime -or $resetCm)
$sinSesion  = $argumentos -match '/sinsesion'
$debug      = $argumentos -match '/debug'
$soloRep    = $argumentos -match '/solo-reporte'
$soloCasos  = $argumentos -match '/solo-casos'

# Que se abre en esta ejecución.
# Por defecto UNA sola pestana: el reporte de lineas prepagadas. El cierre
# masivo de casos ya no se abre solo; hay que pedirlo con /solo-casos.
# Si llegan los dos parametros a la vez, gana el reporte.
$abrirReporte = $soloRep -or -not $soloCasos
$abrirCasos   = $soloCasos -and -not $soloRep

$carpeta = $env:CARPETA
if ([string]::IsNullOrWhiteSpace($carpeta)) { $carpeta = (Get-Location).Path }
$htmlReporte = Join-Path $carpeta 'herramientas\reporte_prepagadas.html'
$htmlCasos   = Join-Path $carpeta 'herramientas\reporte_casos_masivos.html'
$cfgDir = Join-Path $env:APPDATA 'reporte_prepagadas'
$cfgCm  = Join-Path $cfgDir 'credenciales_cm.xml'
$cfgSm  = Join-Path $cfgDir 'credenciales_sime.xml'
$perfil = Join-Path $env:TEMP 'edge_reporte_prepagadas'

function Paso($n, $t) { Write-Host ("  [{0}/6] {1}" -f $n, $t) -ForegroundColor Gray }
function Ok($t)       { Write-Host ("        OK  {0}" -f $t) -ForegroundColor Green }
function Nota($t)     { Write-Host ("        {0}" -f $t) -ForegroundColor DarkGray }
function Aviso($t)    { Write-Host ("        {0}" -f $t) -ForegroundColor Yellow }

Write-Host ''
Write-Host '  Herramientas SIME / CM' -ForegroundColor Yellow
Write-Host '  ----------------------'
Nota ("PowerShell {0} | carpeta: {1}" -f $PSVersionTable.PSVersion, $carpeta)
Write-Host ''

# ---------------------------------------------------------------------
#  Credenciales: prompt por CONSOLA y guardado cifrado con DPAPI.
#  Export-Clixml de un PSCredential cifra la clave con la cuenta de
#  Windows actual: el archivo no sirve en otro equipo ni con otro usuario.
# ---------------------------------------------------------------------
function Leer-Credencial($ruta, $titulo, $usuarioSugerido) {
  if (Test-Path $ruta) {
    try {
      $c = Import-Clixml $ruta
      Ok ("Credenciales de {0} leidas del archivo local ({1})" -f $titulo, $c.UserName)
      return $c
    } catch {
      Nota "El archivo de credenciales estaba corrupto: se vuelve a pedir."
      Remove-Item $ruta -Force -ErrorAction SilentlyContinue
    }
  }
  Write-Host ''
  Write-Host ("  Credenciales de {0}" -f $titulo) -ForegroundColor Yellow
  $u = Read-Host ("  Usuario" + $(if ($usuarioSugerido) { " [$usuarioSugerido]" } else { "" }))
  if ([string]::IsNullOrWhiteSpace($u)) { $u = $usuarioSugerido }
  if ([string]::IsNullOrWhiteSpace($u)) { throw "No se ingreso usuario para $titulo." }
  $s = Read-Host '  Contrasena' -AsSecureString
  if (-not $s -or $s.Length -eq 0) { throw "No se ingreso contrasena para $titulo." }
  $c = New-Object System.Management.Automation.PSCredential($u, $s)
  if (-not (Test-Path $cfgDir)) { New-Item -ItemType Directory -Path $cfgDir -Force | Out-Null }
  $c | Export-Clixml $ruta
  Write-Host ''
  Ok ("Guardadas en {0}" -f $ruta)
  return $c
}

# Pide el token prf a SIME/Web. Con $cred usa ese usuario; sin $cred, la
# sesion de Windows actual. Lanza excepcion si SIME no responde o no manda prf.
function Obtener-Prf($cred) {
  $p = @{ Uri = $SIME_WEB; UseBasicParsing = $true; MaximumRedirection = 10; TimeoutSec = 45 }
  if ($cred) { $p['Credential'] = $cred } else { $p['UseDefaultCredentials'] = $true }
  $r = Invoke-WebRequest @p

  $urlFinal = ''
  if ($r.BaseResponse.ResponseUri) { $urlFinal = $r.BaseResponse.ResponseUri.AbsoluteUri }
  elseif ($r.BaseResponse.RequestMessage) { $urlFinal = $r.BaseResponse.RequestMessage.RequestUri.AbsoluteUri }
  $m = [regex]::Match($urlFinal, '[?&]prf=([^&#]+)')
  if (-not $m.Success) { $m = [regex]::Match([string]$r.Content, '[?&]prf=([A-Za-z0-9+/%=_\-]+)') }
  if (-not $m.Success) {
    throw ("SIME respondio (HTTP {0}) pero no venia el prf en el redirect. URL final: {1}" -f $r.StatusCode, $urlFinal)
  }
  return [uri]::UnescapeDataString($m.Groups[1].Value)
}

$credCm = $null; $credSime = $null; $prf = $null; $urls = @()

try {
  # ---------- 1. Archivos ----------
  Paso 1 'Verificando archivos...'
  if ($abrirReporte) {
    if (Test-Path $htmlReporte) { Ok 'reporte_prepagadas.html encontrado' }
    else {
      if (-not $abrirCasos) { throw ("No se encontro reporte_prepagadas.html en:`n         {0}`n         Deja el .bat en la carpeta que contiene 'herramientas'." -f $carpeta) }
      Nota 'No se encontro reporte_prepagadas.html: se abre solo el cierre masivo.'
      $abrirReporte = $false
    }
  }
  if ($abrirCasos) {
    if (Test-Path $htmlCasos) { Ok 'reporte_casos_masivos.html encontrado' }
    else {
      if (-not $abrirReporte) { throw ("No se encontro reporte_casos_masivos.html en:`n         {0}`n         Deja el .bat en la carpeta que contiene 'herramientas'." -f $carpeta) }
      Nota 'No se encontro reporte_casos_masivos.html: se abre solo el reporte.'
      $abrirCasos = $false
    }
  }
  if (-not $abrirReporte -and -not $abrirCasos) {
    throw ("No hay ningun HTML para abrir en:`n         {0}" -f $carpeta)
  }
  if ($reset -or $resetCm) {
    Remove-Item $cfgCm -Force -ErrorAction SilentlyContinue
    Ok 'Credenciales del CM borradas'
  }
  if ($reset -or $resetSime) {
    Remove-Item $cfgSm -Force -ErrorAction SilentlyContinue
    Ok 'Credenciales de SIME borradas'
  }

  # ---------- 2. Credenciales ----------
  Paso 2 'Credenciales (archivo local cifrado)...'
  $credCm = Leer-Credencial $cfgCm 'CM / Keycloak' ''
  if ($abrirReporte) {
    if ($sinSesion -or (Test-Path $cfgSm)) {
      $credSime = Leer-Credencial $cfgSm 'SIME (Windows: dominio\usuario)' $env:USERNAME
    } else {
      Ok 'SIME usara la sesion de Windows actual (usa /sinsesion para escribir usuario y clave)'
    }
  }

  # ---------- 3. SIME: token prf ----------
  #  Un fallo aqui NO tumba el lanzador: el cierre masivo no usa SIME, asi que
  #  se ofrece reintentar, cambiar de credenciales o saltarse el reporte.
  if ($abrirReporte) {
    Paso 3 'SIME: pidiendo el token prf a SIME/Web...'
    $intentos = 0
    while ($abrirReporte -and -not $prf) {
      $intentos++
      try {
        $prf = Obtener-Prf $credSime
      } catch {
        $motivo = $_.Exception.Message
        Aviso ("SIME no acepto la peticion: {0}" -f $motivo)
        if ($credSime -and ($motivo -match '401|No autorizado|Unauthorized')) {
          Remove-Item $cfgSm -Force -ErrorAction SilentlyContinue
          Nota ("Se borraron las credenciales guardadas de SIME ({0}): no sirven." -f $credSime.UserName)
        }
        if ($intentos -ge 4) {
          if ($abrirCasos) {
            Aviso 'Demasiados intentos con SIME: se abre solo el cierre masivo.'
            $abrirReporte = $false
            break
          }
          throw ("SIME no respondio despues de varios intentos: {0}`n         Revisa la VPN / red interna." -f $motivo)
        }
        Write-Host ''
        Write-Host '  Que hacemos con el reporte de lineas?' -ForegroundColor Yellow
        Write-Host '    [1] Escribir usuario y clave de SIME (formato dominio\usuario)'
        Write-Host '    [2] Reintentar con la sesion de Windows actual'
        if ($abrirCasos) { Write-Host '    [3] Saltarlo y abrir solo el cierre masivo de casos' }
        $op = Read-Host '  Opcion'
        Write-Host ''
        if ($op -eq '3' -and $abrirCasos) {
          $abrirReporte = $false
        } elseif ($op -eq '2') {
          $credSime = $null
          Nota 'Reintentando con la sesion de Windows actual...'
        } else {
          $credSime = Leer-Credencial $cfgSm 'SIME (Windows: dominio\usuario)' $env:USERNAME
        }
      }
    }

    if ($prf) {
      $quien = ''
      try {
        $perfilSime = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($prf)) | ConvertFrom-Json
        $quien = [string]$perfilSime.Nombre
        if ($perfilSime.Departamento) { $quien = $quien + ' - ' + $perfilSime.Departamento }
      } catch { }
      if ($quien) { Ok ("Token prf obtenido para {0}" -f $quien) } else { Ok 'Token prf obtenido' }
    }
  } else {
    Paso 3 'SIME: no hace falta (el cierre masivo solo usa el CM)'
    Ok 'Paso omitido'
  }

  # ---------- 4. CM: login Keycloak ----------
  Paso 4 'CM: validando usuario y clave contra Keycloak...'
  $body = @{
    grant_type = 'password'; client_id = $KC_CLIENT; scope = 'openid'
    username   = $credCm.UserName
    password   = $credCm.GetNetworkCredential().Password
  }
  try {
    $tok = Invoke-RestMethod -Method Post -TimeoutSec 45 `
      -Uri ("{0}/auth/realms/{1}/protocol/openid-connect/token" -f $KC_BASE, $KC_REALM) `
      -ContentType 'application/x-www-form-urlencoded' -Body $body
    if (-not $tok.access_token) { throw 'Keycloak no devolvio access_token.' }
    Ok ("Sesion CM valida para {0} (token de {1}s)" -f $credCm.UserName, $tok.expires_in)
  } catch {
    Remove-Item $cfgCm -Force -ErrorAction SilentlyContinue
    throw ("Keycloak rechazo el login del CM: {0}`n         Se borraron esas credenciales: vuelve a ejecutar el .bat para reingresarlas." -f $_.Exception.Message)
  }

  # ---------- 5. Edge ----------
  Paso 5 'Preparando Microsoft Edge...'
  $edge = ''
  foreach ($base in @(${env:ProgramFiles(x86)}, $env:ProgramFiles, $env:LOCALAPPDATA)) {
    if ([string]::IsNullOrWhiteSpace($base)) { continue }
    $cand = Join-Path $base 'Microsoft\Edge\Application\msedge.exe'
    if (Test-Path $cand) { $edge = $cand; break }
  }
  if (-not $edge) { throw 'No se encontro msedge.exe en las rutas estandar de Microsoft Edge.' }
  if (Test-Path $perfil) { Remove-Item $perfil -Recurse -Force -ErrorAction SilentlyContinue }
  Ok 'Perfil temporal limpio'

  # El prf va en la query (como en el redirect de SIME) y las credenciales del
  # CM en el FRAGMENTO (#...), que no viaja en ninguna peticion. Cada pagina
  # las lee al cargar, llena los campos y limpia la URL.
  $usrEnc  = [uri]::EscapeDataString($credCm.UserName)
  $passEnc = [uri]::EscapeDataString($credCm.GetNetworkCredential().Password)

  if ($abrirReporte -and $prf) {
    $rutaRep = [uri]::EscapeUriString('file:///' + ($htmlReporte -replace '\\', '/'))
    $urls += ('{0}?prf={1}#cm_user={2}&cm_pass={3}' -f $rutaRep, [uri]::EscapeDataString($prf), $usrEnc, $passEnc)
  }
  if ($abrirCasos) {
    $rutaCas = [uri]::EscapeUriString('file:///' + ($htmlCasos -replace '\\', '/'))
    $urls += ('{0}#cm_user={1}&cm_pass={2}' -f $rutaCas, $usrEnc, $passEnc)
  }
  if ($urls.Count -eq 0) { throw 'No quedo ninguna herramienta por abrir.' }

  # ---------- 6. Abrir ----------
  Paso 6 ('Abriendo {0} herramienta(s)...' -f $urls.Count)
  $argsEdge = @(
    ('--user-data-dir="{0}"' -f $perfil),
    '--disable-web-security',
    '--allow-file-access-from-files',
    '--no-first-run',
    '--no-default-browser-check',
    '--new-window',
    '--start-maximized',
    '--inPrivate'
  )
  foreach ($u in $urls) { $argsEdge += ('"{0}"' -f $u) }
  Start-Process $edge -ArgumentList $argsEdge

  Write-Host ''
  if ($abrirReporte -and $prf) { Nota 'Pestana: reporte de lineas prepagadas' }
  if ($abrirCasos)             { Nota 'Pestana: cierre masivo de casos (empieza en modo Simulacion)' }
  Write-Host '  Listo. Usa esa ventana solo para estas herramientas.' -ForegroundColor Green
  Write-Host ''
  Start-Sleep -Seconds 4
}
catch {
  Write-Host ''
  Write-Host ('  ERROR  ' + $_.Exception.Message) -ForegroundColor Red
  if ($debug) {
    Write-Host ''
    Write-Host '  --- detalle tecnico (/debug) ---' -ForegroundColor DarkGray
    Write-Host ($_ | Out-String) -ForegroundColor DarkGray
    Write-Host ($_.ScriptStackTrace) -ForegroundColor DarkGray
  } else {
    Write-Host '  (vuelve a ejecutarlo con  dame click.bat /debug  para ver el detalle)' -ForegroundColor DarkGray
  }
  Write-Host ''
  Read-Host '  Enter para cerrar'
}
finally {
  # Limpieza: nada de esto debe quedar vivo en memoria mas de lo necesario
  $prf = $null; $urls = $null; $body = $null; $tok = $null
  $usrEnc = $null; $passEnc = $null
  $credCm = $null; $credSime = $null
  [GC]::Collect()
}