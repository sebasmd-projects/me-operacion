# Validador QDN · Claro (HLR/HSS) — Documentación técnica

> **Versión: v2.0** · Convención de versionado: *fix* `+0.1` · *feature* `+1.0`.
> Base compartida: ver `doc/lanzador/README.md`.

Consulta por **MSISDN** el estado de una línea en el HLR/HSS de Claro a través del servicio **QDN** de Móvil Éxito, de forma individual o masiva. Implementa la HU *"Validador HLR/HSS mediante consulta QDN Movil Éxito - Claro"*.

> Todo corre en el navegador del analista. No hay backend propio: la página autentica contra el servicio OAuth2 de Claro y consulta el API gateway directamente.

---

## 1. Objetivos

- Resolver, para una o miles de líneas, **cuál es el estado real en HLR/HSS** sin entrar a consolas técnicas.
- Identificar **bloqueos y restricciones** (nacionales, datos, roaming, VLR) con su interpretación de negocio.
- Dejar disponible el **response completo** organizado por categorías, y el **JSON original** para QA, auditoría y troubleshooting.
- **No generar ruido**: si un dato no vino en la respuesta, no se inventa.

---

## 2. Arquitectura y archivos

| Archivo | Qué contiene |
|---|---|
| `herramientas/validador_qdn.html` | Solo marcado: KPIs, pasos, filtros, tabla y modal de detalle. |
| `assets/logica-qdn.js` | Autenticación OAuth2 propia de QDN, parseo del response, concurrencia, reintentos, filtros y tabla. |
| `assets/logica-qdn-operaciones.js` | Operaciones que **escriben** en la red: bloqueos, desbloqueos y conciliación (§11). Se carga después y reusa el token, las filas y los filtros de `logica-qdn.js`. |
| `assets/me-qdn-puente.js` | Enganche con el shell: sesión, exportaciones, spinners, registro. |
| `assets/me-ui.js` / `me-ui.css` | Shell, tablas y exportación. **Común.** |

QDN **no** usa el Keycloak del CM (`me-api.js`): tiene su propio OAuth2, por eso la autenticación vive en `logica-qdn.js`.

---

## 3. Conexión

Solo está confirmado el ambiente **PDN (Producción)**. Los valores vienen precargados y quedan ocultos tras *"Ver / editar datos de conexión (avanzado)"*.

| Parámetro | Valor por defecto |
|---|---|
| Token URL | `https://apim.claro.com.co/MsCommunicatAuthToken/User/authenticate` |
| Client ID | `MOVILEXITO` |
| Base API gateway | `https://msapigateway-nm-apigateway-aro-prod...aroapp.io` |
| Ruta QDN | `/APIMParOrdeConsQDN/MS/CUS/Customer/RSParOrdeConsQDN/V1/ValideQDN/{msisdn}` |

El gestor de token replica las estrategias de `interfaz.py`: `client_credentials` en el cuerpo (PDN), Basic + `client_credentials`, JSON usuario/clave, *password grant* con el usuario de API y JSON `clientId/clientSecret`. El token se renueva solo; **Probar conexión** solo sirve para verificar antes de una carga masiva.

---

## 4. Entrada de líneas

- **Escribir/pegar**: acepta espacio, tabulación, salto de línea, coma, punto y coma y `|`.
- **Excel (.xlsx) / CSV**: zona de arrastrar y soltar, con selección de hoja y columna (detecta `msisdn`/`linea` sola).
- Se normaliza a solo dígitos y se valida longitud **7–15**. Se informan **recibidos, válidos, inválidos y duplicados**; los duplicados se consultan una sola vez y los inválidos no llegan al servicio.

---

## 5. Ejecución

| Regla | Comportamiento |
|---|---|
| Concurrencia | Configurable, **8 por defecto** (tope técnico del servicio: 15 TPS). Nunca secuencial. |
| Timeout | 30 s por intento. |
| Reintentos | **Solo por timeout**: hasta 2 adicionales (3 intentos totales). |
| 401/403 | Renueva el token una vez y repite **sin gastar** reintento. |
| Errores funcionales | 400/401/403/404 y 5xx **no** se reintentan. |
| Fallo individual | No detiene el lote. |

Estados por línea: `EN COLA`, `CONSULTANDO`, `ACTIVE`/`INACTIVE` (según `operationalState`), `INCONSISTENTE`, `TIMEOUT`, `ERROR`, `INVALID`.

---

## 6. Qué se considera una consulta exitosa

**El HTTP 200 no basta.** Igual que `evaluar_negocio()` de `interfaz.py`, se recorre el cuerpo completo buscando marcas de fallo:

- `responseCode` o `statusCode` **≥ 400**
- `success: false`
- un objeto `error` con contenido (se extrae su `message`/`description` y `messageCode`)

Si aparece cualquiera, la línea queda en **ERROR** aunque el HTTP haya sido 200.

Además se valida la **coherencia**: `result.id` debe corresponder al MSISDN consultado y debe venir `operationalState`. Si no, la línea queda en **INCONSISTENTE** — se muestra el detalle, pero encabezado por el aviso *"no usar como evidencia sin verificar"*.

---

## 7. Regla de "no inventar datos"

| Situación | Qué se muestra |
|---|---|
| La característica **vino** con el texto `No Registra` | `No Registra` (es una afirmación del HLR) |
| La característica **no vino** en el response | `—` (no hay dato) |
| No llegó ninguna característica de bloqueo | Bloqueos: **`Sin datos`** (no "Sin bloqueos") |
| Roaming sin campo `odbBaroam`/`odbr` | `—` (no "Sin restricción") |
| Hay bloqueos activos del grupo Roaming | La columna Roaming los refleja, no dice "Sin restricción" |

Una línea inactiva o inexistente sale con todo en `—`, no con datos afirmativos.

---

## 8. Interpretación de bloqueos

Regla de negocio de la HU sobre las características de bloqueo:

| Valor QDN | Interpretación |
|---|---|
| `No Registra` (también `0`, `Ninguno`, vacío) | Sin bloqueo |
| `4` | **Bloqueo activo** |
| `5` | Bloqueo **histórico** (no activo hoy) |
| Otro valor | Se muestra crudo, **no** se cuenta como activo |

Se evalúan bloqueos **nacionales** (entrantes, salientes, SMS, identificador, LDI total / otros indicativos / 444 / sin implementación, video llamada), **de datos** (GPRS, SGSN, redes de otros operadores), **de roaming** (barring general, entrantes, salientes, desvíos, otros operadores) y **de VLR** (voz, SMS, fax, datos asíncronos/síncronos, PAD).

---

## 9. Tabla y detalle

Columnas: **MSISDN, Estado, IMSI, IMEI, 5G, Telefonía, SMS, Datos, Roaming, Bloqueos, Desvío, APN, IP, Portabilidad, Detalle (👁)**.

El modal organiza el response en las 10 categorías de la HU — Identidad, Servicios, Bloqueos, Datos/Internet, Roaming, Desvíos, VLR/MSC, VoLTE, Portabilidad y COTA — más **Información técnica** (`responseCode`, `messageCode`, `message`, `legacy`, `transactionId`, `timestamp`, `startOperatingDate`, intentos, duración) y el **JSON original**.

> El parser **no asume que `name` es único**: conserva cada característica con su `name`, `friendly_name` y `value`, porque el response repite nombres con significados distintos (p. ej. `UDC_SRVBSVOZ-csiState`, `TITAN_SRVVOLTE-order`).

---

## 10. Filtros, KPIs y exportación

- **Tarjetas (filtran al hacer clic)**: Activas · Inactivas · Con bloqueos · **Revisar respuesta** · Errores/timeout.
- **Filtros**: Estado, Bloqueos, 5G, Roaming; mostrar/ocultar columnas.
- **Exportación** CSV / Excel / JSON de lo que quede a la vista, con columna **Observaciones** para que los avisos de inconsistencia no se pierdan.

---

## 11. Operaciones sobre la línea (bloqueo, desbloqueo y conciliación)

Hasta la v1.1 la herramienta era de **solo lectura**. Desde la v2.0 puede además **escribir en la red de Claro**, con el mismo servicio y los mismos cuerpos que usa `interfaz.py`:

```
PATCH {base_apigw}/APIMParOrdeProvision/MSParOrdeProvision/SVC/Service/RSParOrdeProvision/V1/ModifingService
```

Usa el **mismo token OAuth2** de la consulta QDN (`gestorQdn`): no hay una segunda autenticación.

### 11.1 Catálogo

| Grupo | Operación | `process` / `action` | Confirmación |
|---|---|---|---|
| Bloqueo total | Bloqueo TOTAL | `lockall` · `level=2` | **Doble** |
| Bloqueo total | Desbloqueo TOTAL | `unlockall` | Simple |
| Bloqueos individuales | Bloquear / desbloquear llamada ENTRANTE | `blqinccl` · `activate`/`deactivate` | **Doble** / simple |
| Bloqueos individuales | Bloquear / desbloquear llamada SALIENTE | `blqoutcl` · `activate`/`deactivate` | **Doble** / simple |
| Bloqueos individuales | Bloquear / desbloquear SMS ENTRANTE | `blqincsms` · `activate`/`deactivate` | **Doble** / simple |
| Bloqueos individuales | Bloquear / desbloquear SMS SALIENTE | `blqoutsms` · `activate`/`deactivate` | **Doble** / simple |
| Roaming | Activar / desactivar ROAMING | `roaming` · `activate`/`deactivate` · `features=roaming` | Simple / **doble** |
| Procesos | Conciliación de línea | `conciliation` | **Doble** |

**Doble confirmación** = revisar (líneas, datos y cuerpo que se envía) → *"¿seguro?"*. La piden las que **restringen** el servicio y la conciliación; desbloquear pide una sola. Desactivar roaming cuenta como bloqueo.

`features` **nunca** viaja como `""`: vacío se envía como `" "`, igual que en `interfaz.py`.

### 11.2 De dónde salen IMSI, ICCID y KI

| Origen | Cuándo | Nota |
|---|---|---|
| **manual** | Se escribió en el modal de la operación | Gana sobre todo lo demás |
| **archivo** | Columnas opcionales `imsi` / `iccid` / `ki` del Excel o CSV | Basta con subir `msisdn,imsi` |
| **QDN** | `UDC_PRSSIMCD-imsi` · `COTA_PRSSIMCD-iccid` | Lo trae la consulta |
| **derivado** | `ICCID = 8957 + IMSI` | Solo si el ICCID falta. Ej.: `732157001050037` → `8957732157001050037` |

El origen de **cada valor** se muestra bajo su campo: nunca se presenta un dato derivado o escrito a mano como si lo hubiera dicho el HLR. Todos los campos son **editables** antes de ejecutar, y los que falten se piden ahí mismo (el botón no se habilita hasta completarlos). La **KI** nunca la devuelve el QDN: o viene del archivo, o se escribe, o va vacía — el servicio la acepta así.

### 11.3 Individual y masivo

- **Individual**: bloque *Operaciones sobre la línea* dentro del modal de detalle.
- **Masivo**: botón **Operaciones** en la barra de acciones; aplica a las líneas **visibles tras los filtros**. Antes de ejecutar se listan **todas** las líneas afectadas, con las que se omiten y el motivo.

Tras ejecutar, la herramienta **vuelve a consultar el QDN** de las líneas tocadas y refresca la tabla: es el mismo `qdn → operación → qdn` de los escenarios de `interfaz.py`. Sin eso la tabla seguiría mostrando el estado anterior.

### 11.4 Éxito real y bitácora

El éxito **no** es el HTTP 200: se evalúa el cuerpo con el mismo `evaluarNegocio()` de la consulta. Un 200 con `success:false` o `responseCode >= 400` cuenta como **FALLA**.

Cada ejecución queda en la **bitácora** de la sesión con fecha/hora, **usuario que la ejecutó** (el de la sesión CM o SIME que dejó el lanzador), MSISDN, operación, `process`/`action`, IMSI, ICCID, HTTP, resultado, código y `transactionId`. Se ve en el registro y se descarga con el botón **Bitácora**.

> El usuario queda **en la herramienta, no en el payload**: `ModifingService` no define un campo de nota y no se inventa uno. El token de QDN es de servicio (`client_credentials MOVILEXITO`) y no identifica a nadie, por eso la trazabilidad de la persona es local.

**Un timeout NO se reintenta**: la operación pudo haberse aplicado y repetirla la duplicaría. Se reporta como tal para verificar con una consulta antes de repetir.

---

## 12. Riesgos y límites

- **Ambiente productivo**: las consultas son de solo lectura, pero golpean PDN.
- **Las operaciones de §11 escriben en producción y no se deshacen solas.** La doble confirmación y el listado previo de líneas son la única red de seguridad: no hay "deshacer".
- **Masivo**: el alcance lo define el filtro puesto en ese momento. Revisa el listado de la confirmación, no el número.
- **Distribución**: los archivos se descargan y ejecutan **localmente en los PC administrados de backoffice**, no se publican en un servidor. Bajo ese modelo las credenciales viajan en el archivo por diseño, igual que `interfaz.py` y el lanzador. Solo habría que moverlas a un proxy si algún día la herramienta se publicara en un servidor accesible fuera del equipo.
- **CORS**: si se abre con doble clic (`file://`) el navegador puede bloquear las llamadas. Abrir siempre desde `dame click.bat`.
- **Interpretación de códigos no documentados**: valores distintos de `4`/`5` se muestran crudos y **no** se cuentan como bloqueo activo, a propósito.
- **Volumen**: `tiempo ≈ líneas ÷ concurrencia × ~3 s`. Con volúmenes muy grandes conviene exportar a CSV en vez de Excel.

---

## 13. Historial de cambios

| Versión | Cambios |
|---|---|
| **2.0** | La herramienta deja de ser solo de lectura: **operaciones de bloqueo, desbloqueo y conciliación** sobre `ModifingService` (§11), individuales desde el modal y masivas sobre lo filtrado, con doble confirmación en bloqueo y conciliación, listado previo de todas las líneas afectadas, campos IMSI/ICCID/KI pedibles y editables (archivo, QDN o `ICCID = 8957 + IMSI`), reconsulta de verificación y bitácora con el usuario que ejecutó. |
| 1.1 | Éxito real evaluado sobre el cuerpo (`evaluar_negocio`), estado `INCONSISTENTE` por respuesta que no corresponde a la línea, fin de los valores inventados (`—` vs `No Registra`), `Sin datos` en bloqueos no evaluados, coherencia Roaming ⇄ Bloqueos, KPIs por estado real y columna Observaciones en la exportación. |
| 1.0 | Versión inicial sobre la HU: consulta individual y masiva, concurrencia 8, reintentos por timeout, tabla de 15 columnas, detalle por categorías y JSON original. |
