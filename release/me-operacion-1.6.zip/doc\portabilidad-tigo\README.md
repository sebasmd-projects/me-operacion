# Validador Portabilidad · Tigo — Documentación técnica

> **Versión: v1.2** · Convención de versionado: *fix* `+0.1` · *feature* `+1.0`.
> Base compartida: ver `doc/lanzador/README.md`.

Valida por **MSISDN** en qué punto del proceso de portabilidad quedó una línea en el **HLR de Tigo**. Consume el mismo servicio de autogestión que *Consulta QDN · Tigo*, pero traduce el `RETCODE` al lenguaje del proceso.

**Reemplaza a `CheckPortabilidad.html`**, que procesaba de forma secuencial, sin reintentos, sin detalle y leyendo la respuesta como texto plano.

---

## 1. Arquitectura y archivos

| Archivo | Qué contiene |
|---|---|
| `herramientas/validador_portabilidad_tigo.html` | Solo marcado: KPIs, pasos, filtros, tabla y modal. |
| `assets/logica-portabilidad-tigo.js` | Autenticación por `X-Api-Key`, catálogo de RETCODE, parseo del perfil HLR, concurrencia, reintentos. |
| `assets/me-portabilidad-tigo-puente.js` | Enganche con el shell: exportaciones, spinners, registro. |
| `assets/me-ui.js` / `me-ui.css` | Shell, tablas y exportación. **Común.** |

Comparte motor con `logica-qdn-tigo.js`; lo único que cambia es el catálogo de estados.

---

## 2. Regla de negocio (lo que significa cada RETCODE)

| RETCODE | Estado | Lectura de negocio | Qué hacer |
|---|---|---|---|
| `0` | **Creada** | La línea ya tiene perfil en el HLR: portación completada. | Nada. |
| `3001` | **Sin perfil (pendiente)** | `Subscriber not defined`. La línea **no tiene perfil** en el HLR. | Depende del estado en ME — ver §2.1. |
| `1033` | **Residuo en Tigo** | `Number threshold exceeded`. La línea era de Tigo y **se portó a Móvil Éxito**, pero Tigo **no la eliminó de su HLR/HSS**. Ese residuo bloquea la creación. | **Escalar a Tigo.** Tras la depuración pasa a `3001` y ya se puede crear. |
| otro | Error (RETCODE) | Código no catalogado. | Revisar el detalle crudo. |

El proceso avanza en cadena:

```
1033 ──(Tigo depura su HLR/HSS)──▶ 3001 ──(se crea el perfil)──▶ 0
```

### 2.1 El `3001` no prueba que el número sea de ME

Solo dice que **no hay perfil**. Hay que cruzarlo con el estado de la línea en ME (Optiva):

| Estado en ME | Lectura | Qué hacer |
|---|---|---|
| **Activa** | Inconsistencia: activa en ME pero sin perfil en el HLR. | **Escalar a Optiva.** |
| **Inactiva** | Esperado: si está inactiva, obvio que no tiene perfil. | Nada. |
| **No pertenece a ME** | El número no es de Móvil Éxito (puede ser un Port Out). | Descartar del lote. |

> Ojo con la lectura anterior de esta herramienta: `3001` **no** significa "es nuestro pero falta crearlo", y `1033` **no** significa "no es nuestro". `1033` es precisamente lo contrario — la línea **sí** pasó a Móvil Éxito y lo que falta es que Tigo la borre.

---

## 3. Servicio

```
POST {base}/apimew/api/v1/autogestion/HLR/consulta
Headers: Content-Type: application/json · X-Api-Key: <llave fija>
Body:    { "TransactionID": "...", "FechaConsulta": "<ISO 8601>", "Linea": "57XXXXXXXXXX" }
```

Endpoint: `tulioqa.grupo-exito.com`. **El nombre engaña**: el gateway se llama «qa», pero detrás hay **un solo HLR/HSS**, el de **producción** — los datos son reales. El `57` lo antepone la herramienta. La respuesta es JSON (`perfilHLR`, `transaccionID`, `fechaHora`, `error[]`), no texto plano.

---

## 4. Coherencia de la respuesta (anti-ruido)

El defecto más caro de este flujo es reportar **"Creada"** cuando la evidencia no lo sostiene. Antes de aceptar un resultado se verifica que la respuesta **hable de la línea consultada**; si no, el estado pasa a **`Revisar respuesta`**:

- El `ISDN` del perfil **no coincide** con el MSISDN consultado.
- `RETCODE 0` **sin perfil HLR**.
- `RETCODE 0` con perfil pero **sin ISDN**.
- Respuesta con perfil **y además** errores.

Si el servicio (o un stub de QA) devolviera siempre el mismo perfil, esta validación lo delata de inmediato en vez de marcar todo el lote como Creada.

---

## 5. Ejecución

| Regla | Comportamiento |
|---|---|
| Entrada | Pegar, CSV o Excel, con los mismos separadores del resto de la suite. |
| Validación | Solo dígitos, longitud 7–15; se informan inválidos y duplicados. |
| Concurrencia | Configurable, **8 por defecto** (antes: 1 a la vez). |
| Timeout | 30 s por intento. |
| Reintentos | **Solo por timeout**: hasta 2 adicionales (3 intentos totales). |
| Fallo individual | No detiene el lote. |

---

## 6. Tabla, filtros y exportación

Columnas: **MSISDN, Estado, RETCODE, IMSI, IMEI, Tipo SIM, Bloqueos, Roaming, Desvíos, Detalle (👁)**.

- **Tarjetas**: Creadas · Sin perfil (pendiente) · Residuo en Tigo · **Revisar respuesta** · Errores/timeout.
- **Filtros**: Estado y Restricciones; mostrar/ocultar columnas.
- **Exportación** CSV / Excel / JSON con columna **Observaciones** (avisos de inconsistencia).
- El modal trae el perfil HLR por secciones, la información técnica y el **JSON original**.

Sobre la interpretación de bloqueos y desvíos del perfil (heurística declarada, campos ODB con mapeo estándar, `PROV` = provisionado): ver `doc/consulta-qdn-tigo/README.md` §6 y §7 — el motor es el mismo.

---

## 7. Riesgos y límites

- **Datos de producción**: el gateway se llama `tulioqa`, pero consulta el único HLR/HSS existente. Lo que se ve corresponde a portabilidades reales.
- **Distribución**: los archivos se descargan y ejecutan **localmente en los PC administrados de backoffice**, no se publican en un servidor. Bajo ese modelo las credenciales viajan en el archivo por diseño, igual que `interfaz.py` y el lanzador. Solo habría que moverlas a un proxy si algún día la herramienta se publicara en un servidor accesible fuera del equipo.
- **Solo lee**: la herramienta no crea ni modifica nada en el HLR; la creación sigue siendo un proceso aparte.
- **CORS**: abrir desde `dame click.bat`, no con doble clic.

---

## 8. Historial de cambios

| Versión | Cambios |
|---|---|
| **1.2** | Reglas de negocio de Tigo actualizadas: `3001` = **Sin perfil** (no prueba pertenencia a ME; se cruza con Optiva) y `1033` = **Residuo en Tigo** (la línea sí se portó a ME, Tigo no la eliminó de su HLR/HSS; se escala a Tigo y luego pasa a `3001`). Reemplaza la lectura de la v1.1. |
| 1.1 | Etiquetas de negocio corregidas (`3001` = pendiente y **es** de ME; `1033` = Port Out), validación de coherencia ISDN ⇄ línea, estado `Revisar respuesta`, KPIs y columna Observaciones. |
| 1.0 | Reemplazo de `CheckPortabilidad.html`: JSON en vez de texto plano, concurrencia real, reintentos por timeout y detalle completo del perfil. |
