/* =====================================================================
   logica-qdn-operaciones.js · Operaciones de provisión sobre la línea
   ---------------------------------------------------------------------
   El validador QDN era de SOLO LECTURA. Aquí se agregan las operaciones
   que ESCRIBEN en la red de Claro: bloqueos, desbloqueos y conciliación.

   Todo sale de `interfaz.py` (consola de líneas), que es la referencia
   viva de estos servicios:

     · endpoint  PATCH {base_apigw}/APIMParOrdeProvision/.../ModifingService
     · payloads  process / action / level / relatedParty / tier / msisdn /
                 imsi / iccid / ki / features
     · reglas    `features` NUNCA viaja como "" (vacío -> " ");
                 el éxito real NO es el HTTP 200, se evalúa el cuerpo.

   Se carga DESPUÉS de logica-qdn.js y reusa lo que ya vive allí:
   `gestorQdn` (mismo OAuth2), `cfgQdn`, `evaluarNegocio()`, `filas`,
   `filaPasaFiltros()`, `consultarConReintentos()`, `ejecutarPool()` y
   `render()`. No duplica ni el token ni el parseo.

   POR QUÉ LA DOBLE CONFIRMACIÓN
   Estas llamadas afectan líneas REALES en PRODUCCIÓN y no se deshacen
   solas. Bloquear y conciliar piden dos pasos (revisar -> "seguro?");
   desbloquear pide uno. En masivo se listan TODAS las líneas antes de
   ejecutar. Cada ejecución queda con el usuario que la hizo en la
   bitácora, el registro y la exportación.
===================================================================== */

/* ---------------------------------------------------------------------
   1 · ENDPOINT Y CONSTANTES (mismos valores que interfaz.py)
--------------------------------------------------------------------- */
const RUTA_MODIFYING = "/APIMParOrdeProvision/MSParOrdeProvision/SVC/Service/RSParOrdeProvision/V1/ModifingService";
const RELATED_PARTY = [{ id: "EXITO", role: "ServiceProvider", name: "MOVIL EXITO" }];
const TIER_OPERACION = "prepaid";
const NIVEL_LOCKALL = "2";
const CONCURRENCIA_OPERACION = 3;   // más bajo que en consulta: son escrituras

/**
 * `features` no admite cadena vacía: el servicio la rechaza. Vacío -> " ".
 * Varios valores se separan con pipe. Misma regla que normalizar_features().
 */
function normalizarFeatures(texto) {
    const partes = String(texto === null || texto === undefined ? "" : texto)
        .split("|").map(p => p.trim()).filter(Boolean);
    return partes.length ? partes.join("|") : " ";
}

/* ---------------------------------------------------------------------
   2 · CATÁLOGO DE OPERACIONES
   ---------------------------------------------------------------------
   `tipo` decide cuánta fricción pide la interfaz:
     bloqueo / conciliacion -> doble confirmación (revisar + "seguro?")
     desbloqueo             -> confirmación simple
   Desactivar roaming es una restricción, así que cuenta como bloqueo.
--------------------------------------------------------------------- */
const OPERACIONES = [
    { id: "lockall", grupo: "Bloqueo total", etiqueta: "Bloqueo TOTAL de la línea", tipo: "bloqueo", proceso: "lockall" },
    { id: "unlockall", grupo: "Bloqueo total", etiqueta: "Desbloqueo TOTAL de la línea", tipo: "desbloqueo", proceso: "unlockall" },

    { id: "blqinccl_on", grupo: "Bloqueos individuales", etiqueta: "Bloquear llamada ENTRANTE", tipo: "bloqueo", proceso: "blqinccl", accion: "activate" },
    { id: "blqinccl_off", grupo: "Bloqueos individuales", etiqueta: "Desbloquear llamada ENTRANTE", tipo: "desbloqueo", proceso: "blqinccl", accion: "deactivate" },
    { id: "blqoutcl_on", grupo: "Bloqueos individuales", etiqueta: "Bloquear llamada SALIENTE", tipo: "bloqueo", proceso: "blqoutcl", accion: "activate" },
    { id: "blqoutcl_off", grupo: "Bloqueos individuales", etiqueta: "Desbloquear llamada SALIENTE", tipo: "desbloqueo", proceso: "blqoutcl", accion: "deactivate" },
    { id: "blqincsms_on", grupo: "Bloqueos individuales", etiqueta: "Bloquear SMS ENTRANTE", tipo: "bloqueo", proceso: "blqincsms", accion: "activate" },
    { id: "blqincsms_off", grupo: "Bloqueos individuales", etiqueta: "Desbloquear SMS ENTRANTE", tipo: "desbloqueo", proceso: "blqincsms", accion: "deactivate" },
    { id: "blqoutsms_on", grupo: "Bloqueos individuales", etiqueta: "Bloquear SMS SALIENTE", tipo: "bloqueo", proceso: "blqoutsms", accion: "activate" },
    { id: "blqoutsms_off", grupo: "Bloqueos individuales", etiqueta: "Desbloquear SMS SALIENTE", tipo: "desbloqueo", proceso: "blqoutsms", accion: "deactivate" },

    // La colección manda features="roaming" en estas dos (no el valor general).
    { id: "roaming_on", grupo: "Roaming", etiqueta: "Activar ROAMING", tipo: "desbloqueo", proceso: "roaming", accion: "activate", features: "roaming" },
    { id: "roaming_off", grupo: "Roaming", etiqueta: "Desactivar ROAMING", tipo: "bloqueo", proceso: "roaming", accion: "deactivate", features: "roaming" },

    { id: "conciliation", grupo: "Procesos", etiqueta: "Conciliación de línea", tipo: "conciliacion", proceso: "conciliation" }
];

const GRUPOS_OPERACION = ["Bloqueo total", "Bloqueos individuales", "Roaming", "Procesos"];
const operacionPorId = id => OPERACIONES.find(o => o.id === id) || null;
const pideDobleConfirmacion = op => op.tipo === "bloqueo" || op.tipo === "conciliacion";

/* ---------------------------------------------------------------------
   3 · DATOS DE LA LÍNEA (IMSI / ICCID / KI) Y DE DÓNDE SALEN
   ---------------------------------------------------------------------
   El PATCH necesita el IMSI; la conciliación además el ICCID. Hay cuatro
   orígenes posibles, y el que se use SIEMPRE se muestra en pantalla para
   que nadie envíe un dato creyendo que lo dijo el HLR:

     1. manual    lo escribió el analista en el modal de la operación
     2. archivo   columna opcional imsi / iccid / ki del Excel o CSV
     3. QDN       lo devolvió la consulta (UDC_PRSSIMCD-imsi, COTA_…-iccid)
     4. derivado  ICCID = 8957 + IMSI (regla del operador; solo si falta)

   Manual gana sobre archivo, y archivo sobre QDN: si alguien se tomó el
   trabajo de escribirlo o cargarlo, no se le sobreescribe en silencio.
   La KI no la devuelve el QDN nunca: o viene del archivo, o se escribe,
   o va vacía (el servicio la acepta así).
--------------------------------------------------------------------- */
const SIN_DATO = new Set(["—", "", "No Registra", null, undefined]);
const PREFIJO_ICCID = "8957";
const LARGO_IMSI = 15;

function valorQdn(f, campo) {
    const v = f && f.resumen ? f.resumen[campo] : null;
    return SIN_DATO.has(v) ? "" : String(v).trim();
}

/** ICCID = 8957 + IMSI (p. ej. 732157001050037 -> 8957732157001050037). */
function iccidDesdeImsi(imsi) {
    const d = String(imsi || "").replace(/\D/g, "");
    return d.length === LARGO_IMSI ? PREFIJO_ICCID + d : "";
}

/** Correcciones escritas a mano en el modal: msisdn -> {imsi, iccid, ki}. */
const datosManuales = new Map();

/**
 * Resuelve los tres campos con su procedencia.
 * Devuelve { imsi:{valor,origen}, iccid:{…}, ki:{…} }.
 */
function datosOperacion(f) {
    const manual = datosManuales.get(f.msisdn) || {};
    const archivo = (typeof datosArchivo !== "undefined" && datosArchivo.get(f.msisdn)) || {};
    const elegir = (campo, origenQdn) => {
        if (manual[campo]) return { valor: manual[campo], origen: "manual" };
        if (archivo[campo]) return { valor: archivo[campo], origen: "archivo" };
        const qdn = origenQdn ? valorQdn(f, campo) : "";
        if (qdn) return { valor: qdn, origen: "QDN" };
        return { valor: "", origen: "" };
    };

    const imsi = elegir("imsi", true);
    const iccid = elegir("iccid", true);
    if (!iccid.valor && imsi.valor) {
        const derivado = iccidDesdeImsi(imsi.valor);
        if (derivado) { iccid.valor = derivado; iccid.origen = "derivado 8957+IMSI"; }
    }
    // La KI no existe en el QDN: solo manual o archivo.
    const ki = elegir("ki", false);

    return { imsi, iccid, ki };
}

/** Compatibilidad con el resto del archivo: solo el valor resuelto. */
function datoLinea(f, campo) {
    const d = datosOperacion(f)[campo];
    return d ? d.valor : "";
}

/** Campos que la operación exige. La KI nunca es obligatoria. */
function camposRequeridos(op) {
    return op && op.proceso === "conciliation" ? ["imsi", "iccid"] : ["imsi"];
}

/**
 * Motivo por el que una línea NO se puede operar ni pidiendo datos, o ""
 * si es operable (aunque haya que completar campos a mano).
 */
function motivoNoOperable(f, op) {
    if (f.estadoProceso !== "SUCCESS" && f.estadoProceso !== "INCONSISTENTE") {
        return "la consulta QDN no devolvió un resultado utilizable";
    }
    if (f.estadoProceso === "INCONSISTENTE") {
        return "la respuesta QDN quedó marcada como inconsistente";
    }
    return "";
}

/** Campos obligatorios que todavía están vacíos para esta línea. */
function faltantesDe(f, op) {
    const datos = datosOperacion(f);
    return camposRequeridos(op).filter(c => !datos[c].valor);
}

/** Cuerpo del PATCH, con la misma forma exacta que arma interfaz.py. */
function payloadOperacion(op, f) {
    const datos = datosOperacion(f);
    const cuerpo = { process: op.proceso };
    if (op.proceso === "lockall") cuerpo.level = NIVEL_LOCKALL;
    if (op.accion) cuerpo.action = op.accion;
    cuerpo.relatedParty = RELATED_PARTY;
    cuerpo.tier = TIER_OPERACION;
    cuerpo.msisdn = f.msisdn;
    cuerpo.imsi = datos.imsi.valor;
    if (op.proceso === "conciliation") {
        cuerpo.iccid = datos.iccid.valor;
        cuerpo.ki = datos.ki.valor;   // vacía si nadie la aportó: el servicio la acepta
    }
    cuerpo.features = normalizarFeatures(op.features || "");
    return cuerpo;
}

/* ---------------------------------------------------------------------
   4 · QUIÉN EJECUTA (para la bitácora)
   ---------------------------------------------------------------------
   El token de QDN es de servicio (client_credentials MOVILEXITO): no
   identifica a nadie. La persona sale de la sesión que dejó el lanzador,
   CM (Keycloak) o SIME.
--------------------------------------------------------------------- */
function usuarioOperador() {
    const nombres = [];
    ["cm", "sime"].forEach(clave => {
        const st = MEUI.sesion.estado(clave);
        if (st && st.usuario) nombres.push(`${st.usuario} (${clave.toUpperCase()})`);
    });
    return nombres.length ? nombres.join(" · ") : "sin sesión identificada";
}

/* ---------------------------------------------------------------------
   5 · BITÁCORA
   ---------------------------------------------------------------------
   Queda EN LA HERRAMIENTA, no en el payload: el servicio de provisión no
   define un campo de nota en ModifingService y no se inventa uno. Se ve
   en el registro y sale en la exportación de operaciones.
--------------------------------------------------------------------- */
const bitacoraOperaciones = [];

function anotarBitacora(entrada) {
    bitacoraOperaciones.push(entrada);
    MEUI.log(
        `${entrada.ok ? "✔" : "✖"} ${entrada.operacion} · ${entrada.msisdn} · ` +
        `HTTP ${entrada.httpStatus} · código ${entrada.codigo === null ? "—" : entrada.codigo}` +
        `${entrada.detalle ? " · " + entrada.detalle : ""} · por ${entrada.usuario}`,
        entrada.ok ? "ok" : "err");
}

const CABECERA_BITACORA = ["Fecha/hora", "Usuario", "MSISDN", "Operación", "process", "action",
    "IMSI", "ICCID", "HTTP", "Resultado", "Código", "Message Code", "Detalle", "Transaction ID"];

function bitacoraExport() {
    return {
        head: CABECERA_BITACORA,
        rows: bitacoraOperaciones.map(b => [
            b.hora, b.usuario, b.msisdn, b.operacion, b.proceso, b.accion || "",
            b.imsi || "", b.iccid || "", b.httpStatus, b.ok ? "OK" : "FALLA",
            b.codigo === null || b.codigo === undefined ? "" : b.codigo,
            b.codigoMsg || "", b.detalle || "", b.transactionId || ""
        ])
    };
}

/* ---------------------------------------------------------------------
   6 · EJECUCIÓN DEL PATCH
--------------------------------------------------------------------- */
function idTransaccion() {
    return (crypto && crypto.randomUUID) ? crypto.randomUUID()
        : String(Date.now()) + Math.floor(Math.random() * 1e6);
}

async function patchUnaVez(url, payload, cfg, token) {
    const controlador = new AbortController();
    const temporizador = setTimeout(() => controlador.abort(), cfg.timeoutMs);
    const transactionId = idTransaccion();
    const t0 = performance.now();
    try {
        const r = await fetch(url, {
            method: "PATCH", signal: controlador.signal,
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + token,
                "transactionId": transactionId
            },
            body: JSON.stringify(payload)
        });
        const texto = await r.text();
        let cuerpo = null;
        try { cuerpo = texto ? JSON.parse(texto) : null; } catch (e) { /* no era JSON */ }
        return {
            ok: r.ok, status: r.status, cuerpo, texto, transactionId,
            ms: Math.round(performance.now() - t0)
        };
    } finally {
        clearTimeout(temporizador);
    }
}

/**
 * Ejecuta una operación sobre UNA línea y devuelve el registro de bitácora.
 * El éxito real se lee del cuerpo con `evaluarNegocio()` (logica-qdn.js):
 * un HTTP 200 con `success:false` o `responseCode>=400` es una FALLA.
 */
async function ejecutarOperacion(op, f, cfg) {
    const hora = new Date().toISOString().replace("T", " ").slice(0, 19);
    const usuario = usuarioOperador();
    const datos = datosOperacion(f);
    const base = {
        hora, usuario, msisdn: f.msisdn, operacion: op.etiqueta,
        proceso: op.proceso, accion: op.accion || "",
        imsi: datos.imsi.valor, iccid: datos.iccid.valor,
        origenImsi: datos.imsi.origen, origenIccid: datos.iccid.origen
    };

    const impedimento = motivoNoOperable(f, op)
        || (faltantesDe(f, op).length ? "falta " + faltantesDe(f, op).join(" y ") : "");
    if (impedimento) {
        return Object.assign(base, {
            ok: false, httpStatus: "—", codigo: "no-operable", codigoMsg: "",
            detalle: "No se envió nada: " + impedimento, payload: null, cuerpo: null
        });
    }

    const payload = payloadOperacion(op, f);
    const url = cfg.base_apigw.replace(/\/$/, "") + RUTA_MODIFYING;

    let tokenRenovado = false;
    while (true) {
        let token;
        try {
            token = await gestorQdn.obtener(cfg, tokenRenovado);
        } catch (e) {
            return Object.assign(base, {
                ok: false, httpStatus: "—", codigo: "auth", codigoMsg: "",
                detalle: "No se pudo autenticar: " + (e.message || e), payload, cuerpo: null
            });
        }

        let resp;
        try {
            resp = await patchUnaVez(url, payload, cfg, token);
        } catch (e) {
            const esTimeout = e && e.name === "AbortError";
            return Object.assign(base, {
                ok: false, httpStatus: esTimeout ? "timeout" : "—",
                codigo: esTimeout ? "timeout" : "conn-err", codigoMsg: "",
                // Un timeout NO se reintenta: la operación pudo haberse
                // aplicado y repetirla la duplicaría. Se verifica con el QDN.
                detalle: esTimeout
                    ? "Tiempo de espera agotado. NO se reintenta: verifica con una consulta antes de repetir."
                    : "Error de comunicación: " + (e.message || e),
                payload, cuerpo: null
            });
        }

        // 401/403: el token venció -> se renueva UNA vez y se repite.
        if ((resp.status === 401 || resp.status === 403) && !tokenRenovado) {
            tokenRenovado = true;
            gestorQdn.reset();
            continue;
        }

        const negocio = resp.cuerpo
            ? evaluarNegocio(resp.cuerpo)
            : { ok: resp.ok, codigo: resp.status, codigoMsg: null, detalle: (resp.texto || "").slice(0, 300) };
        if (!resp.ok) negocio.ok = false;

        return Object.assign(base, {
            ok: negocio.ok, httpStatus: resp.status, ms: resp.ms,
            codigo: negocio.codigo, codigoMsg: negocio.codigoMsg,
            detalle: negocio.detalle || "", transactionId: resp.transactionId,
            payload, cuerpo: resp.cuerpo, texto: resp.texto
        });
    }
}

/**
 * Vuelve a consultar el QDN de las líneas tocadas y refresca sus filas.
 * Es el mismo `qdn -> operación -> qdn` de los escenarios de interfaz.py:
 * sin esto la tabla seguiría mostrando el estado ANTERIOR a la operación.
 */
async function reconsultar(msisdns, cfg) {
    await ejecutarPool(msisdns, CONCURRENCIA_OPERACION, async (msisdn) => {
        const i = filas.findIndex(x => x.msisdn === msisdn);
        if (i < 0) return;
        const fresca = await consultarConReintentos(msisdn, cfg);
        filas[i] = Object.assign({}, filas[i], fresca);
    });
    render();
}

/* ---------------------------------------------------------------------
   7 · INTERFAZ · lista de operaciones (misma forma en modal y masivo)
--------------------------------------------------------------------- */
function claseTipo(tipo) {
    return tipo === "bloqueo" ? "err" : tipo === "conciliacion" ? "warn" : "ok";
}

/**
 * `contexto` = "linea" (modal de detalle) o "masivo" (barra de acciones).
 * En "linea" se deshabilita lo que esa línea no puede ejecutar y se explica
 * por qué; en masivo el filtro por línea se hace al confirmar.
 */
function listaOperacionesHTML(contexto, f) {
    return GRUPOS_OPERACION.map(grupo => {
        const ops = OPERACIONES.filter(o => o.grupo === grupo);
        if (!ops.length) return "";
        return `
        <div class="mb-2">
            <div class="fw-bold small text-muted mb-1">${MEUI.esc(grupo)}</div>
            <div class="d-flex flex-wrap gap-2">
                ${ops.map(op => {
                    const impedimento = contexto === "linea" ? motivoNoOperable(f, op) : "";
                    return `<button type="button"
                        class="btn btn-sm btn-me-line btn-operacion"
                        data-op="${MEUI.esc(op.id)}" data-contexto="${contexto}"
                        ${impedimento ? `disabled title="No disponible: ${MEUI.esc(impedimento)}"` : ""}>
                        <span class="badge-estado ${claseTipo(op.tipo)}">${op.tipo === "desbloqueo" ? "↑" : "↓"}</span>
                        ${MEUI.esc(op.etiqueta)}
                    </button>`;
                }).join("")}
            </div>
        </div>`;
    }).join("");
}

/** Bloque de operaciones dentro del modal de detalle de una línea. */
function pintarOperacionesLinea(f) {
    const cont = MEUI.$("#mdOperaciones");
    if (!cont) return;
    const impedimentoGeneral = motivoNoOperable(f, null);
    const datos = datosOperacion(f);
    const dato = (etq, d) => `${etq} <span class="me-mono">${MEUI.esc(d.valor || "—")}</span>` +
        `${d.origen ? ` <small class="text-muted">(${MEUI.esc(d.origen)})</small>` : ""}`;
    cont.innerHTML = `
        <div class="me-hint mb-2">
            Estas operaciones <b>escriben en producción</b> sobre
            <span class="me-mono">${MEUI.esc(f.msisdn)}</span> ·
            ${dato("IMSI", datos.imsi)} · ${dato("ICCID", datos.iccid)}.
            Lo que falte se pide al confirmar y todo se puede corregir ahí.
            Quedan registradas a nombre de <b>${MEUI.esc(usuarioOperador())}</b>.
        </div>
        ${impedimentoGeneral ? `<div class="alert alert-warning py-2 mb-2">
            No se puede operar esta línea: ${MEUI.esc(impedimentoGeneral)}.</div>` : ""}
        ${listaOperacionesHTML("linea", f)}`;
    cont.querySelectorAll("button.btn-operacion").forEach(b => {
        b.addEventListener("click", () => abrirConfirmacion(b.dataset.op, [f.msisdn]));
    });
}

/** Menú de operaciones masivas en la barra de acciones. */
function pintarMenuOperaciones() {
    const ul = MEUI.$("#menuOperaciones");
    if (!ul) return;
    ul.innerHTML = `<li class="px-2 pb-2 me-hint" style="max-width:320px">
            Se aplica a las <b id="opMasivoConteo">0</b> líneas que quedaron
            visibles tras los filtros. Antes de ejecutar se listan todas.
        </li>` + GRUPOS_OPERACION.map(grupo => `
        <li class="px-2 pt-1 fw-bold small text-muted">${MEUI.esc(grupo)}</li>
        ${OPERACIONES.filter(o => o.grupo === grupo).map(op => `
            <li><button type="button" class="dropdown-item btn-operacion small"
                data-op="${MEUI.esc(op.id)}" data-contexto="masivo">
                <span class="badge-estado ${claseTipo(op.tipo)}">${op.tipo === "desbloqueo" ? "↑" : "↓"}</span>
                ${MEUI.esc(op.etiqueta)}</button></li>`).join("")}`).join("");

    ul.querySelectorAll("button.btn-operacion").forEach(b => {
        b.addEventListener("click", () => {
            const visibles = filas.filter(filaPasaFiltros).map(f => f.msisdn);
            abrirConfirmacion(b.dataset.op, visibles);
        });
    });
    actualizarConteoMasivo();
}

function actualizarConteoMasivo() {
    const el = MEUI.$("#opMasivoConteo");
    if (el) el.textContent = filas.filter(filaPasaFiltros).length;
}

/* ---------------------------------------------------------------------
   8 · CONFIRMACIÓN (revisar -> "seguro?") Y EJECUCIÓN
--------------------------------------------------------------------- */
let operacionEnCurso = null;   // { op, objetivo: [filas], bloqueadas: [...] }

function abrirConfirmacion(opId, msisdns) {
    const op = operacionPorId(opId);
    if (!op) return;

    const candidatas = msisdns.map(m => filaDe(m)).filter(Boolean);
    const objetivo = [], bloqueadas = [];
    candidatas.forEach(f => {
        const motivo = motivoNoOperable(f, op);
        if (motivo) bloqueadas.push({ msisdn: f.msisdn, motivo });
        else objetivo.push(f);
    });

    operacionEnCurso = { op, objetivo, bloqueadas };
    const requeridos = camposRequeridos(op);

    MEUI.$("#opTitulo").textContent = op.etiqueta;
    MEUI.$("#opResultado").innerHTML = "";
    MEUI.$("#opPaso2").hidden = true;
    MEUI.$("#opPaso1").hidden = false;

    const muestra = objetivo[0] ? payloadOperacion(op, objetivo[0]) : null;
    MEUI.$("#opCuerpo").innerHTML = `
        <div class="d-flex flex-wrap gap-3 align-items-center mb-2">
            <span class="badge-estado ${claseTipo(op.tipo)}">${MEUI.esc(op.tipo.toUpperCase())}</span>
            <span class="me-mono text-muted">process=${MEUI.esc(op.proceso)}${op.accion ? " · action=" + MEUI.esc(op.accion) : ""}${op.proceso === "lockall" ? " · level=" + NIVEL_LOCKALL : ""}</span>
            <span class="text-muted small">Ejecuta: <b>${MEUI.esc(usuarioOperador())}</b></span>
        </div>

        <div class="alert ${objetivo.length > 1 ? "alert-danger" : "alert-warning"} py-2">
            Se va a ejecutar en <b>PRODUCCIÓN</b> sobre
            <b>${objetivo.length}</b> línea${objetivo.length === 1 ? "" : "s"}.
            Esta acción no se deshace sola.
        </div>

        <div class="fw-bold small mb-1">Líneas afectadas (${objetivo.length})</div>
        <div class="me-hint mb-1">
            Los campos vienen del archivo, de la consulta QDN o derivados
            (<span class="me-mono">ICCID = ${PREFIJO_ICCID} + IMSI</span>).
            Se pueden corregir aquí; el origen de cada valor queda debajo.
        </div>
        ${objetivo.length ? `<div style="max-height:260px;overflow:auto">
            <table class="table table-sm mb-0 tabla-operacion">
                <thead><tr>
                    <th>MSISDN</th><th>Estado</th><th>IMSI</th>
                    ${requeridos.indexOf("iccid") >= 0 ? "<th>ICCID</th><th>KI <small>(opcional)</small></th>" : ""}
                </tr></thead>
                <tbody>${objetivo.map(f => campoLineaHTML(op, f, requeridos)).join("")}</tbody>
            </table></div>`
        : `<div class="alert alert-danger py-2 mb-0">Ninguna línea de la selección se puede operar.</div>`}

        ${bloqueadas.length ? `
            <div class="fw-bold small mt-3 mb-1">Se omiten (${bloqueadas.length})</div>
            <ul class="me-hint mb-0" style="max-height:140px;overflow:auto">
                ${bloqueadas.map(b => `<li><span class="me-mono">${MEUI.esc(b.msisdn)}</span> — ${MEUI.esc(b.motivo)}</li>`).join("")}
            </ul>` : ""}

        <div id="opAvisoFaltantes"></div>

        ${muestra ? `<div class="fw-bold small mt-3 mb-1">Cuerpo que se envía${objetivo.length > 1 ? " (ejemplo de la primera línea)" : ""}</div>
            <pre class="json me-mono mb-0" id="opPayload">${MEUI.esc(JSON.stringify(muestra, null, 2))}</pre>` : ""}`;

    // Cada input escribe en `datosManuales` y revalida en caliente.
    MEUI.$("#opCuerpo").querySelectorAll("input[data-campo]").forEach(inp => {
        inp.addEventListener("input", () => {
            const msisdn = inp.dataset.msisdn, campo = inp.dataset.campo;
            const previo = datosManuales.get(msisdn) || {};
            const limpio = campo === "ki" ? inp.value.trim() : inp.value.replace(/\D/g, "");
            if (limpio) previo[campo] = limpio; else delete previo[campo];
            datosManuales.set(msisdn, previo);
            // Escribir el IMSI vuelve a derivar el ICCID si no lo pusieron a mano.
            if (campo === "imsi") refrescarIccidDerivado(msisdn);
            revalidarConfirmacion();
        });
    });

    MEUI.$("#btnOpVolver").hidden = true;
    MEUI.$("#btnOpSeguro").hidden = true;
    const btn = MEUI.$("#btnOpGuardar");
    btn.hidden = false;
    btn.textContent = pideDobleConfirmacion(op) ? "Guardar" : "Ejecutar";
    btn.className = "btn btn-sm " + (pideDobleConfirmacion(op) ? "btn-warning" : "btn-me");
    revalidarConfirmacion();

    new bootstrap.Modal("#modalOperacion").show();
}

/** Una fila de la tabla de confirmación, con sus inputs y el origen del dato. */
function campoLineaHTML(op, f, requeridos) {
    const datos = datosOperacion(f);
    const celda = campo => {
        const d = datos[campo];
        const obligatorio = requeridos.indexOf(campo) >= 0;
        return `<td>
            <input type="text" inputmode="numeric"
                class="form-control form-control-sm me-mono ${obligatorio && !d.valor ? "is-invalid" : ""}"
                data-msisdn="${MEUI.esc(f.msisdn)}" data-campo="${campo}"
                value="${MEUI.esc(d.valor)}"
                placeholder="${obligatorio ? "obligatorio" : "opcional"}">
            <div class="me-hint">${d.origen ? MEUI.esc(d.origen) : (obligatorio ? "sin dato: escríbelo" : "sin dato")}</div>
        </td>`;
    };
    return `<tr>
        <td class="me-mono align-middle">${MEUI.esc(f.msisdn)}</td>
        <td class="align-middle">${MEUI.esc((f.operationalState || "—").toUpperCase())}</td>
        ${celda("imsi")}
        ${requeridos.indexOf("iccid") >= 0 ? celda("iccid") + celda("ki") : ""}
    </tr>`;
}

/** Al cambiar el IMSI se recalcula el ICCID derivado (no el escrito a mano). */
function refrescarIccidDerivado(msisdn) {
    const inp = MEUI.$(`#opCuerpo input[data-campo="iccid"][data-msisdn="${msisdn}"]`);
    if (!inp) return;
    const manual = datosManuales.get(msisdn) || {};
    if (manual.iccid) return;                       // lo escribieron: no se toca
    const f = filaDe(msisdn);
    if (!f) return;
    const datos = datosOperacion(f);
    inp.value = datos.iccid.valor;
    const pie = inp.parentElement.querySelector(".me-hint");
    if (pie) pie.textContent = datos.iccid.origen || "sin dato: escríbelo";
    inp.classList.toggle("is-invalid", !datos.iccid.valor);
}

/** Habilita o bloquea el botón según falten campos obligatorios. */
function revalidarConfirmacion() {
    if (!operacionEnCurso) return;
    const { op, objetivo } = operacionEnCurso;
    const incompletas = objetivo.filter(f => faltantesDe(f, op).length);

    const aviso = MEUI.$("#opAvisoFaltantes");
    if (aviso) {
        aviso.innerHTML = incompletas.length
            ? `<div class="alert alert-warning py-2 mt-2 mb-0">
                 Faltan datos obligatorios en <b>${incompletas.length}</b> línea(s):
                 ${MEUI.esc(incompletas.slice(0, 8).map(f => f.msisdn).join(", "))}${incompletas.length > 8 ? "…" : ""}.
                 Complétalos arriba para poder continuar.
               </div>`
            : "";
    }

    const payload = MEUI.$("#opPayload");
    if (payload && objetivo.length && !faltantesDe(objetivo[0], op).length) {
        payload.textContent = JSON.stringify(payloadOperacion(op, objetivo[0]), null, 2);
    }

    const btn = MEUI.$("#btnOpGuardar");
    if (btn) btn.disabled = !objetivo.length || incompletas.length > 0;
}

/** Paso 1 -> paso 2 en bloqueo y conciliación; ejecución directa si no. */
function confirmarPaso1() {
    if (!operacionEnCurso) return;
    const { op, objetivo } = operacionEnCurso;
    if (!objetivo.length) return;

    if (objetivo.some(f => faltantesDe(f, op).length)) { revalidarConfirmacion(); return; }
    if (!pideDobleConfirmacion(op)) { correrOperacion(); return; }

    MEUI.$("#opPaso1").hidden = true;
    MEUI.$("#opPaso2").hidden = false;
    MEUI.$("#btnOpGuardar").hidden = true;
    MEUI.$("#btnOpVolver").hidden = false;
    MEUI.$("#btnOpSeguro").hidden = false;
    MEUI.$("#opSeguroTexto").innerHTML =
        `¿Seguro? Vas a <b>${MEUI.esc(op.etiqueta.toLowerCase())}</b> en producción sobre ` +
        `<b>${objetivo.length}</b> línea${objetivo.length === 1 ? "" : "s"}` +
        `${objetivo.length === 1 ? ` (<span class="me-mono">${MEUI.esc(objetivo[0].msisdn)}</span>)` : ""}. ` +
        `Queda registrado a nombre de <b>${MEUI.esc(usuarioOperador())}</b>.`;
}

function volverPaso1() {
    MEUI.$("#opPaso2").hidden = true;
    MEUI.$("#opPaso1").hidden = false;
    MEUI.$("#btnOpSeguro").hidden = true;
    MEUI.$("#btnOpVolver").hidden = true;
    MEUI.$("#btnOpGuardar").hidden = false;
}

async function correrOperacion() {
    if (!operacionEnCurso) return;
    const { op, objetivo } = operacionEnCurso;
    const cfg = cfgQdn;

    MEUI.$("#opPaso1").hidden = true;
    MEUI.$("#opPaso2").hidden = true;
    MEUI.$("#btnOpGuardar").hidden = true;
    MEUI.$("#btnOpVolver").hidden = true;
    MEUI.$("#btnOpSeguro").hidden = true;
    const salida = MEUI.$("#opResultado");
    salida.innerHTML = `<div class="me-hint">Ejecutando <b>${MEUI.esc(op.etiqueta)}</b> sobre ${objetivo.length} línea(s)…</div>`;

    MEUI.log(`▶ ${op.etiqueta} sobre ${objetivo.length} línea(s) · ejecuta ${usuarioOperador()}`, "warn");

    const resultados = [];
    await ejecutarPool(objetivo, CONCURRENCIA_OPERACION, async (f) => {
        const r = await ejecutarOperacion(op, f, cfg);
        anotarBitacora(r);
        resultados.push(r);
        salida.innerHTML = `<div class="me-hint">Ejecutando… ${resultados.length} / ${objetivo.length}</div>`;
    });
    resultados.sort((a, b) => objetivo.findIndex(f => f.msisdn === a.msisdn) - objetivo.findIndex(f => f.msisdn === b.msisdn));

    const ok = resultados.filter(r => r.ok).length;
    salida.innerHTML = `
        <div class="alert ${ok === resultados.length ? "alert-success" : "alert-warning"} py-2">
            <b>${ok} de ${resultados.length}</b> operación(es) con resultado exitoso.
            ${ok === resultados.length ? "" : "Revisa el detalle: un HTTP 200 con error en el cuerpo cuenta como falla."}
        </div>
        <div style="max-height:260px;overflow:auto">
        <table class="table table-sm table-striped mb-0">
            <thead><tr><th>MSISDN</th><th>Resultado</th><th>HTTP</th><th>Código</th><th>Detalle</th></tr></thead>
            <tbody>${resultados.map(r => `<tr>
                <td class="me-mono">${MEUI.esc(r.msisdn)}</td>
                <td><span class="badge-estado ${r.ok ? "ok" : "err"}">${r.ok ? "OK" : "FALLA"}</span></td>
                <td class="me-mono">${MEUI.esc(String(r.httpStatus))}</td>
                <td class="me-mono">${MEUI.esc(String(r.codigo === null || r.codigo === undefined ? "—" : r.codigo))}</td>
                <td>${MEUI.esc([r.codigoMsg, r.detalle].filter(Boolean).join(" · ") || "—")}</td>
            </tr>`).join("")}</tbody>
        </table></div>
        <div class="me-hint mt-2">Verificando el estado real con una consulta QDN…</div>`;

    MEUI.toast(`${op.etiqueta}: ${ok}/${resultados.length} con éxito.`, ok === resultados.length ? "ok" : "warn");

    // Verificación: la tabla debe reflejar el estado DESPUÉS de la operación.
    await reconsultar(objetivo.map(f => f.msisdn), cfg);
    salida.insertAdjacentHTML("beforeend",
        `<div class="me-hint">Consulta de verificación terminada: la tabla ya muestra el estado actual.</div>`);
    operacionEnCurso = null;
}

/* ---------------------------------------------------------------------
   9 · INICIALIZACIÓN
--------------------------------------------------------------------- */
function inicializarOperaciones() {
    const guardar = MEUI.$("#btnOpGuardar");
    const seguro = MEUI.$("#btnOpSeguro");
    const volver = MEUI.$("#btnOpVolver");
    if (guardar) guardar.addEventListener("click", confirmarPaso1);
    if (seguro) seguro.addEventListener("click", correrOperacion);
    if (volver) volver.addEventListener("click", volverPaso1);

    const bitacora = MEUI.$("#btnBitacora");
    if (bitacora) bitacora.addEventListener("click", () => {
        if (!bitacoraOperaciones.length) { MEUI.toast("Todavía no se ha ejecutado ninguna operación.", "warn"); return; }
        const { head, rows } = bitacoraExport();
        MEUI.exportarCSV(head, rows, "bitacora_operaciones");
    });

    pintarMenuOperaciones();
}
inicializarOperaciones();
