/* =====================================================================
   logica-titularidad.js · Bloqueos de SIM por titularidad
   ---------------------------------------------------------------------
   Para qué existe: las llamadas al call por «me bloquearon la SIM» salen,
   en su mayoría, del proceso de comprobación de titularidad. Genesis deja
   el log de ese proceso (quién, qué línea, cómo terminó), pero no dice en
   qué red está la línea, y sin eso el asesor no puede resolver en la
   llamada. Esta herramienta junta las tres cosas en una tabla:

     1. Genesis   · el bloqueo/desbloqueo y cómo terminó  (se carga al abrir)
     2. CM        · titular, cuenta y estado de la línea   (bajo demanda)
     3. HLR/HSS   · Claro, Tigo, ambos o ninguno           (bajo demanda)

   Los pasos 2 y 3 son BAJO DEMANDA y sobre las filas marcadas, de 1 a n.
   No se lanzan solos: son miles de líneas y cada una cuesta peticiones a
   tres gateways distintos.

   Lo que NO vive aquí:
     · sesión y paginación de Genesis   → genesis-api.js  (GENESIS)
     · consulta Claro + Tigo            → hlr-consulta.js (HLRConsulta)
     · resolver la línea en el CM       → cm-lineas.js    (CMLineas)
     · shell, tablas, exportación       → me-ui.js        (MEUI)
     · enganche con la interfaz         → me-titularidad-puente.js
===================================================================== */

/* =====================================================================
   1 · CONFIGURACIÓN
===================================================================== */
const CONFIG = {
    /* Genesis responde ~150 ms por página; de a 500 son unas 420 páginas
       para 208.000 registros. Se piden de a una (el servidor devuelve la
       cuenta total y no hay forma de saltar sin leer), pero se deja
       configurable por si el gateway concede páginas más grandes. */
    paginaGenesis: 500,

    /* Cada línea dispara 2 peticiones (Claro + Tigo) a la vez. 5 en
       paralelo = 10 peticiones en vuelo: es el máximo que el cruce ya
       probado usa sin que los gateways empiecen a cortar. */
    concurrenciaHlr: 5,

    /* El CM es una sola petición por línea y aguanta más holgura. */
    concurrenciaCm: 6,

    /* Guarda de interfaz: marcar 5.000 filas y mandarlas a consultar es
       casi siempre un clic por accidente en «seleccionar todas». */
    maxSeleccion: 2000
};

/* =====================================================================
   2 · MODELO DE UNA FILA
   ---------------------------------------------------------------------
   Genesis manda `tipoOperacion` como booleano y `resultado` como número.
   Ninguno de los dos se muestra crudo: un «true/2» en una tabla no le
   dice nada a quien atiende la llamada.

   `resultado` se interpretó cruzando cada valor con TODAS las descripciones
   que lo acompañan en la captura. No hay catálogo publicado, así que un
   valor nuevo se muestra como «Resultado N» y no se le inventa significado.

     0 (114)  «ya estaba en el estado correcto» (96) · sin descripción (18)
     1  (15)  «estado inválido» (12) · «Respuesta fallida … SOAP 500» (3)
     2 (120)  «finalizó, pero la línea quedó en un estado inesperado»

   El 1 se llama «Falló» y no «Estado inválido» justamente por esas 3: la
   etiqueta tiene que ser cierta para TODAS las filas del grupo, no para la
   mayoría. El código crudo va igual en la tabla y en la exportación, así
   que quien quiera afinar no pierde el dato.

   Para el call, 1 y 2 significan lo mismo en la práctica: la línea NO quedó
   como se pedía. Se separan porque en 1 la orden no se ejecutó y en 2 sí,
   y eso cambia a quién se escala.
===================================================================== */
const OPERACION = { true: "Bloqueo", false: "Desbloqueo" };
const RESULTADO = {
    0: { texto: "Sin cambio necesario", clase: "info" },
    1: { texto: "Falló", clase: "err" },
    2: { texto: "Terminó en estado inesperado", clase: "warn" }
};

const textoOperacion = v => OPERACION[String(v)] || "—";
const infoResultado = v => RESULTADO[v] || { texto: v != null ? `Resultado ${v}` : "—", clase: "neutro" };

/** Estado del enriquecimiento de cada fila (columnas CM y HLR). */
const PASO = { PENDIENTE: "Pendiente", CONSULTANDO: "Consultando", LISTA: "Lista", ERROR: "Error" };

function filaDesdeGenesis(g) {
    return {
        __id: g.id,
        id: g.id,
        fecha: g.fechaHoraTransaccion || "",
        linea: String(g.linea || "").trim(),
        documento: String(g.documento || "").trim(),
        operacion: textoOperacion(g.tipoOperacion),
        resultado: g.resultado,
        resultadoTexto: infoResultado(g.resultado).texto,
        canal: g.canal || "",
        usuario: g.usuario || "",
        descripcion: g.descripcionResultado || "",

        sel: false,

        // Se llenan bajo demanda; vacías no es lo mismo que consultadas.
        cmPaso: PASO.PENDIENTE, cmTitular: "", cmCuenta: "", cmSim: "",
        cmEstado: "", cmError: "",

        hlrPaso: PASO.PENDIENTE, hlrUbicacion: "", hlrClaro: "", hlrTigo: "",
        hlrImsi: "", hlrError: ""
    };
}

/* =====================================================================
   3 · ESTADO
===================================================================== */
let filas = [];
let porLinea = new Map();      // línea -> [filas] (una línea puede repetirse)
let cargando = false;      // carga de Genesis en curso
let trabajando = false;    // una tanda de CM o de HLR en curso
let cancelar = false;
let tabla = null;

const vivas = () => filas;
const seleccionadas = () => filas.filter(f => f.sel);

/** Las líneas ÚNICAS de lo marcado: una línea repetida en diez bloqueos se
    consulta una sola vez y el resultado se copia a sus diez filas. */
function lineasSeleccionadas() {
    const s = new Set();
    seleccionadas().forEach(f => { if (f.linea) s.add(f.linea); });
    return Array.from(s);
}

function indexar() {
    porLinea = new Map();
    filas.forEach(f => {
        if (!f.linea) return;
        if (!porLinea.has(f.linea)) porLinea.set(f.linea, []);
        porLinea.get(f.linea).push(f);
    });
}

/* =====================================================================
   4 · CARGA DESDE GENESIS
===================================================================== */
function progreso(texto, pct) {
    const w = MEUI.$("#progresoWrap");
    if (!w) return;
    /* «block», no «»: la hoja de estilos trae `#progresoWrap { display:none }`
       y vaciar el estilo en linea devuelve el control a esa regla, con lo que
       la barra no se mostraba NUNCA. Tiene que ganar el estilo en linea. */
    w.style.display = texto ? "block" : "none";
    if (!texto) return;
    MEUI.$("#progresoTexto").textContent = texto;
    MEUI.$("#progresoPct").textContent = (pct == null ? "" : Math.round(pct) + "%");
    MEUI.$("#progresoBar").style.width = (pct == null ? 0 : Math.max(0, Math.min(100, pct))) + "%";
}

/* Cada cuánto repintar la tabla mientras entra la carga.

   DataTables rehace el conjunto ENTERO en cada repintado, así que el coste
   sube con cada página que llega. La pauta separa dos momentos que sirven
   para cosas distintas:

     · los primeros 2 s, cada 0,5 s → es cuando hay que ver que la cosa
       arrancó y que están entrando datos de verdad;
     · de ahí en adelante, cada 5 s → eso ya se sabe; lo que falta es que
       termine, y repintar seguido solo le quita tiempo a eso.

   Se mide por TIEMPO DE CARGA, no por número de filas: lo que hay que
   cubrir es la incertidumbre de los primeros segundos, y esa no depende de
   cuántos registros traiga el día. */
const PINTADO = { rapido: 500, lento: 5000, cambioMs: 2000 };

function intervaloPintado(msDesdeInicio) {
    return msDesdeInicio < PINTADO.cambioMs ? PINTADO.rapido : PINTADO.lento;
}

async function cargarGenesis() {
    if (cargando) return;
    if (!GENESIS.auth.token) {
        MEUI.toast("Inicia la sesión de Genesis primero.", "warn");
        MEUI.abrirPaso(1, true);
        return;
    }
    cargando = true; cancelar = false;
    MEUI.ocupado("#btnCargar", "Cargando…");
    MEUI.$("#btnCancelar").classList.remove("d-none");

    const t0 = performance.now();
    try {
        MEUI.log("Cargando el log de titularidad de Genesis…", "info");

        // Se empieza de cero: una carga nueva reemplaza lo anterior, no se
        // suma a ello.
        filas = [];
        porLinea = new Map();
        let ultimoPintado = 0;

        const r = await GENESIS.cargarTodo({
            tam: Number(MEUI.$("#cfgPagina").value) || CONFIG.paginaGenesis,
            cancelado: () => cancelar,

            // Cada página se agrega y se pinta: con 200.000 registros, esperar
            // al final son minutos mirando una barra sin ver un solo dato.
            alLote: nuevos => {
                nuevos.forEach(g => {
                    const f = filaDesdeGenesis(g);
                    filas.push(f);
                    if (f.linea) {
                        if (!porLinea.has(f.linea)) porLinea.set(f.linea, []);
                        porLinea.get(f.linea).push(f);
                    }
                });
                const ahora = performance.now();
                if (ahora - ultimoPintado >= intervaloPintado(ahora - t0)) {
                    ultimoPintado = ahora;
                    render();
                }
            },

            alProgresar: p => progreso(
                `Genesis: ${p.leidos.toLocaleString("es-CO")} de ${p.total.toLocaleString("es-CO")} registros `
                + `(página ${p.pagina} de ${p.paginas})`,
                p.total ? (p.leidos / p.total) * 100 : null)
        });

        render();   // el pintado final, ya con todo

        const seg = ((performance.now() - t0) / 1000).toFixed(1);
        if (!r.completo) {
            MEUI.log(`⚠ Carga cancelada: ${filas.length.toLocaleString("es-CO")} de `
                + `${r.total.toLocaleString("es-CO")} registros. Lo que ves está completo hasta ahí.`, "warn");
            MEUI.toast("Carga cancelada; se conserva lo que alcanzó a llegar.", "warn");
        } else if (filas.length < r.total) {
            // Genesis dijo una cuenta y entregó menos: se dice, no se calla.
            MEUI.log(`⚠ Genesis reportó ${r.total.toLocaleString("es-CO")} registros pero entregó `
                + `${filas.length.toLocaleString("es-CO")}. Puede que entraran registros nuevos durante la `
                + `descarga, o que alguna página viniera vacía.`, "warn");
        } else {
            MEUI.log(`✔ ${filas.length.toLocaleString("es-CO")} registros de Genesis en ${seg} s.`, "ok");
        }
    } catch (e) {
        MEUI.log("✖ No se pudo cargar Genesis: " + e.message, "err");
        MEUI.toast("Falló la carga de Genesis. Mira el registro.", "err");
    } finally {
        cargando = false; cancelar = false;
        progreso("");
        MEUI.libre("#btnCargar");
        MEUI.$("#btnCancelar").classList.add("d-none");
    }
}

/* =====================================================================
   5 · ENRIQUECIMIENTO · CM (titular y estado de la línea)
===================================================================== */
function aplicarACadaFila(linea, cambios) {
    (porLinea.get(linea) || []).forEach(f => Object.assign(f, cambios));
}

async function consultarCm() {
    if (trabajando) { MEUI.toast("Espera a que termine la consulta en curso.", "warn"); return; }
    const lineas = lineasSeleccionadas();
    if (!lineas.length) { MEUI.toast("Marca al menos una línea.", "warn"); return; }
    if (lineas.length > CONFIG.maxSeleccion) {
        MEUI.toast(`Son ${lineas.length} líneas; el tope es ${CONFIG.maxSeleccion}. Filtra o marca menos.`, "err");
        return;
    }
    try { await MEAPI.auth.ensure(); }
    catch (e) { MEUI.toast("Inicia la sesión del CM primero.", "err"); MEUI.abrirPaso(1, true); return; }

    trabajando = true;
    cancelar = false;
    MEUI.$("#btnCancelar").classList.remove("d-none");
    lineas.forEach(l => aplicarACadaFila(l, { cmPaso: PASO.CONSULTANDO }));
    render();

    let hechas = 0;
    MEUI.log(`CM: consultando ${lineas.length} línea(s) en tandas de ${CONFIG.concurrenciaCm}.`, "info");

    try {
        await ejecutarPool(lineas, CONFIG.concurrenciaCm, async linea => {
            if (cancelar) { aplicarACadaFila(linea, { cmPaso: PASO.PENDIENTE }); return; }
            try {
                const r = await CMLineas.resolverLinea(linea);
                if (!r) {
                    aplicarACadaFila(linea, {
                        cmPaso: PASO.LISTA, cmEstado: "No existe en el CM",
                        cmTitular: "", cmCuenta: "", cmSim: "", cmError: ""
                    });
                } else {
                    const c = r.elegida;
                    // `resolverLinea` da la línea y su estado, pero no el titular:
                    // ese vive en la cuenta de facturación, que es otra consulta.
                    let titular = "";
                    try {
                        const cc = await CMLineas.cuentaCrm(c.ban);
                        const a = cc && cc.cuenta;
                        if (a) {
                            titular = a.name
                                || [a.givenName, a.familyName].filter(Boolean).join(" ").trim()
                                || "";
                        }
                    } catch (e) { /* el estado de la línea ya sirve; el nombre es un extra */ }

                    aplicarACadaFila(linea, {
                        cmPaso: PASO.LISTA,
                        cmEstado: c.estadoTexto || CMLineas.textoEstadoLinea(c.estado),
                        cmTitular: titular,
                        cmCuenta: c.ban || "",
                        cmSim: c.simId || "",
                        cmError: ""
                    });
                }
            } catch (e) {
                aplicarACadaFila(linea, { cmPaso: PASO.ERROR, cmError: e.message || String(e) });
            }
            hechas++;
            progreso(`CM: ${hechas} de ${lineas.length} línea(s)`, (hechas / lineas.length) * 100);
            if (hechas % 10 === 0 || hechas === lineas.length) render();
        });

    } finally {
        // Pase lo que pase, la herramienta queda utilizable: un flag que se
        // quedara en true dejaría los botones muertos hasta recargar.
        trabajando = false;
        progreso("");
        MEUI.$("#btnCancelar").classList.add("d-none");
        filas.forEach(f => { if (f.cmPaso === PASO.CONSULTANDO) f.cmPaso = PASO.PENDIENTE; });
        render();
    }
    MEUI.log(`CM: ${hechas} línea(s) consultada(s).`, "ok");
}

/* =====================================================================
   6 · ENRIQUECIMIENTO · HLR/HSS (Claro, Tigo, ambos o ninguno)
   ---------------------------------------------------------------------
   Claro NO tiene servicio de lote: su QDN es una petición por línea. Por
   eso «en batch» aquí significa tandas controladas (pool de concurrencia),
   que es lo mismo que hacen el cruce y los validadores. Mil líneas salen
   en tandas, con progreso y sin tumbar el gateway.
===================================================================== */
async function consultarHlr() {
    if (trabajando) { MEUI.toast("Espera a que termine la consulta en curso.", "warn"); return; }
    const lineas = lineasSeleccionadas();
    if (!lineas.length) { MEUI.toast("Marca al menos una línea.", "warn"); return; }
    if (lineas.length > CONFIG.maxSeleccion) {
        MEUI.toast(`Son ${lineas.length} líneas; el tope es ${CONFIG.maxSeleccion}. Filtra o marca menos.`, "err");
        return;
    }

    trabajando = true;
    cancelar = false;
    MEUI.$("#btnCancelar").classList.remove("d-none");
    lineas.forEach(l => aplicarACadaFila(l, { hlrPaso: PASO.CONSULTANDO }));
    render();

    const concurrencia = Math.max(1, Math.min(15,
        Number(MEUI.$("#cfgConcurrencia").value) || CONFIG.concurrenciaHlr));
    MEUI.log(`HLR/HSS: ${lineas.length} línea(s) en tandas de ${concurrencia} `
        + `(cada una consulta Claro y Tigo a la vez).`, "info");

    try {
        await HLRConsulta.consultarVarias(lineas, {
            concurrencia,
            cancelado: () => cancelar,
            alTerminarUna: (r, hechas, total) => {
                aplicarACadaFila(r.msisdn, {
                    hlrPaso: PASO.LISTA,
                    hlrUbicacion: r.etiquetaUbicacion,
                    hlrClaro: r.etiquetaClaro,
                    hlrTigo: r.etiquetaTigo,
                    hlrImsi: r.imsi || "",
                    hlrError: r.ubicacion === "NO_CONCLUYENTE"
                        ? [r.claro && r.claro.mensaje, r.tigo && r.tigo.mensaje].filter(Boolean).join(" · ")
                        : ""
                });
                progreso(`HLR/HSS: ${hechas} de ${total} línea(s)`, (hechas / total) * 100);
                if (hechas % 10 === 0 || hechas === total) render();
            }
        });

    } finally {
        trabajando = false;
        progreso("");
        MEUI.$("#btnCancelar").classList.add("d-none");
        // Lo que quedó marcado como «consultando» es lo que se canceló o lo
        // que se quedó a medias por un error.
        filas.forEach(f => { if (f.hlrPaso === PASO.CONSULTANDO) f.hlrPaso = PASO.PENDIENTE; });
        render();
    }
    MEUI.log("HLR/HSS: consulta terminada.", "ok");
}

/* =====================================================================
   7 · POOL
===================================================================== */
async function ejecutarPool(items, limite, worker) {
    let i = 0;
    const n = Math.max(1, Math.min(limite || 5, items.length || 1));
    await Promise.all(Array.from({ length: n }, async () => {
        while (i < items.length) {
            const idx = i++;
            await worker(items[idx], idx);
        }
    }));
}

/* =====================================================================
   8 · FILTROS
===================================================================== */
const filtros = { operacion: "", resultado: "", canal: "", ubicacion: "", sel: "", texto: "" };

const normaliza = s => String(s || "").toLowerCase()
    .normalize("NFD").replace(/[̀-ͯ]/g, "");

function filaPasaFiltros(f) {
    if (filtros.operacion && f.operacion !== filtros.operacion) return false;
    if (filtros.resultado && f.resultadoTexto !== filtros.resultado) return false;
    if (filtros.canal && f.canal !== filtros.canal) return false;
    if (filtros.ubicacion && (f.hlrUbicacion || "—") !== filtros.ubicacion) return false;
    if (filtros.sel === "marcadas" && !f.sel) return false;
    if (filtros.sel === "sin-marcar" && f.sel) return false;
    if (filtros.texto) {
        const q = normaliza(filtros.texto);
        const heno = normaliza([f.linea, f.documento, f.descripcion, f.cmTitular,
            f.cmCuenta, f.usuario, f.hlrImsi].join(" "));
        if (heno.indexOf(q) < 0) return false;
    }
    return true;
}

/* Filtrar 208.000 filas cuesta entre 7 y 54 ms (medido). Poco, pero la tabla
   pide datos en cada paginada y en cada orden, y repetirlo ahí no aporta
   nada: mientras no cambien ni los datos ni los filtros, el resultado es el
   mismo. Se invalida en `render()`, que es por donde pasa todo cambio. */
let _visibles = null;
let _ordenadas = null;      // las mismas, ya ordenadas; clave: "columna:sentido"
let _ordenClave = null;

function invalidarVistas() { _visibles = null; _ordenadas = null; _ordenClave = null; }

function visibles() {
    if (!_visibles) _visibles = filas.filter(filaPasaFiltros);
    return _visibles;
}

/* =====================================================================
   9 · TABLA
===================================================================== */
const esc = s => MEUI.esc(s);
const badge = (t, c) => `<span class="badge-estado ${c || "neutro"}">${esc(t || "—")}</span>`;

const CLASE_UBICACION = {
    "Claro": "info", "Tigo": "ok", "Ambos — revisar": "warn",
    "Residuo en Tigo (escalar)": "warn", "Claro + residuo en Tigo": "warn",
    "Ninguno": "off", "No concluyente": "err"
};
const CLASE_ESTADO_CM = {
    "Activa": "ok", "Bloqueada": "err", "Inactiva": "off",
    "Disponible": "info", "No existe en el CM": "warn"
};

function celdaPaso(paso, error) {
    if (paso === PASO.PENDIENTE) return '<span class="paso-pend">—</span>';
    if (paso === PASO.CONSULTANDO) return badge("Consultando", "info");
    if (paso === PASO.ERROR) return `<span title="${esc(error)}">${badge("Error", "err")}</span>`;
    return "";
}

/* Las columnas se declaran aparte porque ahora hacen DOS cosas: pintar, y
   decirle al ordenador por qué campo ordenar cuando el analista hace clic en
   una cabecera (la tabla manda el índice de la columna, no el nombre). */
const COLUMNAS = [
    {
        title: '<input type="checkbox" id="chkTodas" title="Marcar lo visible">',
        data: null, orderable: false, width: "28px",
        render: f => `<input type="checkbox" class="chk-fila" data-id="${esc(f.__id)}"${f.sel ? " checked" : ""}>`
    },
    { title: "Línea", data: "linea", render: l => `<span class="me-mono">${esc(l)}</span>` },
    { title: "HLR/HSS", data: "hlrUbicacion", render: (v, t, f) => v ? badge(v, CLASE_UBICACION[v]) : celdaPaso(f.hlrPaso, f.hlrError) },
    { title: "Estado línea (CM)", data: "cmEstado", render: (v, t, f) => v ? badge(v, CLASE_ESTADO_CM[v]) : celdaPaso(f.cmPaso, f.cmError) },
    { title: "Claro", data: "hlrClaro", render: v => esc(v || "—") },
    { title: "Tigo", data: "hlrTigo", render: v => esc(v || "—") },
    { title: "Titular (CM)", data: "cmTitular", render: v => esc(v || "—") },
    { title: "Documento", data: "documento", render: v => `<span class="me-mono">${esc(v)}</span>` },
    { title: "Cuenta (BAN)", data: "cmCuenta", render: v => `<span class="me-mono">${esc(v || "—")}</span>` },
    { title: "Operación", data: "operacion", render: v => badge(v, v === "Bloqueo" ? "err" : "ok") },
    { title: "Resultado", data: "resultadoTexto", render: (v, t, f) => badge(v, infoResultado(f.resultado).clase) },
    { title: "Fecha", data: "fecha", render: v => `<span class="me-mono">${esc(String(v).replace("T", " ").slice(0, 19))}</span>` },
    { title: "Canal", data: "canal", render: v => esc(v || "—") },
    { title: "Usuario", data: "usuario", render: v => esc(v || "—") },
    { title: "Descripción", data: "descripcion", render: v => `<span class="desc" title="${esc(v)}">${esc(v)}</span>` },
    { title: "ID", data: "id", render: v => `<span class="me-mono">${esc(v)}</span>` }
];

/* =====================================================================
   9b · DE DÓNDE SACA LA TABLA SUS FILAS
   ---------------------------------------------------------------------
   DataTables va en modo `serverSide`, pero el «servidor» es este arreglo
   en memoria. La diferencia con dárselo entero no es de estilo, está
   medida en este mismo navegador:

     208.249 filas dentro de DataTables   un repintado cuesta 2.979 ms
                                          y el heap sube a ~242 MB
     208.249 filas en un arreglo plano    48 MB · filtrar 7 ms ·
                                          ordenar 26 ms · sacar 50 filas 0 ms

   Es decir: los datos no pesan; pesaba metérselos a la tabla. Así la tabla
   solo tiene nunca más de una página —las 50 filas que se ven— y filtrar,
   ordenar y paginar lo hacemos nosotros sobre el arreglo.
===================================================================== */
function ordenadas(orden) {
    const col = COLUMNAS[orden && orden.column];
    const campo = col && col.data;
    const clave = campo ? `${campo}:${orden.dir}` : "";
    if (_ordenadas && _ordenClave === clave) return _ordenadas;

    const base = visibles();
    if (!campo) {                    // sin orden: como vino de Genesis
        _ordenadas = base; _ordenClave = ""; return _ordenadas;
    }
    const signo = orden.dir === "desc" ? -1 : 1;
    // Se ordena una COPIA: `visibles()` se reusa para las tarjetas y la
    // exportación, y no debe quedar reordenado por detrás.
    _ordenadas = base.slice().sort((a, b) => {
        const x = a[campo], y = b[campo];
        if (typeof x === "number" && typeof y === "number") return (x - y) * signo;
        return String(x == null ? "" : x).localeCompare(String(y == null ? "" : y), "es") * signo;
    });
    _ordenClave = clave;
    return _ordenadas;
}

/** Lo que DataTables llama «ajax»: aquí no sale ninguna petición. */
function fuenteDatos(peticion, responder) {
    // La tabla trae su propio buscador; se suma al de la barra de filtros en
    // vez de competir con él (los dos acotan, no se pisan).
    const suyo = (peticion.search && peticion.search.value || "").trim();
    const previo = filtros.texto;
    if (suyo) filtros.texto = previo ? previo + " " + suyo : suyo;
    if (suyo) invalidarVistas();

    const orden = (peticion.order && peticion.order[0]) || null;
    const lista = ordenadas(orden);
    const desde = peticion.start || 0;
    const cuantas = peticion.length > 0 ? peticion.length : lista.length;

    if (suyo) { filtros.texto = previo; invalidarVistas(); }

    responder({
        draw: peticion.draw,
        recordsTotal: filas.length,
        recordsFiltered: lista.length,
        data: lista.slice(desde, desde + cuantas)
    });
}

function construirTabla() {
    tabla = new DataTable("#tablaTitularidad", MEUI.opcionesTabla({
        serverSide: true,
        ajax: fuenteDatos,
        processing: true,        // «Procesando…» de la propia tabla
        orderClasses: false,
        pageLength: 50,
        lengthMenu: [25, 50, 100, 250],
        order: [],
        columns: COLUMNAS
    }));
    if (MEUI.registrarTabla) MEUI.registrarTabla(tabla);

    // Marcar/desmarcar: delegado, porque DataTables redibuja las filas.
    document.querySelector("#tablaTitularidad").addEventListener("change", ev => {
        const c = ev.target.closest(".chk-fila");
        if (!c) return;
        const f = filas.find(x => String(x.__id) === c.dataset.id);
        if (f) { f.sel = c.checked; actualizarResumenSeleccion(); }
    });
    const todas = document.getElementById("chkTodas");
    if (todas) todas.addEventListener("change", () => marcarVisibles(todas.checked));
}

/** Marca o desmarca lo que pasa los filtros, no la página visible: el
    analista filtra y marca «todas» esperando eso. */
function marcarVisibles(valor) {
    visibles().forEach(f => { f.sel = !!valor; });
    render();
}

function actualizarResumenSeleccion() {
    const n = seleccionadas().length;
    const l = lineasSeleccionadas().length;
    const el = MEUI.$("#resumenSeleccion");
    if (el) {
        el.textContent = n
            ? `${n.toLocaleString("es-CO")} fila(s) · ${l.toLocaleString("es-CO")} línea(s) única(s)`
            : "Nada marcado";
    }
    ["btnConsultarCm", "btnConsultarHlr"].forEach(id => {
        const b = MEUI.$("#" + id);
        // Un botón con spinner (MEUI.ocupado) se queda deshabilitado hasta
        // que termine. Sin esto, el repintado de mitad de tanda lo volvía a
        // habilitar y se podía lanzar una segunda consulta encima.
        if (b && !b.dataset.meOcupado) b.disabled = n === 0;
    });
}

function render() {
    // Todo cambio de datos o de filtros pasa por aquí, así que es el punto
    // donde las vistas memorizadas dejan de valer.
    invalidarVistas();
    if (!tabla) construirTabla();
    // `draw` le pide los datos a `fuenteDatos`: no se le entrega el arreglo.
    tabla.draw(false);
    actualizarKpis();
    actualizarResumenSeleccion();
    refrescarOpcionesFiltros();
    MEUI.mostrarSiHayDatos("#tablaTitularidad", { vacio: "#msgVacio", tabla });
    MEUI.resumenPaso(2, filas.length ? `${filas.length.toLocaleString("es-CO")} registros` : "");
    if (MEUI.ajustarTablas) MEUI.ajustarTablas();
}

/* =====================================================================
   10 · TARJETAS
===================================================================== */
function actualizarKpis() {
    const v = visibles();
    const cuenta = p => v.filter(p).length;
    const set = (id, n) => { const e = MEUI.$("#" + id); if (e) e.textContent = n.toLocaleString("es-CO"); };
    set("kpiTotal", v.length);
    set("kpiLineas", new Set(v.map(f => f.linea).filter(Boolean)).size);
    set("kpiBloqueos", cuenta(f => f.operacion === "Bloqueo"));
    set("kpiRevisar", cuenta(f => f.hlrUbicacion === "Ambos — revisar" || f.hlrUbicacion === "No concluyente"));
}

function refrescarOpcionesFiltros() {
    const llenar = (sel, campo, vacio) => {
        const s = MEUI.$(sel);
        if (!s) return;
        const actual = s.value;
        const valores = [...new Set(filas.map(f => f[campo]).filter(x => x != null && x !== ""))].sort();
        s.innerHTML = `<option value="">${vacio}</option>`
            + valores.map(x => `<option value="${esc(x)}"${x === actual ? " selected" : ""}>${esc(x)}</option>`).join("");
    };
    llenar("#fOperacion", "operacion", "Operación: todas");
    llenar("#fResultado", "resultadoTexto", "Resultado: todos");
    llenar("#fCanal", "canal", "Canal: todos");
    llenar("#fUbicacion", "hlrUbicacion", "HLR/HSS: todos");
}

/* =====================================================================
   11 · EXPORTACIÓN
   Lo que se exporta es lo que se ve: mismos filtros, mismo orden.
===================================================================== */
const CABECERA = ["Línea", "HLR/HSS", "Claro", "Tigo", "IMSI",
    "Estado línea (CM)", "Titular (CM)", "Cuenta (BAN)", "SIM (CM)", "Documento (Genesis)",
    "Operación", "Resultado", "Descripción", "Fecha", "Canal", "Usuario", "ID Genesis"];

const filaExport = f => [f.linea, f.hlrUbicacion || "", f.hlrClaro || "", f.hlrTigo || "", f.hlrImsi || "",
    f.cmEstado || "", f.cmTitular || "", f.cmCuenta || "", f.cmSim || "", f.documento,
    f.operacion, f.resultadoTexto, f.descripcion,
    String(f.fecha).replace("T", " ").slice(0, 19), f.canal, f.usuario, f.id];

function filasExport() { return { head: CABECERA, rows: visibles().map(filaExport) }; }
function filasParaExportar() { return visibles(); }

/* =====================================================================
   12 · DETALLE DE UNA FILA
   El SOAP crudo no se guarda en memoria (ver genesis-api.js): se vuelve a
   pedir la página de ese id cuando alguien lo abre.
===================================================================== */
async function verDetalle(id) {
    const f = filas.find(x => String(x.__id) === String(id));
    if (!f) return;
    MEUI.$("#mdLinea").textContent = f.linea;
    MEUI.$("#mdResumen").innerHTML = `
        <dl class="dl-grid">
          <dt>Operación</dt><dd>${esc(f.operacion)}</dd>
          <dt>Resultado</dt><dd>${esc(f.resultadoTexto)}</dd>
          <dt>Descripción</dt><dd>${esc(f.descripcion || "—")}</dd>
          <dt>Fecha</dt><dd>${esc(String(f.fecha).replace("T", " ").slice(0, 19))}</dd>
          <dt>Documento (Genesis)</dt><dd>${esc(f.documento || "—")}</dd>
          <dt>Canal · Usuario</dt><dd>${esc(f.canal || "—")} · ${esc(f.usuario || "—")}</dd>
          <dt>HLR/HSS</dt><dd>${esc(f.hlrUbicacion || "sin consultar")}</dd>
          <dt>Estado en el CM</dt><dd>${esc(f.cmEstado || "sin consultar")}</dd>
        </dl>`;
    MEUI.$("#mdCrudo").textContent = "Pidiendo el detalle a Genesis…";
    new bootstrap.Modal("#modalDetalle").show();
    try {
            const d = await GENESIS.detalleDe(f.id, Number(MEUI.$("#cfgPagina").value) || CONFIG.paginaGenesis);
            MEUI.$("#mdCrudo").textContent = d
                ? `--- request ---\n${d.request || "(vacío)"}\n\n--- response ---\n${d.response || "(vacío)"}`
                : "Genesis ya no devuelve ese registro en la página esperada.";
        } catch (e) {
            MEUI.$("#mdCrudo").textContent = "No se pudo traer el detalle: " + e.message;
        }
    }

    /* =====================================================================
       13 · LO QUE USA EL PUENTE
    ===================================================================== */

    /** Corta la carga de Genesis o una tanda de consultas, entre elementos.
        No aborta la petición en vuelo: deja terminar la que ya salió y no
        manda más. Lo que ya llegó se conserva. */
    function cancelarTrabajo() { cancelar = true; }

    function fijarFiltro(campo, valor) {
        if (!(campo in filtros)) return;
        filtros[campo] = valor || "";
        render();
    }

    function limpiarFiltros() {
        Object.keys(filtros).forEach(k => { filtros[k] = ""; });
        render();
    }

    /* =====================================================================
       14 · ARRANQUE
    ===================================================================== */
    function inicializarTitularidad() {
        render();   // deja la tabla montada y el mensaje de «sin datos» a la vista
    }
    inicializarTitularidad();
