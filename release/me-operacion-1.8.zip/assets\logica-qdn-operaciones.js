/* =====================================================================
   logica-qdn-operaciones.js · Operaciones de provisión sobre la línea
   ---------------------------------------------------------------------
   El validador QDN era de SOLO LECTURA. Aquí se agregan las operaciones
   que ESCRIBEN en la red de Claro: bloqueos, desbloqueos y conciliación.

   Todo sale de `interfaz.py` (consola de líneas), que es la referencia
   viva de estos servicios:

     · endpoint  PATCH {base_apigw}/APIMParOrdeProvision/.../ModifingService
     · payloads  process / action / level / relatedParty / tier / msisdn /
                 imsi / iccid / ki / features
     · reglas    `features` NUNCA viaja como "" (vacío -> " ");
                 el éxito real NO es el HTTP 200, se evalúa el cuerpo.

   Se carga DESPUÉS de logica-qdn.js y reusa lo que ya vive allí:
   `gestorQdn` (mismo OAuth2), `cfgQdn`, `evaluarNegocio()`, `filas`,
   `filaPasaFiltros()`, `consultarConReintentos()`, `ejecutarPool()` y
   `render()`. No duplica ni el token ni el parseo.

   POR QUÉ LA DOBLE CONFIRMACIÓN
   Estas llamadas afectan líneas REALES en PRODUCCIÓN y no se deshacen
   solas. Bloquear y conciliar piden dos pasos (revisar -> "seguro?");
   desbloquear pide uno. En masivo se listan TODAS las líneas antes de
   ejecutar. Cada ejecución queda con el usuario que la hizo en la
   bitácora, el registro y la exportación.
===================================================================== */

/* ---------------------------------------------------------------------
   1 · ENDPOINT Y CONSTANTES (mismos valores que interfaz.py)
--------------------------------------------------------------------- */
const RUTA_MODIFYING = "/APIMParOrdeProvision/MSParOrdeProvision/SVC/Service/RSParOrdeProvision/V1/ModifingService";
const RELATED_PARTY = [{ id: "EXITO", role: "ServiceProvider", name: "MOVIL EXITO" }];
const TIER_OPERACION = "prepaid";
const NIVEL_LOCKALL = "2";
const CONCURRENCIA_OPERACION = 3;   // más bajo que en consulta: son escrituras

/**
 * `features` no admite cadena vacía: el servicio la rechaza. Vacío -> " ".
 * Varios valores se separan con pipe. Misma regla que normalizar_features().
 */
function normalizarFeatures(texto) {
    const partes = String(texto === null || texto === undefined ? "" : texto)
        .split("|").map(p => p.trim()).filter(Boolean);
    return partes.length ? partes.join("|") : " ";
}

/* ---------------------------------------------------------------------
   2 · CATÁLOGO DE OPERACIONES
   ---------------------------------------------------------------------
   `tipo` decide cuánta fricción pide la interfaz:
     bloqueo / conciliacion -> doble confirmación (revisar + "seguro?")
     desbloqueo             -> confirmación simple
   Desactivar roaming es una restricción, así que cuenta como bloqueo.
--------------------------------------------------------------------- */
const OPERACIONES = [
    { id: "lockall", grupo: "Bloqueo total", etiqueta: "Bloqueo TOTAL de la línea", tipo: "bloqueo", proceso: "lockall" },
    { id: "unlockall", grupo: "Bloqueo total", etiqueta: "Desbloqueo TOTAL de la línea", tipo: "desbloqueo", proceso: "unlockall" },

    { id: "blqinccl_on", grupo: "Bloqueos individuales", etiqueta: "Bloquear llamada ENTRANTE", tipo: "bloqueo", proceso: "blqinccl", accion: "activate" },
    { id: "blqinccl_off", grupo: "Bloqueos individuales", etiqueta: "Desbloquear llamada ENTRANTE", tipo: "desbloqueo", proceso: "blqinccl", accion: "deactivate" },
    { id: "blqoutcl_on", grupo: "Bloqueos individuales", etiqueta: "Bloquear llamada SALIENTE", tipo: "bloqueo", proceso: "blqoutcl", accion: "activate" },
    { id: "blqoutcl_off", grupo: "Bloqueos individuales", etiqueta: "Desbloquear llamada SALIENTE", tipo: "desbloqueo", proceso: "blqoutcl", accion: "deactivate" },
    { id: "blqincsms_on", grupo: "Bloqueos individuales", etiqueta: "Bloquear SMS ENTRANTE", tipo: "bloqueo", proceso: "blqincsms", accion: "activate" },
    { id: "blqincsms_off", grupo: "Bloqueos individuales", etiqueta: "Desbloquear SMS ENTRANTE", tipo: "desbloqueo", proceso: "blqincsms", accion: "deactivate" },
    { id: "blqoutsms_on", grupo: "Bloqueos individuales", etiqueta: "Bloquear SMS SALIENTE", tipo: "bloqueo", proceso: "blqoutsms", accion: "activate" },
    { id: "blqoutsms_off", grupo: "Bloqueos individuales", etiqueta: "Desbloquear SMS SALIENTE", tipo: "desbloqueo", proceso: "blqoutsms", accion: "deactivate" },
    { id: "blqldi_on", grupo: "Bloqueos individuales", etiqueta: "Bloquear larga distancia (LDI)", tipo: "bloqueo", proceso: "blqldi", accion: "activate" },
    { id: "blqldi_off", grupo: "Bloqueos individuales", etiqueta: "Desbloquear larga distancia (LDI)", tipo: "desbloqueo", proceso: "blqldi", accion: "deactivate" },

    // La colección manda features="roaming" en estas dos (no el valor general).
    { id: "roaming_on", grupo: "Roaming", etiqueta: "Activar ROAMING", tipo: "desbloqueo", proceso: "roaming", accion: "activate", features: "roaming" },
    { id: "roaming_off", grupo: "Roaming", etiqueta: "Desactivar ROAMING", tipo: "bloqueo", proceso: "roaming", accion: "deactivate", features: "roaming" },

    { id: "conciliation", grupo: "Procesos", etiqueta: "Conciliación de línea", tipo: "conciliacion", proceso: "conciliation" },

    // "riesgo_alto": cambia identificadores propios de la línea (IMSI/ICCID/
    // KI, o el MSISDN). A diferencia de las demás, el valor NUEVO no puede
    // salir del QDN ni de un archivo -nadie más que el analista sabe cuál
    // es el IMSI/MSISDN nuevo-, así que siempre se escribe a mano, línea
    // por línea. Por eso quedan FUERA del menú de operaciones masivas (ver
    // GRUPOS_MASIVO): aplicar el mismo IMSI o MSISDN nuevo a varias líneas
    // de una sola vez sería un error, no una operación válida.
    { id: "change_imsi", grupo: "Riesgo alto", etiqueta: "Cambio de SIM (IMSI / ICCID / KI)", tipo: "riesgo_alto", proceso: "change_imsi" },
    { id: "change_msisdn", grupo: "Riesgo alto", etiqueta: "Cambio de MSISDN", tipo: "riesgo_alto", proceso: "change_msisdn" }
];

const GRUPOS_OPERACION = ["Bloqueo total", "Bloqueos individuales", "Roaming", "Procesos", "Riesgo alto"];
// Grupos que SÍ se ofrecen en el menú de operaciones MASIVAS de la barra de
// filtros. "Riesgo alto" se excluye ahí a propósito (ver el comentario de
// OPERACIONES) y solo se ofrece dentro del modal de una línea individual.
const GRUPOS_MASIVO = GRUPOS_OPERACION.filter(g => g !== "Riesgo alto");
const operacionPorId = id => OPERACIONES.find(o => o.id === id) || null;
const pideDobleConfirmacion = op => op.tipo === "bloqueo" || op.tipo === "conciliacion" || op.tipo === "riesgo_alto";

/* ---------------------------------------------------------------------
   3 · DATOS DE LA LÍNEA (IMSI / ICCID / KI) Y DE DÓNDE SALEN
   ---------------------------------------------------------------------
   El PATCH necesita el IMSI; la conciliación además el ICCID. Hay cuatro
   orígenes posibles, y el que se use SIEMPRE se muestra en pantalla para
   que nadie envíe un dato creyendo que lo dijo el HLR:

     1. manual    lo escribió el analista en el modal de la operación
     2. archivo   columna opcional imsi / iccid / ki del Excel o CSV
     3. QDN       lo devolvió la consulta (UDC_PRSSIMCD-imsi, COTA_…-iccid)
     4. derivado  ICCID = 8957 + IMSI (regla del operador; solo si falta)

   Manual gana sobre archivo, y archivo sobre QDN: si alguien se tomó el
   trabajo de escribirlo o cargarlo, no se le sobreescribe en silencio.
   La KI no la devuelve el QDN nunca: o viene del archivo, o se escribe,
   o va vacía (el servicio la acepta así).
--------------------------------------------------------------------- */
const SIN_DATO = new Set(["—", "", "No Registra", null, undefined]);
const PREFIJO_ICCID = "8957";
const LARGO_IMSI = 15;

function valorQdn(f, campo) {
    const v = f && f.resumen ? f.resumen[campo] : null;
    return SIN_DATO.has(v) ? "" : String(v).trim();
}

/** ICCID = 8957 + IMSI (p. ej. 732157001050037 -> 8957732157001050037). */
function iccidDesdeImsi(imsi) {
    const d = String(imsi || "").replace(/\D/g, "");
    return d.length === LARGO_IMSI ? PREFIJO_ICCID + d : "";
}

/** Correcciones escritas a mano en el modal: msisdn -> {imsi, iccid, ki}. */
const datosManuales = new Map();

/**
 * Resuelve los tres campos con su procedencia.
 * Devuelve { imsi:{valor,origen}, iccid:{…}, ki:{…} }.
 */
function datosOperacion(f) {
    const manual = datosManuales.get(f.msisdn) || {};
    const archivo = (typeof datosArchivo !== "undefined" && datosArchivo.get(f.msisdn)) || {};
    const elegir = (campo, origenQdn) => {
        if (manual[campo]) return { valor: manual[campo], origen: "manual" };
        if (archivo[campo]) return { valor: archivo[campo], origen: "archivo" };
        const qdn = origenQdn ? valorQdn(f, campo) : "";
        if (qdn) return { valor: qdn, origen: "QDN" };
        return { valor: "", origen: "" };
    };

    const imsi = elegir("imsi", true);
    const iccid = elegir("iccid", true);
    if (!iccid.valor && imsi.valor) {
        const derivado = iccidDesdeImsi(imsi.valor);
        if (derivado) { iccid.valor = derivado; iccid.origen = "derivado 8957+IMSI"; }
    }
    // La KI no existe en el QDN: solo manual o archivo.
    const ki = elegir("ki", false);

    return { imsi, iccid, ki };
}

/** Compatibilidad con el resto del archivo: solo el valor resuelto. */
function datoLinea(f, campo) {
    const d = datosOperacion(f)[campo];
    return d ? d.valor : "";
}

/** Campos que la operación exige. La KI nunca es obligatoria. */
function camposRequeridos(op) {
    if (!op) return ["imsi"];
    if (op.proceso === "conciliation") return ["imsi", "iccid"];
    // change_imsi / change_msisdn: como es un PATCH, no hace falta traer
    // todos los datos -solo el valor NUEVO del campo que de verdad cambia-.
    if (op.proceso === "change_imsi") return ["imsi_new"];
    if (op.proceso === "change_msisdn") return ["msisdn_new"];
    return ["imsi"];
}

/* ---------------------------------------------------------------------
   3b · VALORES "NUEVOS" (change_imsi / change_msisdn) Y FEATURES DINÁMICOS
   ---------------------------------------------------------------------
   Los valores NUEVOS (imsi_new, iccid_new, ki_new, msisdn_new,
   portation_status) nunca salen del QDN ni de un archivo: nadie más que
   el analista sabe cuál es el dato nuevo, así que SIEMPRE se escriben a
   mano. Se guardan en el mismo `datosManuales` que ya usan imsi/iccid/ki
   (una entrada más por MSISDN, mismo mapa).

   `features` también se vuelve editable aquí para TODAS las operaciones,
   no solo las de riesgo alto: si la línea ya tiene bloqueos activos y se
   ejecuta OTRA operación sin decirle al servicio cuáles son, el riesgo es
   que esos bloqueos se pierdan sin que nadie lo pidiera. Se detectan los
   que se pueden traducir con confianza al nombre de "process" que espera
   el PATCH, se listan aparte los que no, y el campo queda editable para
   que el analista corrija o complete.
--------------------------------------------------------------------- */

/** Valor "nuevo" (o de features/nota) escrito a mano para esta línea. */
function valorNuevo(msisdn, campo) {
    const m = datosManuales.get(msisdn) || {};
    return m[campo] || "";
}
function escribirValorNuevo(msisdn, campo, valor) {
    const previo = datosManuales.get(msisdn) || {};
    if (valor) previo[campo] = valor; else delete previo[campo];
    datosManuales.set(msisdn, previo);
}

/** Un ICCID que no empieza por 8957: se avisa, NUNCA se corrige solo. */
function iccidSospechoso(iccid) {
    const d = String(iccid || "").replace(/\D/g, "");
    return d.length > 0 && d.slice(0, PREFIJO_ICCID.length) !== PREFIJO_ICCID;
}

// Nombre de característica QDN (ver CATALOGO_BLOQUEOS en logica-qdn.js) ->
// "process" del catálogo de OPERACIONES. Solo las que se pueden traducir
// con confianza: por ejemplo "SMS" a secas (UDC_BRRSMS-status /
// UDC_SRVSMSFL-status) no dice si es entrante o saliente -blqincsms y
// blqoutsms son procesos DISTINTOS-, así que esa no se traduce sola: se
// avisa en `sinTraducir` para que el analista decida.
const BLOQUEO_A_PROCESO = {
    "UDC_BLQINCLL-status": "blqinccl",
    "UDC_BLQOUTCL-status": "blqoutcl",
    "UDC_SRVROAM-odbBaroam": "roaming",
    "UDC_SRVROAM-odbr": "roaming",
    // Solo se traduce el LDI "total" (osb4, en sus dos variantes de nombre):
    // es el que representa la restricción general de larga distancia. Los
    // más granulares del catálogo (LDI otros indicativos/osb1, LDI 444/
    // Infracel/osb2, LDI sin implementación de red/osb3) NO se traducen
    // solos a "blqldi" -no hay certeza de que equivalgan al mismo proceso-;
    // si están activos quedan en `sinTraducir` para que el analista decida.
    "UDC_BRRLDIFL-osb4": "blqldi",
    "UDC_SRVLDIFL-osb4": "blqldi"
};

/**
 * Bloqueos activos de la línea, traducidos a la lista de "features" que
 * espera el PATCH (separados por "|"). Lo que no se puede traducir con
 * confianza queda en `sinTraducir` -se avisa, no se adivina-.
 */
function featuresDeBloqueos(f) {
    const activos = f.bloqueosActivos || [];
    const procesos = new Set(), sinTraducir = [];
    activos.forEach(b => {
        const p = BLOQUEO_A_PROCESO[b.name];
        if (p) procesos.add(p); else sinTraducir.push(b.etiqueta || b.name);
    });
    return { texto: [...procesos].join("|"), sinTraducir };
}

/**
 * `features` resuelto para el PATCH de esta línea: lo que haya escrito el
 * analista a mano, o -si no ha tocado nada- lo detectado de los bloqueos
 * activos. Vacío de verdad (sin bloqueos, nadie escribió nada) se manda
 * como " " más abajo, vía normalizarFeatures().
 */
function featuresResueltos(f) {
    const manual = valorNuevo(f.msisdn, "features");
    if (manual) return { valor: manual, origen: "manual", sinTraducir: [] };
    const det = featuresDeBloqueos(f);
    return {
        valor: det.texto,
        origen: det.texto ? "detectado de los bloqueos activos" : (f.estadoProceso ? "sin bloqueos detectados" : ""),
        sinTraducir: det.sinTraducir
    };
}

/**
 * Datos de "antes" y "después" para change_imsi / change_msisdn: el valor
 * actual (de datosOperacion) + el nuevo (manual) + el ICCID nuevo derivado
 * de 8957+IMSI-nuevo si no se escribió uno -mismo criterio que el ICCID
 * actual-, y los avisos de ICCID que no empieza por 8957 (se muestran,
 * nunca se corrigen solos).
 */
function datosCambio(f, op) {
    const actual = datosOperacion(f);
    const avisos = [];
    if (actual.iccid.valor && iccidSospechoso(actual.iccid.valor)) {
        avisos.push(`El ICCID actual (${actual.iccid.valor}) no empieza por ${PREFIJO_ICCID}: revísalo antes de continuar. No se modifica solo.`);
    }

    const salida = { avisos, actual };

    if (op.proceso === "change_imsi") {
        const imsiNew = valorNuevo(f.msisdn, "imsi_new");
        let iccidNew = valorNuevo(f.msisdn, "iccid_new");
        let iccidNewOrigen = iccidNew ? "manual" : "";
        if (!iccidNew && imsiNew) {
            const derivado = iccidDesdeImsi(imsiNew);
            if (derivado) { iccidNew = derivado; iccidNewOrigen = "derivado 8957+IMSI nuevo"; }
        }
        if (iccidNew && iccidNewOrigen === "manual" && iccidSospechoso(iccidNew)) {
            avisos.push(`El ICCID nuevo (${iccidNew}) no empieza por ${PREFIJO_ICCID}: revísalo antes de continuar. No se modifica solo.`);
        }
        salida.imsi_new = imsiNew;
        salida.iccid_new = { valor: iccidNew, origen: iccidNewOrigen };
        salida.ki_new = valorNuevo(f.msisdn, "ki_new");
    }

    if (op.proceso === "change_msisdn") {
        salida.msisdn_new = valorNuevo(f.msisdn, "msisdn_new");
        // Valor visto en el único ejemplo real disponible ("0"); sin
        // documentación propia del campo, se deja editable y con ese
        // valor de partida en vez de imponerlo sin poder cambiarlo.
        salida.portation_status = valorNuevo(f.msisdn, "portation_status") || "0";
    }

    return salida;
}

/**
 * Motivo por el que una línea NO se puede operar ni pidiendo datos, o ""
 * si es operable (aunque haya que completar campos a mano).
 */
function motivoNoOperable(f, op) {
    if (f.estadoProceso !== "SUCCESS" && f.estadoProceso !== "INCONSISTENTE") {
        return "la consulta QDN no devolvió un resultado utilizable";
    }
    if (f.estadoProceso === "INCONSISTENTE") {
        return "la respuesta QDN quedó marcada como inconsistente";
    }
    return "";
}

/** Campos obligatorios que todavía están vacíos para esta línea. */
function faltantesDe(f, op) {
    if (op.proceso === "change_imsi") return valorNuevo(f.msisdn, "imsi_new") ? [] : ["imsi_new"];
    if (op.proceso === "change_msisdn") return valorNuevo(f.msisdn, "msisdn_new") ? [] : ["msisdn_new"];
    const datos = datosOperacion(f);
    return camposRequeridos(op).filter(c => !datos[c].valor);
}

// Nota libre de ESTA confirmación (una sola caja de texto para todo el
// lote, no una por línea: es el motivo de la operación, no un dato propio
// de cada MSISDN). Se reinicia cada vez que se abre una confirmación nueva.
let notaLibreActual = "";

/**
 * Nota que viaja en el PATCH: SIEMPRE lleva el usuario que ejecuta (mismo
 * criterio que la bitácora), y opcionalmente lo que el analista haya
 * escrito, separado por ". " -mismo formato del ejemplo real
 * ("usuario. Se realiza cambio de línea por x o y motivo")-.
 */
function notaOperacion() {
    const usuario = usuarioOperador();
    return notaLibreActual ? `${usuario}. ${notaLibreActual}` : usuario;
}

/** Cuerpo del PATCH, con la misma forma exacta que arma interfaz.py. */
function payloadOperacion(op, f) {
    const datos = datosOperacion(f);
    const cuerpo = { process: op.proceso };
    if (op.proceso === "lockall") cuerpo.level = NIVEL_LOCKALL;
    if (op.accion) cuerpo.action = op.accion;
    cuerpo.relatedParty = RELATED_PARTY;
    cuerpo.tier = TIER_OPERACION;
    cuerpo.msisdn = f.msisdn;

    if (op.proceso === "change_imsi") {
        // PATCH parcial: el ICCID/KI nuevos solo se mandan si el analista
        // los diligenció (o se derivó el ICCID del IMSI nuevo) — "no es
        // necesario ingresar todos los datos".
        const cambio = datosCambio(f, op);
        cuerpo.imsi = datos.imsi.valor;
        cuerpo.imsi_new = cambio.imsi_new;
        if (cambio.iccid_new.valor) { cuerpo.iccid = datos.iccid.valor; cuerpo.iccid_new = cambio.iccid_new.valor; }
        if (cambio.ki_new) { cuerpo.ki = datos.ki.valor; cuerpo.ki_new = cambio.ki_new; }
    } else if (op.proceso === "change_msisdn") {
        const cambio = datosCambio(f, op);
        cuerpo.msisdn_new = cambio.msisdn_new;
        cuerpo.imsi = datos.imsi.valor;
        cuerpo.portation_status = cambio.portation_status;
    } else {
        cuerpo.imsi = datos.imsi.valor;
        if (op.proceso === "conciliation") {
            cuerpo.iccid = datos.iccid.valor;
            cuerpo.ki = datos.ki.valor;   // vacía si nadie la aportó: el servicio la acepta
        }
    }

    // `op.features` es un override fijo del CATÁLOGO (solo lo usan hoy
    // roaming_on/roaming_off, que siempre mandan features="roaming"); para
    // todo lo demás se usa el valor dinámico de esta línea -detectado de
    // sus bloqueos activos, o editado a mano-, para no perderlos al
    // ejecutar una operación que no es sobre ellos.
    cuerpo.features = normalizarFeatures(op.features || featuresResueltos(f).valor);
    cuerpo.note = notaOperacion();
    return cuerpo;
}

/* ---------------------------------------------------------------------
   4 · QUIÉN EJECUTA (para la bitácora)
   ---------------------------------------------------------------------
   El token de QDN es de servicio (client_credentials MOVILEXITO): no
   identifica a nadie. La persona sale de la sesión que dejó el lanzador,
   CM (Keycloak) o SIME.
--------------------------------------------------------------------- */
function usuarioOperador() {
    const nombres = [];
    // Solo el nombre de usuario -sin "(CM)"/"(SIME)"-: lo que importa aquí
    // es quién ejecutó, no de qué sesión salió el dato. Si CM y SIME dejaron
    // el mismo usuario (lo normal), no se repite.
    ["cm", "sime"].forEach(clave => {
        const st = MEUI.sesion.estado(clave);
        if (st && st.usuario && nombres.indexOf(st.usuario) < 0) nombres.push(st.usuario);
    });
    return nombres.length ? nombres.join(" · ") : "sin sesión identificada";
}

/* ---------------------------------------------------------------------
   5 · BITÁCORA
   ---------------------------------------------------------------------
   Queda EN LA HERRAMIENTA, no en el payload: el servicio de provisión no
   define un campo de nota en ModifingService y no se inventa uno. Se ve
   en el registro y sale en la exportación de operaciones.
--------------------------------------------------------------------- */
const bitacoraOperaciones = [];

function anotarBitacora(entrada) {
    bitacoraOperaciones.push(entrada);
    MEUI.log(
        `${entrada.ok ? "✔" : "✖"} ${entrada.operacion} · ${entrada.msisdn} · ` +
        `HTTP ${entrada.httpStatus} · código ${entrada.codigo === null ? "—" : entrada.codigo}` +
        `${entrada.detalle ? " · " + entrada.detalle : ""} · por ${entrada.usuario}`,
        entrada.ok ? "ok" : "err");
}

const CABECERA_BITACORA = ["Fecha/hora", "Usuario", "MSISDN", "Operación", "process", "action",
    "IMSI", "ICCID", "IMSI nuevo", "ICCID nuevo", "KI nuevo", "MSISDN nuevo", "Portation status",
    "HTTP", "Resultado", "Código", "Message Code", "Detalle", "Nota", "Transaction ID"];

function bitacoraExport() {
    return {
        head: CABECERA_BITACORA,
        rows: bitacoraOperaciones.map(b => [
            b.hora, b.usuario, b.msisdn, b.operacion, b.proceso, b.accion || "",
            b.imsi || "", b.iccid || "",
            b.imsiNuevo || "", b.iccidNuevo || "", b.kiNuevo || "", b.msisdnNuevo || "", b.portationStatus || "",
            b.httpStatus, b.ok ? "OK" : "FALLA",
            b.codigo === null || b.codigo === undefined ? "" : b.codigo,
            b.codigoMsg || "", b.detalle || "", b.nota || "", b.transactionId || ""
        ])
    };
}

/* ---------------------------------------------------------------------
   6 · EJECUCIÓN DEL PATCH
--------------------------------------------------------------------- */
function idTransaccion() {
    return (crypto && crypto.randomUUID) ? crypto.randomUUID()
        : String(Date.now()) + Math.floor(Math.random() * 1e6);
}

async function patchUnaVez(url, payload, cfg, token) {
    const controlador = new AbortController();
    const temporizador = setTimeout(() => controlador.abort(), cfg.timeoutMs);
    const transactionId = idTransaccion();
    const t0 = performance.now();
    try {
        const r = await fetch(url, {
            method: "PATCH", signal: controlador.signal,
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + token,
                "transactionId": transactionId
            },
            body: JSON.stringify(payload)
        });
        const texto = await r.text();
        let cuerpo = null;
        try { cuerpo = texto ? JSON.parse(texto) : null; } catch (e) { /* no era JSON */ }
        return {
            ok: r.ok, status: r.status, cuerpo, texto, transactionId,
            ms: Math.round(performance.now() - t0)
        };
    } finally {
        clearTimeout(temporizador);
    }
}

/**
 * Ejecuta una operación sobre UNA línea y devuelve el registro de bitácora.
 * El éxito real se lee del cuerpo con `evaluarNegocio()` (logica-qdn.js):
 * un HTTP 200 con `success:false` o `responseCode>=400` es una FALLA.
 */
async function ejecutarOperacion(op, f, cfg) {
    const hora = new Date().toISOString().replace("T", " ").slice(0, 19);
    const usuario = usuarioOperador();
    const datos = datosOperacion(f);
    const base = {
        hora, usuario, msisdn: f.msisdn, operacion: op.etiqueta,
        proceso: op.proceso, accion: op.accion || "",
        imsi: datos.imsi.valor, iccid: datos.iccid.valor,
        origenImsi: datos.imsi.origen, origenIccid: datos.iccid.origen,
        nota: notaOperacion()
    };
    // "Riesgo alto": la bitácora también deja el valor NUEVO -sin esto, el
    // registro de una operación que cambia un identificador no diría a qué
    // quedó, solo desde qué estaba.
    if (op.tipo === "riesgo_alto") {
        const cambio = datosCambio(f, op);
        if (op.proceso === "change_imsi") {
            Object.assign(base, { imsiNuevo: cambio.imsi_new, iccidNuevo: cambio.iccid_new.valor, kiNuevo: cambio.ki_new });
        } else if (op.proceso === "change_msisdn") {
            Object.assign(base, { msisdnNuevo: cambio.msisdn_new, portationStatus: cambio.portation_status });
        }
    }

    const impedimento = motivoNoOperable(f, op)
        || (faltantesDe(f, op).length ? "falta " + faltantesDe(f, op).join(" y ") : "");
    if (impedimento) {
        return Object.assign(base, {
            ok: false, httpStatus: "—", codigo: "no-operable", codigoMsg: "",
            detalle: "No se envió nada: " + impedimento, payload: null, cuerpo: null
        });
    }

    const payload = payloadOperacion(op, f);
    const url = cfg.base_apigw.replace(/\/$/, "") + RUTA_MODIFYING;

    let tokenRenovado = false;
    while (true) {
        let token;
        try {
            token = await gestorQdn.obtener(cfg, tokenRenovado);
        } catch (e) {
            return Object.assign(base, {
                ok: false, httpStatus: "—", codigo: "auth", codigoMsg: "",
                detalle: "No se pudo autenticar: " + (e.message || e), payload, cuerpo: null
            });
        }

        let resp;
        try {
            resp = await patchUnaVez(url, payload, cfg, token);
        } catch (e) {
            const esTimeout = e && e.name === "AbortError";
            return Object.assign(base, {
                ok: false, httpStatus: esTimeout ? "timeout" : "—",
                codigo: esTimeout ? "timeout" : "conn-err", codigoMsg: "",
                // Un timeout NO se reintenta: la operación pudo haberse
                // aplicado y repetirla la duplicaría. Se verifica con el QDN.
                detalle: esTimeout
                    ? "Tiempo de espera agotado. NO se reintenta: verifica con una consulta antes de repetir."
                    : "Error de comunicación: " + (e.message || e),
                payload, cuerpo: null
            });
        }

        // 401/403: el token venció -> se renueva UNA vez y se repite.
        if ((resp.status === 401 || resp.status === 403) && !tokenRenovado) {
            tokenRenovado = true;
            gestorQdn.reset();
            continue;
        }

        const negocio = resp.cuerpo
            ? evaluarNegocio(resp.cuerpo)
            : { ok: resp.ok, codigo: resp.status, codigoMsg: null, detalle: (resp.texto || "").slice(0, 300) };
        if (!resp.ok) negocio.ok = false;

        return Object.assign(base, {
            ok: negocio.ok, httpStatus: resp.status, ms: resp.ms,
            codigo: negocio.codigo, codigoMsg: negocio.codigoMsg,
            detalle: negocio.detalle || "", transactionId: resp.transactionId,
            payload, cuerpo: resp.cuerpo, texto: resp.texto
        });
    }
}

/**
 * Vuelve a consultar el QDN de las líneas tocadas y refresca sus filas.
 * Es el mismo `qdn -> operación -> qdn` de los escenarios de interfaz.py:
 * sin esto la tabla seguiría mostrando el estado ANTERIOR a la operación.
 */
async function reconsultar(msisdns, cfg) {
    await ejecutarPool(msisdns, CONCURRENCIA_OPERACION, async (msisdn) => {
        const i = filas.findIndex(x => x.msisdn === msisdn);
        if (i < 0) return;
        const fresca = await consultarConReintentos(msisdn, cfg);
        filas[i] = Object.assign({}, filas[i], fresca);
    });
    render();
}

/* ---------------------------------------------------------------------
   7 · INTERFAZ · lista de operaciones (misma forma en modal y masivo)
--------------------------------------------------------------------- */
function claseTipo(tipo) {
    if (tipo === "bloqueo" || tipo === "riesgo_alto") return "err";
    return tipo === "conciliacion" ? "warn" : "ok";
}

/**
 * `contexto` = "linea" (modal de detalle) o "masivo" (barra de acciones).
 * En "linea" se deshabilita lo que esa línea no puede ejecutar y se explica
 * por qué; en masivo el filtro por línea se hace al confirmar.
 */
function listaOperacionesHTML(contexto, f) {
    return GRUPOS_OPERACION.map(grupo => {
        const ops = OPERACIONES.filter(o => o.grupo === grupo);
        if (!ops.length) return "";
        return `
        <div class="mb-2">
            <div class="fw-bold small text-muted mb-1">${MEUI.esc(grupo)}</div>
            <div class="d-flex flex-wrap gap-2">
                ${ops.map(op => {
                    const impedimento = contexto === "linea" ? motivoNoOperable(f, op) : "";
                    const icono = op.tipo === "desbloqueo" ? "↑" : op.tipo === "riesgo_alto" ? "⚠" : "↓";
                    return `<button type="button"
                        class="btn btn-sm btn-me-line btn-operacion"
                        data-op="${MEUI.esc(op.id)}" data-contexto="${contexto}"
                        ${impedimento ? `disabled title="No disponible: ${MEUI.esc(impedimento)}"` : ""}>
                        <span class="badge-estado ${claseTipo(op.tipo)}">${icono}</span>
                        ${MEUI.esc(op.etiqueta)}
                    </button>`;
                }).join("")}
            </div>
        </div>`;
    }).join("");
}

/** Bloque de operaciones dentro del modal de detalle de una línea. */
function pintarOperacionesLinea(f) {
    const cont = MEUI.$("#mdOperaciones");
    if (!cont) return;
    const impedimentoGeneral = motivoNoOperable(f, null);
    const datos = datosOperacion(f);
    const dato = (etq, d) => `${etq} <span class="me-mono">${MEUI.esc(d.valor || "—")}</span>` +
        `${d.origen ? ` <small class="text-muted">(${MEUI.esc(d.origen)})</small>` : ""}`;
    cont.innerHTML = `
        <div class="me-hint mb-2">
            Estas operaciones <b>escriben en producción</b> sobre
            <span class="me-mono">${MEUI.esc(f.msisdn)}</span> ·
            ${dato("IMSI", datos.imsi)} · ${dato("ICCID", datos.iccid)}.
            Lo que falte se pide al confirmar y todo se puede corregir ahí.
            Quedan registradas a nombre de <b>${MEUI.esc(usuarioOperador())}</b>.
        </div>
        ${impedimentoGeneral ? `<div class="alert alert-warning py-2 mb-2">
            No se puede operar esta línea: ${MEUI.esc(impedimentoGeneral)}.</div>` : ""}
        ${listaOperacionesHTML("linea", f)}`;
    cont.querySelectorAll("button.btn-operacion").forEach(b => {
        b.addEventListener("click", () => abrirConfirmacion(b.dataset.op, [f.msisdn]));
    });
}

/** Menú de operaciones masivas en la barra de acciones. "Riesgo alto" NO
 *  se ofrece aquí -ver el comentario de OPERACIONES-, solo por línea. */
function pintarMenuOperaciones() {
    const ul = MEUI.$("#menuOperaciones");
    if (!ul) return;
    ul.innerHTML = `<li class="px-2 pb-2 me-hint" style="max-width:320px">
            Se aplica a las <b id="opMasivoConteo">0</b> líneas que quedaron
            visibles tras los filtros. Antes de ejecutar se listan todas.
        </li>` + GRUPOS_MASIVO.map(grupo => `
        <li class="px-2 pt-1 fw-bold small text-muted">${MEUI.esc(grupo)}</li>
        ${OPERACIONES.filter(o => o.grupo === grupo).map(op => `
            <li><button type="button" class="dropdown-item btn-operacion small"
                data-op="${MEUI.esc(op.id)}" data-contexto="masivo">
                <span class="badge-estado ${claseTipo(op.tipo)}">${op.tipo === "desbloqueo" ? "↑" : "↓"}</span>
                ${MEUI.esc(op.etiqueta)}</button></li>`).join("")}`).join("");

    ul.querySelectorAll("button.btn-operacion").forEach(b => {
        b.addEventListener("click", () => {
            const visibles = filas.filter(filaPasaFiltros).map(f => f.msisdn);
            abrirConfirmacion(b.dataset.op, visibles);
        });
    });
    actualizarConteoMasivo();
}

function actualizarConteoMasivo() {
    const el = MEUI.$("#opMasivoConteo");
    if (el) el.textContent = filas.filter(filaPasaFiltros).length;
}

/* ---------------------------------------------------------------------
   8 · CONFIRMACIÓN (revisar -> "seguro?") Y EJECUCIÓN
--------------------------------------------------------------------- */
let operacionEnCurso = null;   // { op, objetivo: [filas], bloqueadas: [...] }

function abrirConfirmacion(opId, msisdns) {
    const op = operacionPorId(opId);
    if (!op) return;

    const candidatas = msisdns.map(m => filaDe(m)).filter(Boolean);
    const objetivo = [], bloqueadas = [];
    candidatas.forEach(f => {
        const motivo = motivoNoOperable(f, op);
        if (motivo) bloqueadas.push({ msisdn: f.msisdn, motivo });
        else objetivo.push(f);
    });

    operacionEnCurso = { op, objetivo, bloqueadas };
    const requeridos = camposRequeridos(op);
    notaLibreActual = "";   // cada confirmación nueva empieza con la nota en blanco

    MEUI.$("#opTitulo").textContent = op.etiqueta;
    MEUI.$("#opResultado").innerHTML = "";
    MEUI.$("#opPaso2").hidden = true;
    MEUI.$("#opPaso1").hidden = false;

    const esRiesgoAlto = op.tipo === "riesgo_alto";
    const muestra = objetivo[0] ? payloadOperacion(op, objetivo[0]) : null;
    MEUI.$("#opCuerpo").innerHTML = `
        <div class="d-flex flex-wrap gap-3 align-items-center mb-2">
            <span class="badge-estado ${claseTipo(op.tipo)}">${esRiesgoAlto ? "RIESGO ALTO" : MEUI.esc(op.tipo.toUpperCase())}</span>
            <span class="me-mono text-muted">process=${MEUI.esc(op.proceso)}${op.accion ? " · action=" + MEUI.esc(op.accion) : ""}${op.proceso === "lockall" ? " · level=" + NIVEL_LOCKALL : ""}</span>
            <span class="text-muted small">Ejecuta: <b>${MEUI.esc(usuarioOperador())}</b></span>
        </div>

        <div class="alert ${objetivo.length > 1 || esRiesgoAlto ? "alert-danger" : "alert-warning"} py-2">
            Se va a ejecutar en <b>PRODUCCIÓN</b> sobre
            <b>${objetivo.length}</b> línea${objetivo.length === 1 ? "" : "s"}.
            ${esRiesgoAlto ? "<b>Cambia un identificador propio de la línea</b> -esto puede dejarla sin servicio si el dato nuevo es incorrecto. " : ""}
            Esta acción no se deshace sola.
        </div>

        <div class="fw-bold small mb-1">Líneas afectadas (${objetivo.length})</div>
        <div class="me-hint mb-1">
            ${esRiesgoAlto
                ? `El valor <b>nuevo</b> siempre se escribe a mano -nadie más que tú sabe cuál es-. Como es un PATCH parcial, no hace falta llenar todos los campos: solo lo que de verdad cambia.`
                : `Los campos vienen del archivo, de la consulta QDN o derivados
                   (<span class="me-mono">ICCID = ${PREFIJO_ICCID} + IMSI</span>). Se pueden corregir aquí; el origen de cada valor queda debajo.`}
            El campo <b>Features</b> lleva los bloqueos que ya tiene la línea -detectados solos cuando se puede, editable siempre- para no perderlos al ejecutar esta operación.
        </div>
        ${objetivo.length ? `<div style="max-height:320px;overflow:auto">
            <table class="table table-sm mb-0 tabla-operacion">
                ${tablaConfirmacionEncabezado(op, requeridos)}
                <tbody>${objetivo.map(f => filaConfirmacion(op, f, requeridos)).join("")}</tbody>
            </table></div>`
        : `<div class="alert alert-danger py-2 mb-0">Ninguna línea de la selección se puede operar.</div>`}

        ${bloqueadas.length ? `
            <div class="fw-bold small mt-3 mb-1">Se omiten (${bloqueadas.length})</div>
            <ul class="me-hint mb-0" style="max-height:140px;overflow:auto">
                ${bloqueadas.map(b => `<li><span class="me-mono">${MEUI.esc(b.msisdn)}</span> — ${MEUI.esc(b.motivo)}</li>`).join("")}
            </ul>` : ""}

        <div id="opAvisoFaltantes"></div>

        <div class="mt-3">
            <label class="me-lbl" for="opNota">Nota (opcional)</label>
            <textarea id="opNota" class="form-control form-control-sm" rows="2"
                placeholder="Motivo de la operación -se agrega a la nota junto a tu usuario-">${MEUI.esc(notaLibreActual)}</textarea>
            <div class="me-hint">Se envía como <span class="me-mono">"${MEUI.esc(usuarioOperador())}${notaLibreActual ? ". " + MEUI.esc(notaLibreActual) : ""}"</span>. El usuario siempre viaja; el texto es opcional.</div>
        </div>

        ${muestra ? `<div class="fw-bold small mt-3 mb-1">Cuerpo que se envía${objetivo.length > 1 ? " (ejemplo de la primera línea)" : ""}</div>
            <pre class="json me-mono mb-0" id="opPayload">${MEUI.esc(JSON.stringify(muestra, null, 2))}</pre>` : ""}`;

    // Cada input escribe en `datosManuales` y revalida en caliente. Los
    // campos de texto libre (KI, features, nota) NO se limpian a solo
    // dígitos -KI es hexadecimal, features usa letras y "|"-.
    const CAMPOS_TEXTO_LIBRE = new Set(["ki", "ki_new", "features"]);
    MEUI.$("#opCuerpo").querySelectorAll("input[data-campo]").forEach(inp => {
        inp.addEventListener("input", () => {
            const msisdn = inp.dataset.msisdn, campo = inp.dataset.campo;
            const limpio = CAMPOS_TEXTO_LIBRE.has(campo) ? inp.value.trim() : inp.value.replace(/\D/g, "");
            escribirValorNuevo(msisdn, campo, limpio);
            // Escribir el IMSI (actual o nuevo) vuelve a derivar su ICCID
            // correspondiente si no lo pusieron a mano.
            if (campo === "imsi") refrescarIccidDerivado(msisdn);
            if (campo === "imsi_new") refrescarIccidNuevoDerivado(msisdn);
            revalidarConfirmacion();
        });
    });
    const notaEl = MEUI.$("#opNota");
    if (notaEl) notaEl.addEventListener("input", () => { notaLibreActual = notaEl.value.trim(); revalidarConfirmacion(); });

    MEUI.$("#btnOpVolver").hidden = true;
    MEUI.$("#btnOpSeguro").hidden = true;
    const btn = MEUI.$("#btnOpGuardar");
    btn.hidden = false;
    btn.textContent = pideDobleConfirmacion(op) ? "Guardar" : "Ejecutar";
    btn.className = "btn btn-sm " + (pideDobleConfirmacion(op) ? "btn-warning" : "btn-me");
    revalidarConfirmacion();

    new bootstrap.Modal("#modalOperacion").show();
}

/** Celda editable genérica: input + origen/aviso debajo. */
function celdaInput({ msisdn, campo, valor, obligatorio, textoLibre, pie, invalidaSiVacio }) {
    return `<td>
        <input type="text" ${textoLibre ? "" : 'inputmode="numeric"'}
            class="form-control form-control-sm me-mono ${invalidaSiVacio && !valor ? "is-invalid" : ""}"
            data-msisdn="${MEUI.esc(msisdn)}" data-campo="${campo}"
            value="${MEUI.esc(valor || "")}"
            placeholder="${obligatorio ? "obligatorio" : "opcional"}">
        <div class="me-hint">${MEUI.esc(pie || (obligatorio ? "sin dato: escríbelo" : "sin dato"))}</div>
    </td>`;
}

/** Celda de solo lectura (el dato actual, cuando la operación no lo toca). */
function celdaLectura(valor) {
    return `<td class="align-top me-mono">${MEUI.esc(valor || "—")}</td>`;
}

/** Encabezado de la tabla de confirmación: cambia según la operación. */
function tablaConfirmacionEncabezado(op, requeridos) {
    if (op.proceso === "change_imsi") {
        return `<thead><tr>
            <th>MSISDN</th><th>Estado</th>
            <th>IMSI actual → nuevo</th>
            <th>ICCID actual → nuevo</th>
            <th>KI actual → nuevo <small>(opcional)</small></th>
            <th>Features <small>(bloqueos)</small></th>
        </tr></thead>`;
    }
    if (op.proceso === "change_msisdn") {
        return `<thead><tr>
            <th>MSISDN actual → nuevo</th><th>Estado</th><th>IMSI</th><th>Portation status</th><th>Features</th>
        </tr></thead>`;
    }
    return `<thead><tr>
        <th>MSISDN</th><th>Estado</th><th>IMSI</th>
        ${requeridos.indexOf("iccid") >= 0 ? "<th>ICCID</th><th>KI <small>(opcional)</small></th>" : ""}
        <th>Features <small>(bloqueos)</small></th>
    </tr></thead>`;
}

/** Celda de Features: pre-llenada con lo detectado, editable, con aviso de
 *  lo que no se pudo traducir solo (si hay). */
function celdaFeatures(f) {
    const r = featuresResueltos(f);
    const avisoExtra = r.sinTraducir.length
        ? ` — sin traducir sola${r.sinTraducir.length > 1 ? "s" : ""}: ${r.sinTraducir.join(", ")} (agrégalo(s) aquí si aplica)`
        : "";
    return celdaInput({
        msisdn: f.msisdn, campo: "features", valor: valorNuevo(f.msisdn, "features") || r.valor,
        obligatorio: false, textoLibre: true,
        pie: (r.origen || "sin bloqueos detectados") + avisoExtra
    });
}

/** Una fila de la tabla de confirmación. Tres formas según la operación. */
function filaConfirmacion(op, f, requeridos) {
    const cambio = op.tipo === "riesgo_alto" ? datosCambio(f, op) : null;

    if (op.proceso === "change_imsi") {
        return `<tr>
            ${celdaLectura(f.msisdn)}
            <td class="align-top">${MEUI.esc((f.operationalState || "—").toUpperCase())}</td>
            <td>
                <div class="me-mono small text-muted valor-actual">${MEUI.esc(cambio.actual.imsi.valor || "—")} →</div>
                ${celdaInput({ msisdn: f.msisdn, campo: "imsi_new", valor: cambio.imsi_new, obligatorio: true, invalidaSiVacio: true })}
            </td>
            <td>
                <div class="me-mono small text-muted valor-actual">${MEUI.esc(cambio.actual.iccid.valor || "—")} →</div>
                ${celdaInput({ msisdn: f.msisdn, campo: "iccid_new", valor: cambio.iccid_new.valor, obligatorio: false, pie: cambio.iccid_new.origen || "sin dato" })}
            </td>
            <td>
                <div class="me-mono small text-muted valor-actual">${MEUI.esc(cambio.actual.ki.valor || "—")} →</div>
                ${celdaInput({ msisdn: f.msisdn, campo: "ki_new", valor: cambio.ki_new, obligatorio: false, textoLibre: true })}
            </td>
            ${celdaFeatures(f)}
        </tr>`;
    }

    if (op.proceso === "change_msisdn") {
        return `<tr>
            <td>
                <div class="me-mono small text-muted valor-actual">${MEUI.esc(f.msisdn)} →</div>
                ${celdaInput({ msisdn: f.msisdn, campo: "msisdn_new", valor: cambio.msisdn_new, obligatorio: true, invalidaSiVacio: true })}
            </td>
            <td class="align-top">${MEUI.esc((f.operationalState || "—").toUpperCase())}</td>
            ${celdaLectura(cambio.actual.imsi.valor)}
            ${celdaInput({ msisdn: f.msisdn, campo: "portation_status", valor: cambio.portation_status, obligatorio: false, pie: 'valor de ejemplo: "0"' })}
            ${celdaFeatures(f)}
        </tr>`;
    }

    // Operaciones existentes (bloqueo/desbloqueo/conciliación/roaming).
    const datos = datosOperacion(f);
    const celda = campo => celdaInput({
        msisdn: f.msisdn, campo, valor: datos[campo].valor,
        obligatorio: requeridos.indexOf(campo) >= 0, invalidaSiVacio: requeridos.indexOf(campo) >= 0,
        textoLibre: campo === "ki", pie: datos[campo].origen
    });
    return `<tr>
        <td class="me-mono align-middle">${MEUI.esc(f.msisdn)}</td>
        <td class="align-top">${MEUI.esc((f.operationalState || "—").toUpperCase())}</td>
        ${celda("imsi")}
        ${requeridos.indexOf("iccid") >= 0 ? celda("iccid") + celda("ki") : ""}
        ${celdaFeatures(f)}
    </tr>`;
}

/** Al cambiar el IMSI actual se recalcula el ICCID actual derivado. */
function refrescarIccidDerivado(msisdn) {
    const inp = MEUI.$(`#opCuerpo input[data-campo="iccid"][data-msisdn="${msisdn}"]`);
    if (!inp) return;
    const manual = datosManuales.get(msisdn) || {};
    if (manual.iccid) return;                       // lo escribieron: no se toca
    const f = filaDe(msisdn);
    if (!f) return;
    const datos = datosOperacion(f);
    inp.value = datos.iccid.valor;
    const pie = inp.parentElement.querySelector(".me-hint");
    if (pie) pie.textContent = datos.iccid.origen || "sin dato: escríbelo";
    inp.classList.toggle("is-invalid", !datos.iccid.valor);
}

/** Al cambiar el IMSI NUEVO (change_imsi) se recalcula el ICCID nuevo
 *  derivado -mismo criterio que refrescarIccidDerivado, para el par nuevo-. */
function refrescarIccidNuevoDerivado(msisdn) {
    const inp = MEUI.$(`#opCuerpo input[data-campo="iccid_new"][data-msisdn="${msisdn}"]`);
    if (!inp) return;
    const manual = datosManuales.get(msisdn) || {};
    if (manual.iccid_new) return;                    // lo escribieron: no se toca
    const f = filaDe(msisdn);
    if (!f) return;
    const cambio = datosCambio(f, { proceso: "change_imsi" });
    inp.value = cambio.iccid_new.valor;
    const pie = inp.parentElement.querySelector(".me-hint");
    if (pie) pie.textContent = cambio.iccid_new.origen || "sin dato";
}

/** Habilita o bloquea el botón según falten campos obligatorios. */
function revalidarConfirmacion() {
    if (!operacionEnCurso) return;
    const { op, objetivo } = operacionEnCurso;
    const incompletas = objetivo.filter(f => faltantesDe(f, op).length);

    const aviso = MEUI.$("#opAvisoFaltantes");
    if (aviso) {
        aviso.innerHTML = incompletas.length
            ? `<div class="alert alert-warning py-2 mt-2 mb-0">
                 Faltan datos obligatorios en <b>${incompletas.length}</b> línea(s):
                 ${MEUI.esc(incompletas.slice(0, 8).map(f => f.msisdn).join(", "))}${incompletas.length > 8 ? "…" : ""}.
                 Complétalos arriba para poder continuar.
               </div>`
            : "";
    }

    const payload = MEUI.$("#opPayload");
    if (payload && objetivo.length && !faltantesDe(objetivo[0], op).length) {
        payload.textContent = JSON.stringify(payloadOperacion(op, objetivo[0]), null, 2);
    }

    const btn = MEUI.$("#btnOpGuardar");
    if (btn) btn.disabled = !objetivo.length || incompletas.length > 0;
}

/** Paso 1 -> paso 2 en bloqueo y conciliación; ejecución directa si no. */
function confirmarPaso1() {
    if (!operacionEnCurso) return;
    const { op, objetivo } = operacionEnCurso;
    if (!objetivo.length) return;

    if (objetivo.some(f => faltantesDe(f, op).length)) { revalidarConfirmacion(); return; }
    if (!pideDobleConfirmacion(op)) { correrOperacion(); return; }

    MEUI.$("#opPaso1").hidden = true;
    MEUI.$("#opPaso2").hidden = false;
    MEUI.$("#btnOpGuardar").hidden = true;
    MEUI.$("#btnOpVolver").hidden = false;
    MEUI.$("#btnOpSeguro").hidden = false;
    MEUI.$("#opSeguroTexto").innerHTML =
        `¿Seguro? Vas a <b>${MEUI.esc(op.etiqueta.toLowerCase())}</b> en producción sobre ` +
        `<b>${objetivo.length}</b> línea${objetivo.length === 1 ? "" : "s"}` +
        `${objetivo.length === 1 ? ` (<span class="me-mono">${MEUI.esc(objetivo[0].msisdn)}</span>)` : ""}. ` +
        `Queda registrado a nombre de <b>${MEUI.esc(usuarioOperador())}</b>.`;
}

function volverPaso1() {
    MEUI.$("#opPaso2").hidden = true;
    MEUI.$("#opPaso1").hidden = false;
    MEUI.$("#btnOpSeguro").hidden = true;
    MEUI.$("#btnOpVolver").hidden = true;
    MEUI.$("#btnOpGuardar").hidden = false;
}

async function correrOperacion() {
    if (!operacionEnCurso) return;
    const { op, objetivo } = operacionEnCurso;
    const cfg = cfgQdn;

    MEUI.$("#opPaso1").hidden = true;
    MEUI.$("#opPaso2").hidden = true;
    MEUI.$("#btnOpGuardar").hidden = true;
    MEUI.$("#btnOpVolver").hidden = true;
    MEUI.$("#btnOpSeguro").hidden = true;
    const salida = MEUI.$("#opResultado");
    salida.innerHTML = `<div class="me-hint">Ejecutando <b>${MEUI.esc(op.etiqueta)}</b> sobre ${objetivo.length} línea(s)…</div>`;

    MEUI.log(`▶ ${op.etiqueta} sobre ${objetivo.length} línea(s) · ejecuta ${usuarioOperador()}`, "warn");

    const resultados = [];
    await ejecutarPool(objetivo, CONCURRENCIA_OPERACION, async (f) => {
        const r = await ejecutarOperacion(op, f, cfg);
        anotarBitacora(r);
        resultados.push(r);
        salida.innerHTML = `<div class="me-hint">Ejecutando… ${resultados.length} / ${objetivo.length}</div>`;
    });
    resultados.sort((a, b) => objetivo.findIndex(f => f.msisdn === a.msisdn) - objetivo.findIndex(f => f.msisdn === b.msisdn));

    const ok = resultados.filter(r => r.ok).length;
    salida.innerHTML = `
        <div class="alert ${ok === resultados.length ? "alert-success" : "alert-warning"} py-2">
            <b>${ok} de ${resultados.length}</b> operación(es) con resultado exitoso.
            ${ok === resultados.length ? "" : "Revisa el detalle: un HTTP 200 con error en el cuerpo cuenta como falla."}
        </div>
        <div style="max-height:260px;overflow:auto">
        <table class="table table-sm table-striped mb-0">
            <thead><tr><th>MSISDN</th><th>Resultado</th><th>HTTP</th><th>Código</th><th>Detalle</th></tr></thead>
            <tbody>${resultados.map(r => `<tr>
                <td class="me-mono">${MEUI.esc(r.msisdn)}</td>
                <td><span class="badge-estado ${r.ok ? "ok" : "err"}">${r.ok ? "OK" : "FALLA"}</span></td>
                <td class="me-mono">${MEUI.esc(String(r.httpStatus))}</td>
                <td class="me-mono">${MEUI.esc(String(r.codigo === null || r.codigo === undefined ? "—" : r.codigo))}</td>
                <td>${MEUI.esc([r.codigoMsg, r.detalle].filter(Boolean).join(" · ") || "—")}</td>
            </tr>`).join("")}</tbody>
        </table></div>
        <div class="me-hint mt-2">Verificando el estado real con una consulta QDN…</div>`;

    MEUI.toast(`${op.etiqueta}: ${ok}/${resultados.length} con éxito.`, ok === resultados.length ? "ok" : "warn");

    // Verificación: la tabla debe reflejar el estado DESPUÉS de la operación.
    await reconsultar(objetivo.map(f => f.msisdn), cfg);
    salida.insertAdjacentHTML("beforeend",
        `<div class="me-hint">Consulta de verificación terminada: la tabla ya muestra el estado actual.</div>`);
    operacionEnCurso = null;
}

/* ---------------------------------------------------------------------
   9 · INICIALIZACIÓN
--------------------------------------------------------------------- */
function inicializarOperaciones() {
    const guardar = MEUI.$("#btnOpGuardar");
    const seguro = MEUI.$("#btnOpSeguro");
    const volver = MEUI.$("#btnOpVolver");
    if (guardar) guardar.addEventListener("click", confirmarPaso1);
    if (seguro) seguro.addEventListener("click", correrOperacion);
    if (volver) volver.addEventListener("click", volverPaso1);

    const bitacora = MEUI.$("#btnBitacora");
    if (bitacora) bitacora.addEventListener("click", () => {
        if (!bitacoraOperaciones.length) { MEUI.toast("Todavía no se ha ejecutado ninguna operación.", "warn"); return; }
        const { head, rows } = bitacoraExport();
        MEUI.exportarCSV(head, rows, "bitacora_operaciones");
    });

    pintarMenuOperaciones();
}
inicializarOperaciones();
