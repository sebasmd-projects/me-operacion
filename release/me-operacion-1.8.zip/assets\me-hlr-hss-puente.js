/* =====================================================================
   me-hlr-hss-puente.js · Interruptor de pestañas de hlr_hss.html
   ---------------------------------------------------------------------
   No es un puente como los demás (no conecta UNA lógica con el shell):
   conecta TRES motores independientes (logica-hlr-hss-tigo.js, -claro.js,
   -ambos.js) con un único documento, montando y desmontando el
   <template> de la pestaña activa, y reengancha en CADA montaje lo que
   antes vivía en tres puentes separados (me-qdn-puente.js,
   me-qdn-tigo-puente.js, me-hlr-cruzado-puente.js): Enter para consultar,
   exportaciones CSV/Excel/JSON, spinners automáticos, botones de
   registro y -solo en Claro- la sesión QDN de la cabecera.

   Por qué desmontar y no solo ocultar con CSS: los tres motores fueron
   escritos como páginas independientes y comparten (por diseño, de
   antes de esta fusión) los mismos ids -#tablaResultados, #inputLineas,
   #modalDetalle, #logConexion...-. Si dos pestañas estuvieran montadas a
   la vez (aunque una estuviera oculta con `hidden`), habría DOS
   elementos con el mismo id en el documento, y `MEUI.$("#id")` /
   `document.getElementById` solo encuentran el primero: la pestaña
   "de atrás" quedaría rota. Por eso solo la pestaña activa vive en el
   DOM en cada momento, y por lo que TODO el enganche de esta pestaña
   -no solo el motor- se rehace en cada montaje: los elementos son
   nodos nuevos (clonados del <template>), sin ningún listener todavía.

   Va SIEMPRE al final del <body>, después de los tres motores:

       <script src="assets/logica-hlr-hss-tigo.js"></script>
       <script src="assets/logica-hlr-hss-claro.js"></script>
       <script src="assets/logica-hlr-hss-ambos.js"></script>
       <script src="assets/me-hlr-hss-puente.js"></script>
===================================================================== */
(function () {
    "use strict";
    const el = id => document.getElementById(id);

    const MOTORES = {
        tigo: {
            template: "panelTigo", motor: () => window.MotorTigo, etiqueta: "Tigo",
            exportBase: "hlr_hss_tigo", exportHoja: "QDN Tigo",
            spinnerConsultar: "Consultando HLR Tigo…"
        },
        claro: {
            template: "panelClaro", motor: () => window.MotorClaro, etiqueta: "Claro",
            exportBase: "hlr_hss_claro", exportHoja: "QDN Claro",
            spinnerConsultar: "Consultando QDN Claro…",
            sesionQdn: true
        },
        ambos: {
            template: "panelAmbos", motor: () => window.MotorAmbos, etiqueta: "Ambos",
            exportBase: "hlr_hss_ambos", exportHoja: "Cruce HLR",
            spinnerConsultar: "Consultando Claro y Tigo…"
        }
    };

    const montado = document.getElementById("panelMontado");
    let actual = null;

    /** Todo lo que antes vivía en el puente de cada herramienta por separado
     *  (no en el motor): se rehace en cada montaje porque los elementos son
     *  nodos nuevos, recién clonados del <template>, sin listeners. */
    function engancharComun(cfg, motor) {
        MEUI.enterEjecuta(el("inputLineas"), el("btnConsultar"));

        const reemplazar = (id, fn) => {
            const b = el(id); if (!b) return;
            const n = b.cloneNode(true); b.replaceWith(n); n.addEventListener("click", fn);
        };
        if (typeof motor.filasExport === "function") {
            reemplazar("btnCSV", () => { const d = motor.filasExport(); MEUI.exportarCSV(d.head, d.rows, cfg.exportBase); });
            reemplazar("btnXLSX", () => { const d = motor.filasExport(); MEUI.exportarXLSX(d.head, d.rows, cfg.exportBase, cfg.exportHoja); });
        }
        if (el("btnJSON") && typeof motor.filasParaExportar === "function")
            el("btnJSON").addEventListener("click", () => MEUI.exportarJSON(motor.filasParaExportar(), cfg.exportBase));

        MEUI.autoSpinner("#btnConsultar", cfg.spinnerConsultar);
        if (cfg.sesionQdn) MEUI.autoSpinner("#btnProbarQdn", "Obteniendo token…");

        if (el("btnLimpiarLog")) el("btnLimpiarLog").addEventListener("click", () => MEUI.limpiarLog());
        if (el("btnCopiarLog")) el("btnCopiarLog").addEventListener("click", () => {
            navigator.clipboard.writeText(el("logConexion").innerText)
                .then(() => MEUI.toast("Registro copiado.", "ok"))
                .catch(() => MEUI.toast("No se pudo copiar.", "err"));
        });

        // Sesión QDN (solo Claro): credenciales compartidas por la cabecera
        // y el botón "Probar conexión" que las deja guardadas.
        if (cfg.sesionQdn) {
            const cQdn = MEUI.cred.get("qdn");
            if (cQdn && el("cfgClientSecret") && !el("cfgClientSecret").value) {
                if (cQdn.token_url) el("cfgTokenUrl").value = cQdn.token_url;
                if (cQdn.client_id) el("cfgClientId").value = cQdn.client_id;
                if (cQdn.base_apigw) el("cfgBaseApigw").value = cQdn.base_apigw;
            }
            if (el("btnProbarQdn")) el("btnProbarQdn").addEventListener("click", () =>
                MEUI.cred.set("qdn", {
                    token_url: el("cfgTokenUrl").value.trim(),
                    client_id: el("cfgClientId").value.trim(),
                    base_apigw: el("cfgBaseApigw").value.trim()
                }));
        }
    }

    function montar(clave) {
        const cfg = MOTORES[clave];
        if (!cfg) return;
        if (actual === clave) return;   // ya está esta pestaña activa

        // Se desmonta TODO lo anterior antes de montar lo nuevo (ver el
        // porqué en el encabezado del archivo).
        montado.innerHTML = "";

        const tpl = document.getElementById(cfg.template);
        if (!tpl) {
            MEUI.log(`No se encontró la plantilla "${cfg.template}" para la pestaña ${cfg.etiqueta}.`, "err");
            return;
        }
        montado.appendChild(tpl.content.cloneNode(true));

        document.querySelectorAll("[data-tab]").forEach(b => {
            const activa = b.dataset.tab === clave;
            b.classList.toggle("activa", activa);
            b.setAttribute("aria-selected", activa ? "true" : "false");
        });
        actual = clave;

        // MEUI.montarPasos() (el plegado de las secciones [data-me-paso])
        // solo corre una vez, dentro de MEUI.init(); el marcado que se
        // acaba de clonar no ha pasado por ahí todavía. Se repite aquí
        // para esta tanda de elementos nuevos -montarPasos() ya se
        // encarga de no tocar dos veces lo que ya estaba montado.
        MEUI.montarPasos();
        MEUI.aplicarAperturaPasos();

        const motor = cfg.motor();
        if (!motor || typeof motor.iniciar !== "function") {
            MEUI.log(`No se pudo iniciar el motor "${cfg.etiqueta}": revisa que su script haya cargado sin errores (ver más arriba en este registro).`, "err");
            MEUI.toast(`La pestaña ${cfg.etiqueta} no cargó. Mira el registro.`, "err");
            return;
        }
        try {
            // reiniciar() limpia el dataTable de la visita anterior a esta
            // MISMA pestaña (si la hubo): sin esto, construirDataTable()
            // vería su variable ya asignada y no crearía una tabla nueva
            // sobre el <table> recién clonado, que quedaría en blanco.
            if (typeof motor.reiniciar === "function") motor.reiniciar();
            motor.iniciar();
            engancharComun(cfg, motor);
            MEUI.log(`Pestaña "${cfg.etiqueta}" lista.`, "ok");
        } catch (e) {
            MEUI.log(`Error iniciando la pestaña "${cfg.etiqueta}": ${e.message}`, "err");
            MEUI.toast(`No se pudo iniciar la pestaña ${cfg.etiqueta}. Mira el registro.`, "err");
        }
        setTimeout(MEUI.ajustarTablas, 250);
    }

    document.querySelectorAll("[data-tab]").forEach(b =>
        b.addEventListener("click", () => montar(b.dataset.tab)));

    // Sesión QDN de la cabecera (solo aplica mientras Claro está montado;
    // si se dispara con otra pestaña activa, los el(...) de arriba
    // simplemente no encuentran nada y no pasa nada).
    document.addEventListener("me:sesion-iniciar", e => {
        if (e.detail.clave === "qdn" && el("btnProbarQdn")) el("btnProbarQdn").click();
    });
    document.addEventListener("me:sesion-cerrar", e => {
        if (e.detail.clave !== "qdn") return;
        const claro = window.MotorClaro;
        if (claro && claro.gestorQdn) claro.gestorQdn.reset();
        MEUI.log("Sesión QDN cerrada.", "warn");
    });

    // Arranca en "Tigo": es la pestaña de solo lectura y menor riesgo -no
    // tiene sentido que el primer vistazo a la herramienta aterrice en
    // Claro, que trae operaciones de escritura sobre la línea.
    montar("tigo");
})();
