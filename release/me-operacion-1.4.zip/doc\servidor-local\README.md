# Servidor local (`server/`) — experimental

> **Estado: experimental, no conectado a `dame click.bat`.** Se prueba
> suelto con `server\iniciar-servidor.bat`; si funciona bien en los
> equipos reales de los analistas, el siguiente paso es que
> `lanzador.ps1` lo levante solo y abra `http://localhost:PUERTO/...` en
> vez de `file:///...` (ver «Integración futura» al final).

---

## Por qué existe

`dame click.bat` abre Edge con `--disable-web-security` y
`--allow-file-access-from-files` porque, al abrir las herramientas por
`file://`, el navegador bloquea por **CORS** las llamadas que
`assets/me-api.js` hace directo a servidores HTTP de otro origen: el CM
(`obp-apigw.exito-prod.movil-exito.internal`) y Keycloak. Son servidores
internos de la compañía, sin cabeceras CORS, y no hay forma de
«arreglarlo» del lado del servidor — de ahí que el lanzador optara por
desactivar la seguridad web del navegador entero.

Esa combinación de banderas (`--disable-web-security` + `--inPrivate` +
perfil temporal desechable) es justo la que varios antivirus/EDR vigilan
de cerca: es la firma de un navegador abierto para saltarse su propio
aislamiento de origen, el mismo patrón que usan herramientas para robar
cookies/tokens. Ver `doc/lanzador/README.md`, sección de riesgos.

**La solución no es "confiar en que no lo detecten"**: es dejar de
necesitar la bandera. Sirviendo la página **y** haciendo de proxy hacia
el CM/Keycloak desde el mismo origen (`http://localhost:PUERTO`), la
página y las llamadas al API quedan en el mismo origen — el navegador ya
no aplica CORS ahí, así que `--disable-web-security` deja de hacer
falta. De regalo, servir por HTTP también resuelve el otro motivo de esa
bandera (`--allow-file-access-from-files`, que existía para que `marked`
pudiera leer los `README.md` por `fetch()` estando en `file://`).

---

## Qué hay en `server/`

| Archivo | Qué hace |
| --- | --- |
| `verificar-httplistener.ps1` / `.bat` | Prueba aislada: confirma que el equipo puede levantar un `System.Net.HttpListener` en `localhost` sin admin, antes de construir nada encima. **Correr esto primero**, en un equipo real de analista. |
| `servidor.ps1` / `iniciar-servidor.bat` | El servidor de verdad: sirve `index.html`, `assets/`, `herramientas/`, `doc/` por HTTP, y hace de proxy hacia el CM y Keycloak. |

No usa Node, Python ni ninguna dependencia externa — solo
`System.Net.HttpListener` y `System.Net.Http.HttpClient`, ambos nativos
de .NET, disponibles en cualquier Windows con PowerShell (igual que el
resto del proyecto, que evita a propósito depender de herramientas que
haya que instalar).

### Por qué `localhost` y no admin

`HttpListener` normalmente exige que Windows reserve la URL con
`netsh http add urlacl` (que sí pide administrador) — **excepto** cuando
el prefijo es `http://localhost:PUERTO/` o `http://127.0.0.1:PUERTO/`:
para esos dos casos concretos, Windows deja escuchar sin reserva ni
privilegios elevados. Por eso `servidor.ps1` se enlaza siempre a
`localhost`, nunca a `+` (todas las interfaces) ni a una IP de red real.
`verificar-httplistener.ps1` existe justo para confirmar esto en un
equipo real antes de asumir que funciona en todos.

### Qué expone

```
http://localhost:PUERTO/                 -> index.html y el resto de archivos estáticos
http://localhost:PUERTO/proxy/cm/<ruta>  -> http://obp-apigw.exito-prod.movil-exito.internal/<ruta>
http://localhost:PUERTO/proxy/kc/<ruta>  -> http://keycloak.exito-prod.movil-exito.internal/<ruta>
```

El proxy reenvía método, cabeceras (`Authorization`, `locale`, `spid`,
`tenant`, `Content-Type`...) y cuerpo tal cual, y devuelve la respuesta
tal cual — no interpreta nada del CM, solo hace de puente.

### Cómo lo detecta `me-api.js`

`assets/me-api.js` calcula `CONFIG.apiBase` / `CONFIG.kcBase` según el
origen desde el que se cargó la página:

```js
const ENTORNO_LOCAL = location.protocol === "http:" &&
    /^(localhost|127\.0\.0\.1)$/i.test(location.hostname);

apiBase: ENTORNO_LOCAL ? "/proxy/cm" : "http://obp-apigw.exito-prod.movil-exito.internal",
kcBase:  ENTORNO_LOCAL ? "/proxy/kc" : "http://keycloak.exito-prod.movil-exito.internal",
```

Esto es **aditivo y no rompe nada**: si la página se abre por `file://`
(el flujo de siempre, vía `dame click.bat`), `ENTORNO_LOCAL` es `false` y
`CONFIG` queda exactamente igual que antes de este cambio. Ninguna otra
herramienta ni archivo `logica-*.js` necesitó tocarse — todas llaman a
`MEAPI.getJson`/`MEAPI.api`, que ya usan `CONFIG.apiBase` internamente.

---

## Cómo probarlo

1. `server\verificar-httplistener.bat` — confirma que el equipo puede
   abrir un puerto en `localhost`. Si falla aquí, no tiene sentido seguir
   (puede ser una política de seguridad local; revisa con el mensaje que
   deja en pantalla).
2. `server\iniciar-servidor.bat` — levanta el servidor y abre el
   navegador por defecto en `http://localhost:8877/`. Prueba iniciar
   sesión del CM y hacer una consulta desde cualquier herramienta: si el
   proxy funciona, no hace falta `--disable-web-security` para nada de
   eso.
3. Para dejar de abrirlo automáticamente: `server\iniciar-servidor.bat -SinAbrirNavegador`.
4. Para usar otro puerto (si el 8877 está ocupado):
   `server\iniciar-servidor.bat -Puerto 9090`.

Ctrl+C detiene el servidor; cerrar la ventana también.

---

## Limitaciones actuales (es v1, para validar el enfoque)

- **Un solo hilo.** Atiende una petición a la vez (`GetContext()`
  bloqueante en el hilo principal). Para el uso normal de un analista
  (una pestaña, consultas una detrás de otra) alcanza; no está pensado
  para varios usuarios concurrentes sobre el mismo proceso.
- **Sin HTTPS.** Sigue siendo texto plano en la red local, igual que
  ahora — pero ya no depende de desactivar la seguridad del navegador
  entero para funcionar.
- **SIME queda fuera.** El token `prf` se obtiene por NTLM desde
  `lanzador.ps1` (fuera del navegador, server-to-server), no desde JS de
  la página — nunca tuvo el problema de CORS que este proxy resuelve, así
  que no necesita pasar por aquí.

---

## Integración futura (no hecha todavía)

Si `verificar-httplistener` y `servidor.ps1` funcionan bien en los
equipos reales de los analistas, el paso siguiente sería que
`lanzador.ps1`:

1. Levante `server\servidor.ps1` en segundo plano (en vez de nada).
2. Abra Edge apuntando a `http://localhost:PUERTO/herramientas/...` en
   vez de `file:///...`.
3. Quite `--disable-web-security` y `--allow-file-access-from-files` de
   `$argsEdge` (ya no harían falta).

Eso se dejó **fuera** de este cambio a propósito: mezclar "construir el
servidor" con "tocar el lanzador que todos los analistas usan a diario"
en el mismo paso es más riesgo del necesario. Primero se valida esto
suelto.
