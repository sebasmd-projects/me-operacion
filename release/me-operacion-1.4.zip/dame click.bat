@echo off
REM ============================================================
REM  Abrir herramientas SIME / CM-BSS
REM  Coloca este .bat junto a index.html (la carpeta que contiene
REM  'herramientas', 'assets' y 'lanzador.ps1').
REM
REM  Lanzador DELGADO: toda la logica vive en lanzador.ps1, invocado
REM  como archivo real -no como bloque embebido que el propio .bat
REM  decodifica y ejecuta con Invoke-Expression, como antes-. Ese patron
REM  ("el script se lee a si mismo y corre el resultado") es una firma
REM  que varios antivirus vigilan de cerca, asi que se evita por completo.
REM  De paso, lanzador.ps1 SI se puede firmar con Authenticode; un .bat
REM  no se puede firmar de ninguna forma.
REM
REM  Uso: ver el encabezado de lanzador.ps1 para el detalle completo de
REM  parametros (/solo-casos, /sinsesion, /reset, /debug, /sinupdate...).
REM
REM  Aviso de version nueva: este lanzador SOLO avisa si hay una version
REM  mas nueva publicada; nunca la descarga ni la aplica solo. Para
REM  instalarla, corre "actualizar.bat" aparte (paso siempre a mano).
REM ============================================================
@title Herramientas SIME / CM
setlocal
where powershell.exe >nul 2>&1
if errorlevel 1 (
  echo No se encontro powershell.exe en el PATH.
  pause
  exit /b 1
)
powershell.exe -NoProfile -NoLogo -ExecutionPolicy Bypass -File "%~dp0lanzador.ps1" %*
set "CODIGO=%ERRORLEVEL%"
endlocal
exit /b %CODIGO%
