<#
    actualizar.ps1
    -----------------------------------------------------------------------
    Instala la version nueva que "dame click.bat" avisa cuando la
    encuentra. Es un paso APARTE y siempre A MANO: antes esto lo hacia
    dame click.bat el solo, en silencio, cada vez que se abria -
    descargaba el .zip, sobreescribia la carpeta encima y se relanzaba sin
    preguntar nada. Varios antivirus bloquean justo ese patron (codigo que
    se reemplaza a si mismo y se re-ejecuta sin intervencion humana, el
    mismo comportamiento que un dropper de malware), asi que se separo:

      - dame click.bat (via lanzador.ps1) SOLO avisa: "hay version nueva,
        corre actualizar.bat" -nunca descarga ni aplica nada-.
      - este script es el que de verdad descarga y aplica, y solo corre
        porque el analista lo lanzo el mismo, a proposito.

    Ademas verifica el SHA-256 del .zip contra el que trae version.json
    ANTES de aplicarlo: si no coincide, no se toca nada. (Los releases
    generados con empaquetar-release.ps1 desde esta version en adelante
    ya incluyen ese hash; uno mas viejo simplemente avisa que no se pudo
    verificar, en vez de bloquear la actualizacion.)

    Uso:
        actualizar.bat
        actualizar.bat /debug         -> muestra el detalle tecnico si algo falla
        actualizar.bat /sinconfirmar  -> no pregunta "instalar? [S/n]" (para
                                          correrlo desde otro script propio)
#>
$ErrorActionPreference = 'Stop'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch { }

$argumentos   = $args -join ' '
$debug        = $argumentos -match '/debug'
$sinConfirmar = $argumentos -match '/sinconfirmar'

$carpeta = $PSScriptRoot
if ([string]::IsNullOrWhiteSpace($carpeta)) { $carpeta = (Get-Location).Path }

function Ok($t)    { Write-Host ("  OK        {0}" -f $t) -ForegroundColor Green }
function Nota($t)  { Write-Host ("            {0}" -f $t) -ForegroundColor DarkGray }
function Aviso($t) { Write-Host ("  ATENCION  {0}" -f $t) -ForegroundColor Yellow }

Write-Host ''
Write-Host '  Actualizar me-operacion' -ForegroundColor Yellow
Write-Host '  ------------------------'
Write-Host ''

# Version tipo "1.0" / "1.1". Acepta un numero solo ("2" -> "2.0") y nunca
# lanza: si no se puede interpretar, cuenta como "0.0".
function VerDe($valor) {
  $s = [string]$valor
  if ([string]::IsNullOrWhiteSpace($s)) { return [version]'0.0' }
  if ($s -notmatch '\.') { $s = "$s.0" }
  try { return [version]$s } catch { return [version]'0.0' }
}

$UPDATE_BASE   = 'https://sebasmd.com/me/operacion'
$VERSION_URL   = "$UPDATE_BASE/version.json"
$VERSION_LOCAL = Join-Path $carpeta 'VERSION'

try {
  $verLocal = [version]'0.0'
  if (Test-Path $VERSION_LOCAL) {
    $txt = (Get-Content $VERSION_LOCAL -Raw -ErrorAction Stop).Trim()
    if ($txt) { $verLocal = VerDe $txt }
  }

  Write-Host '  Consultando version disponible...' -ForegroundColor Gray
  $cacheBust = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
  $info = Invoke-RestMethod -Uri "$VERSION_URL`?t=$cacheBust" -TimeoutSec 15 -UseBasicParsing
  $verRemota = VerDe $info.version

  if ($verRemota -le $verLocal) {
    Ok ("Ya estas en la version mas reciente ({0})." -f $verLocal)
    Write-Host ''
    Read-Host '  Enter para cerrar'
    exit 0
  }

  Write-Host ''
  Write-Host ("  Version local : {0}" -f $verLocal)
  Write-Host ("  Version nueva : {0}" -f $verRemota)
  if ($info.notas) { Write-Host ("  Novedades     : {0}" -f $info.notas) }
  Write-Host ''

  if (-not $sinConfirmar) {
    $resp = Read-Host '  Instalar esta version ahora? [S/n]'
    if ($resp -and ($resp.Trim().ToLower() -notin @('s', 'si', 'sí', 'y', 'yes'))) {
      Nota 'Cancelado. No se cambio nada.'
      Write-Host ''
      Read-Host '  Enter para cerrar'
      exit 0
    }
  }

  $zipUrl = [string]$info.zip
  if ($zipUrl -notmatch '^https?://') { $zipUrl = "$UPDATE_BASE/$zipUrl" }

  $zipTmp = Join-Path $env:TEMP ("me-operacion-{0}.zip" -f $verRemota)
  $exTmp  = Join-Path $env:TEMP ("me-operacion-{0}-extract" -f $verRemota)
  if (Test-Path $exTmp) { Remove-Item $exTmp -Recurse -Force -ErrorAction SilentlyContinue }
  if (Test-Path $zipTmp) { Remove-Item $zipTmp -Force -ErrorAction SilentlyContinue }

  Write-Host '  Descargando...' -ForegroundColor Gray
  Invoke-WebRequest -Uri $zipUrl -OutFile $zipTmp -TimeoutSec 120 -UseBasicParsing

  # Verificacion de integridad: si version.json trae sha256, el .zip
  # descargado tiene que coincidir EXACTO o no se aplica nada. HTTPS ya
  # protege el transporte, pero esto ademas cubre que el archivo publicado
  # en sebasmd.com sea justo el que se genero con empaquetar-release.ps1
  # (y no uno corrupto o distinto). La herramienta no adivina: si no
  # coincide, se detiene y avisa, no intenta "arreglarlo solo".
  if ($info.sha256) {
    Write-Host '  Verificando integridad (SHA-256)...' -ForegroundColor Gray
    $hashReal = (Get-FileHash -Path $zipTmp -Algorithm SHA256).Hash
    if ($hashReal.ToLower() -ne ([string]$info.sha256).ToLower()) {
      Remove-Item $zipTmp -Force -ErrorAction SilentlyContinue
      throw ("El .zip descargado NO coincide con el hash publicado en version.json.`n" +
             "         Esperado: {0}`n         Obtenido: {1}`n" +
             "         No se aplico nada. Vuelve a intentarlo mas tarde." -f $info.sha256, $hashReal)
    }
    Ok 'Hash verificado: el archivo descargado es el que se publico.'
  } else {
    Aviso 'version.json no trae sha256 (release anterior a esta funcion): no se pudo verificar integridad.'
  }

  Write-Host '  Descomprimiendo...' -ForegroundColor Gray
  Expand-Archive -Path $zipTmp -DestinationPath $exTmp -Force

  # Si el .zip trae todo adentro de una sola subcarpeta (tipico de
  # "Comprimir carpeta" en vez de "Comprimir el contenido"), se usa esa
  # subcarpeta como raiz real de los archivos.
  $raizExtraida = $exTmp
  $itemsExtraidos = Get-ChildItem $exTmp
  if ($itemsExtraidos.Count -eq 1 -and $itemsExtraidos[0].PSIsContainer) {
    $raizExtraida = $itemsExtraidos[0].FullName
  }
  if (-not (Test-Path (Join-Path $raizExtraida 'index.html'))) {
    throw "El .zip descargado no tiene index.html en la raiz esperada: revisa como se empaqueto."
  }

  # /E copia todo (incluidas subcarpetas vacias) y SOBRESCRIBE; no borra
  # archivos que existan en destino y ya no vengan en el .zip (a proposito:
  # mas seguro que /MIR para no arriesgar borrar algo fuera de lugar por un
  # error de rutas).
  Write-Host '  Aplicando (robocopy)...' -ForegroundColor Gray
  robocopy $raizExtraida $carpeta /E /NFL /NDL /NJH /NJS /NP /R:1 /W:1 | Out-Null
  if ($LASTEXITCODE -ge 8) { throw "robocopy fallo copiando la actualizacion (codigo $LASTEXITCODE)." }

  Remove-Item $zipTmp -Force -ErrorAction SilentlyContinue
  Remove-Item $exTmp -Recurse -Force -ErrorAction SilentlyContinue

  Write-Host ''
  Ok ("Actualizado a la version {0}." -f $verRemota)
  Nota "Corre 'dame click.bat' cuando quieras abrir las herramientas."
  Write-Host ''
  Read-Host '  Enter para cerrar'
}
catch {
  Write-Host ''
  Write-Host ('  ERROR  ' + $_.Exception.Message) -ForegroundColor Red
  if ($debug) {
    Write-Host ''
    Write-Host '  --- detalle tecnico (/debug) ---' -ForegroundColor DarkGray
    Write-Host ($_ | Out-String) -ForegroundColor DarkGray
    Write-Host ($_.ScriptStackTrace) -ForegroundColor DarkGray
  } else {
    Write-Host '  (vuelve a ejecutarlo con  actualizar.bat /debug  para ver el detalle)' -ForegroundColor DarkGray
  }
  Write-Host ''
  Read-Host '  Enter para cerrar'
  exit 1
}
