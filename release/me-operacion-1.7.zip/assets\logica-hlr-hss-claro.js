/* =====================================================================
   logica-hlr-hss-claro.js · Motor "Claro" de la pestaña HLR/HSS
   ---------------------------------------------------------------------
   Copia envuelta de logica-qdn.js + logica-qdn-operaciones.js (Validador
   QDN · Claro), SIN TOCAR una sola linea de sus reglas de negocio ni de
   las operaciones de escritura (bloqueo/desbloqueo/conciliacion).

   Van en el MISMO IIFE (un solo cierre compartido), no en dos separados:
   logica-qdn-operaciones.js referencia directamente variables de
   logica-qdn.js (gestorQdn, cfgQdn, evaluarNegocio, filas,
   filaPasaFiltros, consultarConReintentos, ejecutarPool, render,
   filaDe, datosArchivo) por nombre suelto, exactamente como hacian
   cuando eran dos <script> separados en la pagina original. Separarlos
   en dos IIFE distintos habria roto ese acople sin tocar la logica; UN
   cierre compartido lo preserva intacto.

   Si cambia algo aqui, revisa tambien logica-qdn.js /
   logica-qdn-operaciones.js si siguieran existiendo como referencia.
===================================================================== */
(function () {
"use strict";

/* ---------- logica-qdn.js ---------- */
/* =====================================================================
   logica-qdn.js · Validador HLR/HSS · QDN Móvil Éxito - Claro
   ---------------------------------------------------------------------
   Reglas de negocio de esta herramienta. QDN habla con SU PROPIO servicio
   OAuth2 (el mismo que usan interfaz.py / main.py de consultar-qdn), NO con
   el Keycloak del CM que usa assets/me-api.js: por eso esta herramienta trae
   su propio gestor de token en vez de reusar MEAPI.

   La consulta QDN solo está confirmada contra PDN (así lo indica el equipo);
   el ambiente queda fijo en PDN con los mismos valores que interfaz.py.
===================================================================== */

/* ---------------------------------------------------------------------
   1 · AMBIENTE Y RUTA QDN (mismos valores que interfaz.py / main.py)
--------------------------------------------------------------------- */
const AMBIENTE_QDN = {
    etiqueta: "PDN - Producción",
    token_url: "https://apim.claro.com.co/MsCommunicatAuthToken/User/authenticate",
    client_id: "MOVILEXITO",
    client_secret: "ebaee6c9-513b-4ee6-abc4-c88924006bb8",
    base_apigw: "https://msapigateway-nm-apigateway-aro-prod.apps.prd-claro-co.eastus2.aroapp.io",
    auth_en_cuerpo: true,
    api_usuario: "exitoapi",
    api_clave: "exitoapi"
};
const RUTA_QDN = "/APIMParOrdeConsQDN/MS/CUS/Customer/RSParOrdeConsQDN/V1/ValideQDN/";

const cfgQdn = Object.assign({}, AMBIENTE_QDN, {
    timeoutMs: 30000,
    reintentos: 2,          // hasta 2 reintentos adicionales (3 intentos totales)
    concurrencia: 8         // RN08: máximo operativo recomendado
});

/* ---------------------------------------------------------------------
   2 · TOKEN OAuth2 (mismas estrategias que GestorToken de interfaz.py)
--------------------------------------------------------------------- */
const gestorQdn = {
    token: null, exp: 0, renovando: null,

    intentos(cfg) {
        const basic = btoa(`${cfg.client_id}:${cfg.client_secret}`);
        const form = { "Content-Type": "application/x-www-form-urlencoded" };
        const enCuerpo = ["client_credentials en el cuerpo", {
            headers: form,
            body: new URLSearchParams({
                grant_type: "client_credentials",
                client_id: cfg.client_id, client_secret: cfg.client_secret
            })
        }];
        const enCabecera = ["Basic + client_credentials", {
            headers: Object.assign({}, form, { Authorization: "Basic " + basic }),
            body: new URLSearchParams({ grant_type: "client_credentials" })
        }];
        const lista = [];
        if (cfg.auth_en_cuerpo) { lista.push(enCuerpo, enCabecera); }
        else {
            lista.push(["JSON username/password", {
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ username: cfg.client_id, password: cfg.client_secret })
            }]);
            lista.push(enCabecera, enCuerpo);
        }
        if (cfg.api_usuario) {
            lista.push(["password grant con usuario de API", {
                headers: form,
                body: new URLSearchParams({
                    grant_type: "password", client_id: cfg.client_id,
                    client_secret: cfg.client_secret,
                    username: cfg.api_usuario, password: cfg.api_clave || ""
                })
            }]);
        }
        lista.push(["JSON clientId/clientSecret", {
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ clientId: cfg.client_id, clientSecret: cfg.client_secret })
        }]);
        return lista;
    },

    extraerToken(obj, profundidad) {
        profundidad = profundidad || 0;
        if (profundidad > 4 || obj == null) return null;
        const llaves = ["access_token", "accessToken", "token", "id_token", "jwt",
            "access_Public", "api_request"];
        if (typeof obj === "object" && !Array.isArray(obj)) {
            for (const k of llaves) {
                if (typeof obj[k] === "string" && obj[k].length > 20) return obj[k];
            }
            for (const v of Object.values(obj)) {
                const r = this.extraerToken(v, profundidad + 1);
                if (r) return r;
            }
        } else if (Array.isArray(obj)) {
            for (const v of obj) {
                const r = this.extraerToken(v, profundidad + 1);
                if (r) return r;
            }
        }
        return null;
    },

    async solicitar(cfg) {
        let ultimo = null;
        for (const [nombre, opts] of this.intentos(cfg)) {
            try {
                const r = await fetch(cfg.token_url, Object.assign({ method: "POST" }, opts));
                let cuerpo;
                const texto = await r.text();
                try { cuerpo = texto ? JSON.parse(texto) : null; } catch (e) { cuerpo = texto; }
                if (r.ok) {
                    const token = typeof cuerpo === "string" ? cuerpo : this.extraerToken(cuerpo);
                    if (token) {
                        this.token = token;
                        const vida = (cuerpo && cuerpo.expires_in) ? Number(cuerpo.expires_in) : 1500;
                        this.exp = Date.now() + Math.max(30, vida - 30) * 1000;
                        MEUI.log(`✔ Token QDN obtenido (${nombre}).`, "ok");
                        return token;
                    }
                    ultimo = nombre + ": respuesta 200 sin token";
                } else {
                    ultimo = nombre + `: HTTP ${r.status} — ${String(texto).slice(0, 160)}`;
                }
            } catch (e) { ultimo = nombre + ": " + e.message; }
        }
        throw new Error("No se pudo obtener el token QDN. Último error → " + ultimo);
    },

    async obtener(cfg, forzar) {
        if (!forzar && this.token && Date.now() < this.exp) return this.token;
        if (this.renovando) return this.renovando;
        this.renovando = this.solicitar(cfg).finally(() => { this.renovando = null; });
        return this.renovando;
    },

    reset() { this.token = null; this.exp = 0; }
};

/* ---------------------------------------------------------------------
   3 · CATÁLOGO DE BLOQUEOS Y CATEGORIZACIÓN (sección 15-16-22 de la HU)
--------------------------------------------------------------------- */
// Valor QDN -> interpretación (CA11/CA12/CA13). "0" y "Ninguno" también se
// tratan como "sin bloqueo": así vienen algunos campos de roaming (odb*).
const SIN_BLOQUEO_MARCAS = new Set(["No Registra", "", "0", "Ninguno", null, undefined]);
function interpretarBloqueo(valor) {
    if (valor === "4") return "ACTIVO";
    if (valor === "5") return "HISTORICO";
    if (SIN_BLOQUEO_MARCAS.has(valor)) return "SIN_BLOQUEO";
    return "OTRO"; // código no documentado por la HU: se muestra pero no se cuenta como activo
}

// name -> { etiqueta, grupo } para las características de bloqueo/restricción
// que la HU pide identificar explícitamente (sección 16).
const CATALOGO_BLOQUEOS = {
    "UDC_BLQINCLL-status": { etiqueta: "Llamadas entrantes", grupo: "Nacional" },
    "UDC_BLQOUTCL-status": { etiqueta: "Llamadas salientes", grupo: "Nacional" },
    "UDC_BRRSMS-status": { etiqueta: "SMS", grupo: "Nacional" },
    "UDC_SRVSMSFL-status": { etiqueta: "SMS (perfil)", grupo: "Nacional" },
    "UDC_BRRIDVOZ-clir": { etiqueta: "Identificador de llamadas", grupo: "Nacional" },
    "UDC_BRRLDIFL-osb4": { etiqueta: "LDI total", grupo: "Nacional" },
    "UDC_SRVLDIFL-osb4": { etiqueta: "LDI total", grupo: "Nacional" },
    "UDC_BRRLDIMA-osb1": { etiqueta: "LDI otros indicativos", grupo: "Nacional" },
    "UDC_BRRLDINF-osb2": { etiqueta: "LDI 444 (Infracel)", grupo: "Nacional" },
    "UDC_BRRLDI-osb3": { etiqueta: "LDI sin implementación de red", grupo: "Nacional" },
    "UDC_SRVVIDLL-status_BAIC": { etiqueta: "Video llamada entrante", grupo: "Nacional" },
    "UDC_SRVVIDLL-status_BAOC": { etiqueta: "Video llamada saliente", grupo: "Nacional" },

    "UDC_SRVINTPRE-odbgprs": { etiqueta: "Servicio de datos (GPRS)", grupo: "Datos" },
    "UDC_SRVINTPRE-obGprs": { etiqueta: "Restricción GPRS", grupo: "Datos" },
    "UDC_SRVINTPRE-sgsnAreaRestRcvd": { etiqueta: "Restricciones SGSN", grupo: "Datos" },
    "UDC_SRVINTPRE-sr": { etiqueta: "Redes de otros operadores (datos)", grupo: "Datos" },

    "UDC_SRVROAM-odbBaroam": { etiqueta: "Restricción general de roaming", grupo: "Roaming" },
    "UDC_SRVROAM-odbr": { etiqueta: "Restricción de roaming", grupo: "Roaming" },
    "UDC_SRVROAM-odbic": { etiqueta: "Llamadas entrantes en roaming", grupo: "Roaming" },
    "UDC_SRVROAM-odboc": { etiqueta: "Llamadas salientes en roaming", grupo: "Roaming" },
    "UDC_SRVROAM-sr": { etiqueta: "Redes de otros operadores (roaming)", grupo: "Roaming" },
    "UDC_SRVROAM-odbsci": { etiqueta: "Cambios de desvío en roaming", grupo: "Roaming" },

    "UDC_SRVBSVOZ-ts10BarrByCb": { etiqueta: "Voz (VLR)", grupo: "VLR" },
    "UDC_SRVBSVOZ-ts20BarrByCb": { etiqueta: "SMS (VLR)", grupo: "VLR" },
    "UDC_SRVBSVOZ-ts60BarrByCb": { etiqueta: "Fax (VLR)", grupo: "VLR" },
    "UDC_SRVBSVOZ-bs20BarrByCb": { etiqueta: "Datos asíncronos (VLR)", grupo: "VLR" },
    "UDC_SRVBSVOZ-bs30BarrByCb": { etiqueta: "Datos síncronos (VLR)", grupo: "VLR" },
    "UDC_SRVBSVOZ-bs40BarrByCb": { etiqueta: "Acceso PAD (VLR)", grupo: "VLR" }
};

// Suffijos de UDC_SRVBSVOZ- que son servicio de telefonía (el resto de ese
// mismo prefijo cae en VLR/MSC: comparten prefijo pero no significado).
const BSVOZ_TELEFONIA = new Set(["bcieID", "csiState", "imsiActive", "operatorServiceName",
    "ucsiserv", "msisdn"]);

function sufijo(name) {
    const i = name.indexOf("-");
    return i >= 0 ? name.slice(i + 1) : name;
}

/** Devuelve la categoría (sección 22 de la HU) para una característica. */
function categoriaDe(name, friendlyName) {
    if (name === "UDC") return "identidad";               // nota UDC-xxxx del servicio
    if (CATALOGO_BLOQUEOS[name]) return "bloqueos";
    if (name.indexOf("TITAN_SRVVOLTE-") === 0) return "volte";
    if (name.indexOf("STP_STPSUB-") === 0) return "portabilidad";
    if (name.indexOf("COTA_PRSSIMCD-") === 0) return "cota";
    if (name.indexOf("UDC_SRVROAM-") === 0) return "roaming";
    if (name.indexOf("UDC_SRVAVM-") === 0) return "desvios";
    if (name.indexOf("UDC_BLQ") === 0 || name.indexOf("UDC_BRR") === 0) return "bloqueos";
    if (name.indexOf("UDC_SRVBSVOZ-") === 0) {
        return BSVOZ_TELEFONIA.has(sufijo(name)) ? "servicios" : "vlr";
    }
    if (name.indexOf("UDC_SRVROUT-") === 0) return "vlr";
    if (name.indexOf("UDC_SRVCWA-") === 0) return "servicios";
    if (name.indexOf("UDC_SRVVIDLL-") === 0) return "servicios";
    if (name.indexOf("UDC_SRVSMSFL-") === 0) return "servicios";
    if (name.indexOf("UDC_SRVSIDVZ-") === 0) return "servicios";
    if (name.indexOf("UDC_SRVTRLLA-") === 0) return "servicios";
    if (name.indexOf("UDC_SRVACWI-") === 0 || name.indexOf("UDC_SRVRBT-") === 0 ||
        name.indexOf("UDC_SRVPMT-") === 0 || name.indexOf("UDC_SRVFRDPR-") === 0) return "servicios";
    if (name.indexOf("UDC_SRV5GNE-") === 0) return "servicios";
    if (name.indexOf("UDC_PRSSIMCD-") === 0) return "identidad";
    if (name.indexOf("UDC_PFAPNPRV-") === 0 || name.indexOf("UDC_SRVCTMMS-") === 0 ||
        name.indexOf("UDC_SRVVVM-") === 0 || name.indexOf("UDC_SRVINT-") === 0) return "datos";
    if (name.indexOf("UDC_SRVINTPRE-") === 0) return "datos";
    return "otros";
}

const NOMBRES_CATEGORIA = {
    identidad: "Identidad", servicios: "Servicios", bloqueos: "Bloqueos",
    datos: "Datos / Internet", roaming: "Roaming", desvios: "Desvíos",
    vlr: "VLR / MSC", volte: "VoLTE", portabilidad: "Portabilidad",
    cota: "COTA", otros: "Otros"
};
const ORDEN_CATEGORIAS = ["identidad", "servicios", "bloqueos", "datos", "roaming",
    "desvios", "vlr", "volte", "portabilidad", "cota", "otros"];

/* ---------------------------------------------------------------------
   4 · PARSEO DEL RESPONSE (secciones 3, 11-20, 32)
--------------------------------------------------------------------- */
function buscarCaracteristica(lista, name) {
    const f = lista.find(c => c.name === name);
    return f ? f.value : null;
}

/**
 * Valor tal como lo reportó el HLR.
 *   · Si la característica NO vino en el response  -> "—" (no hay dato).
 *   · Si vino con el texto "No Registra"           -> se muestra "No Registra".
 * La diferencia importa: "No Registra" es una afirmación del HLR; "—" es
 * ausencia de información y no se debe presentar como si fuera un dato.
 */
function valorHLR(v) {
    return (v === null || v === undefined || v === "") ? "—" : String(v);
}

/**
 * Éxito REAL leyendo el cuerpo, no el HTTP: mismo criterio que
 * evaluar_negocio()/_recorrer() de interfaz.py. Un HTTP 200 con
 * responseCode>=400, success:false o un objeto `error` con contenido
 * NO es una consulta exitosa.
 */
function evaluarNegocio(cuerpo) {
    const hall = { fallo: false, codigo: null, codigoMsg: null, detalle: null };
    const vacio = v => v === null || v === undefined || v === ""
        || (Array.isArray(v) && !v.length)
        || (typeof v === "object" && !Array.isArray(v) && !Object.keys(v).length);

    (function recorrer(obj, enError) {
        if (obj === null || typeof obj !== "object") return;
        if (Array.isArray(obj)) { obj.forEach(v => recorrer(v, enError)); return; }

        if (obj.success === false) hall.fallo = true;
        ["statusCode", "responseCode"].forEach(k => {
            const n = parseInt(obj[k], 10);
            if (!isNaN(n) && n >= 400) {
                hall.fallo = true;
                if (hall.codigo === null) hall.codigo = n;
            }
        });

        Object.keys(obj).forEach(k => {
            const v = obj[k];
            const hijoError = enError || k === "error";
            if (k === "error" && !vacio(v)) hall.fallo = true;
            if (hijoError && (k === "message" || k === "description")
                && typeof v === "string" && !hall.detalle) hall.detalle = v;
            if (hijoError && k === "messageCode" && typeof v === "string"
                && !hall.codigoMsg) hall.codigoMsg = v;
            recorrer(v, hijoError);
        });
    })(cuerpo, false);

    return { ok: !hall.fallo, codigo: hall.codigo, codigoMsg: hall.codigoMsg, detalle: hall.detalle };
}

function friendlyDeDesvio(status) {
    return status && status !== "No Registra" ? "Activo" : (status ? status : "—");
}

function textoPortabilidad(pt) {
    if (pt === "0") return "Número nativo del operador";
    if (pt === "1") return "Número en otro operador (portado)";
    if (pt === null || pt === undefined || pt === "No Registra") return "—";
    return "PT " + pt;
}

/** Convierte el response crudo de QDN en la fila que consume la tabla y el detalle. */
function procesarRespuestaQDN(msisdn, datos, meta) {
    const res = (datos && datos.result) || {};
    const rc = Array.isArray(res.resourceCharacteristic) ? res.resourceCharacteristic : [];

    // Nota especial "UDC" (p. ej. "UDC-3503 ... was not found in the Database").
    const notaUDC = rc.find(c => c.name === "UDC");

    // ---- categorización completa: no se asume que 'name' es único --------
    const categorias = {};
    ORDEN_CATEGORIAS.forEach(c => { categorias[c] = []; });
    rc.forEach(c => {
        const cat = categoriaDe(c.name, c.friendly_name);
        categorias[cat].push({ name: c.name, friendly: c.friendly_name || "", valor: c.value });
    });

    // ---- bloqueos: activos / históricos / otros ---------------------------
    // `bloqueosEvaluados` distingue "no hay bloqueos" (se revisaron y están
    // limpios) de "no se pudo revisar" (la línea no trajo ninguna
    // característica de bloqueo, p. ej. porque está inactiva o no existe).
    let bloqueosEvaluados = false;
    const bloqueosActivos = [], bloqueosHistoricos = [], bloqueosOtros = [];
    Object.entries(CATALOGO_BLOQUEOS).forEach(([name, info]) => {
        const c = rc.find(x => x.name === name);
        if (!c) return;
        bloqueosEvaluados = true;
        const estado = interpretarBloqueo(c.value);
        const item = { name, etiqueta: info.etiqueta, grupo: info.grupo, valor: c.value, estado };
        if (estado === "ACTIVO") bloqueosActivos.push(item);
        else if (estado === "HISTORICO") bloqueosHistoricos.push(item);
        else if (estado === "OTRO") bloqueosOtros.push(item);
    });

    // ---- resumen para la tabla (columnas de la sección 10) -----------------
    const imsi = buscarCaracteristica(rc, "UDC_PRSSIMCD-imsi") || buscarCaracteristica(rc, "UDC_SRV5GNE-imsi");
    const imei = buscarCaracteristica(rc, "UDC_PRSSIMCD-imeisv");
    // El ICCID no se muestra en la tabla: lo necesita el proceso de
    // conciliación (logica-qdn-operaciones.js) para armar el PATCH.
    const iccid = buscarCaracteristica(rc, "COTA_PRSSIMCD-iccid");
    const estadoImsi = buscarCaracteristica(rc, "UDC_SRVBSVOZ-imsiActive")
        || (buscarCaracteristica(rc, "UDC_PRSSIMCD-isActiveIMSI") === "true" ? "Activa" : null);
    const cincoG = buscarCaracteristica(rc, "UDC_SRV5GNE-supportNewRadioSecondaryRAT");
    const telefonia = buscarCaracteristica(rc, "UDC_SRVBSVOZ-bcieID");
    const smsEnvio = buscarCaracteristica(rc, "UDC_SRVSMSFL-TS22");
    const smsRecep = buscarCaracteristica(rc, "UDC_SRVSMSFL-TS21");
    const datosServ = buscarCaracteristica(rc, "UDC_SRVINTPRE-msisdn"); // friendly_name real: "SERVICIO DE DATOS"
    const roamGeneral = buscarCaracteristica(rc, "UDC_SRVROAM-odbBaroam") || buscarCaracteristica(rc, "UDC_SRVROAM-odbr");
    const desvioStatus = buscarCaracteristica(rc, "UDC_SRVAVM-status");
    const desvioTipo = buscarCaracteristica(rc, "UDC_SRVAVM-replaceCFConditional");
    const apn = buscarCaracteristica(rc, "UDC_PFAPNPRV-apn");
    const ip = buscarCaracteristica(rc, "UDC_PFAPNPRV-ipv4Address");
    const ipTipo = buscarCaracteristica(rc, "UDC_PFAPNPRV-typeip");
    const pt = buscarCaracteristica(rc, "STP_STPSUB-pt");

    const operationalState = (res.operationalState || "").toLowerCase();

    // ---- coherencia de la respuesta ---------------------------------------
    // El QDN devuelve en result.id la línea consultada. Si no coincide con lo
    // que se pidió, la respuesta no corresponde a esta línea y no se puede
    // presentar su contenido como si fuera de ella.
    const inconsistencias = [];
    const idDevuelto = soloDigitos(res.id);
    if (idDevuelto && !idDevuelto.endsWith(soloDigitos(msisdn))) {
        inconsistencias.push(`El servicio respondió por la línea ${res.id}, no por ${msisdn}.`);
    }
    if (!operationalState) {
        inconsistencias.push("La respuesta no trae operationalState.");
    }

    return {
        msisdn,
        estadoProceso: inconsistencias.length ? "INCONSISTENTE" : "SUCCESS",
        inconsistencias,
        bloqueosEvaluados,
        intentos: meta.intentos, ms: meta.ms,
        httpStatus: meta.httpStatus,
        responseCode: datos.responseCode, messageCode: datos.messageCode,
        message: datos.message, legacy: datos.legacy,
        transactionId: datos.transactionId, timestamp: datos.timestamp,
        operationalState,
        resourceId: res.id, resourceType: res["@type"], resourceCategory: res.category,
        resourceDescripcion: res.description, startOperatingDate: res.startOperatingDate,
        notaUDC: notaUDC ? (notaUDC.friendly_name || notaUDC.value) : null,
        notas: Array.isArray(res.note) ? res.note.map(n => n.text).filter(Boolean) : [],

        resumen: {
            imsi: valorHLR(imsi), imei: valorHLR(imei), iccid: valorHLR(iccid),
            estadoImsi: valorHLR(estadoImsi),
            cincoG: (cincoG === null || cincoG === undefined) ? "—"
                : (cincoG === "true" || cincoG === true) ? "Sí"
                    : (cincoG === "false" || cincoG === false) ? "No" : String(cincoG),
            telefonia: valorHLR(telefonia),
            sms: (smsEnvio === "Activo" && smsRecep === "Activo") ? "Activo"
                : valorHLR(smsEnvio || smsRecep),
            datos: valorHLR(datosServ),
            // Coherente con la columna Bloqueos: si hay restricciones activas
            // del grupo Roaming no se puede decir "sin restricción" aunque el
            // barring general (odbBaroam) venga en "Ninguno".
            roaming: (() => {
                const roam = bloqueosActivos.filter(b => b.grupo === "Roaming");
                if (roam.length) return `⚠ ${roam.length} restricción${roam.length > 1 ? "es" : ""} de roaming`;
                if (roamGeneral === null || roamGeneral === undefined) return "—";
                return SIN_BLOQUEO_MARCAS.has(roamGeneral) ? "Sin restricción" : roamGeneral;
            })(),
            desvio: valorHLR(desvioStatus), desvioTipo: valorHLR(desvioTipo),
            apn: valorHLR(apn),
            ip: valorHLR(ip !== null && ip !== undefined && ip !== "No Registra" ? ip : (ip === null ? ipTipo : ip)),
            portabilidad: textoPortabilidad(pt)
        },

        bloqueosActivos, bloqueosHistoricos, bloqueosOtros,
        categorias,
        raw: datos
    };
}

function filaError(msisdn, estadoProceso, detalle, meta) {
    return {
        msisdn, estadoProceso, detalle: detalle || "",
        intentos: (meta && meta.intentos) || 0, ms: (meta && meta.ms) || null,
        httpStatus: meta && meta.httpStatus,
        resumen: {}, bloqueosActivos: [], bloqueosHistoricos: [], bloqueosOtros: [],
        categorias: {}, raw: (meta && meta.raw) || null
    };
}

/* ---------------------------------------------------------------------
   5 · ENTRADA: MSISDN individual y masivo (sección 4-5)
--------------------------------------------------------------------- */
function soloDigitos(v) { return String(v || "").replace(/\D/g, ""); }

/** Separa por salto de línea, coma, punto y coma o tabulación (sección 4.2-A). */
function parseMsisdns(texto) {
    const vistos = new Set(), orden = [], invalidas = [];
    let total = 0, duplicados = 0;
    String(texto || "").split(/[\s,;|\t\r\n]+/).forEach(bruto => {
        const crudo = String(bruto).trim();
        if (!crudo) return;
        total++;
        const num = soloDigitos(crudo);
        if (num.length < 7 || num.length > 15) { invalidas.push(crudo); return; }
        if (vistos.has(num)) { duplicados++; return; }
        vistos.add(num); orden.push(num);
    });
    return { lineas: orden, invalidas, total, duplicados };
}

/* ---------------------------------------------------------------------
   6 · CONCURRENCIA, TIMEOUT Y REINTENTOS (secciones 6-9, 27-29)
--------------------------------------------------------------------- */
async function ejecutarPool(items, limite, worker) {
    let i = 0;
    const total = items.length;
    const n = Math.max(1, Math.min(limite || 8, total || 1));
    const ejecutores = Array.from({ length: n }, async () => {
        while (i < total) {
            const idx = i++;
            await worker(items[idx], idx);
        }
    });
    await Promise.all(ejecutores);
}

async function consultarUnaVez(msisdn, cfg, token) {
    const url = cfg.base_apigw.replace(/\/$/, "") + RUTA_QDN + msisdn;
    const controlador = new AbortController();
    const temporizador = setTimeout(() => controlador.abort(), cfg.timeoutMs);
    const t0 = performance.now();
    try {
        const r = await fetch(url, {
            method: "GET", signal: controlador.signal,
            headers: {
                "Accept": "application/json",
                "Authorization": "Bearer " + token,
                "transactionId": (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random())
            }
        });
        const ms = Math.round(performance.now() - t0);
        const texto = await r.text();
        let cuerpo = null;
        try { cuerpo = texto ? JSON.parse(texto) : null; } catch (e) { /* respuesta no JSON */ }
        return { ok: r.ok, status: r.status, cuerpo, texto, ms };
    } finally {
        clearTimeout(temporizador);
    }
}

/** Consulta con hasta cfg.reintentos reintentos ADICIONALES, solo por timeout (sección 28). */
async function consultarConReintentos(msisdn, cfg) {
    let intentos = 0;
    let ultimoErrorConexion = null;
    let tokenRenovado = false;

    while (true) {
        intentos++;
        let token;
        try {
            token = await gestorQdn.obtener(cfg);
        } catch (e) {
            return filaError(msisdn, "ERROR", "No se pudo autenticar: " + e.message, { intentos });
        }

        let resp;
        try {
            resp = await consultarUnaVez(msisdn, cfg, token);
        } catch (e) {
            const esTimeout = e && e.name === "AbortError";
            // cfg.reintentos + 1 = intentos totales permitidos (1 inicial + N reintentos).
            if (esTimeout && intentos < cfg.reintentos + 1) continue; // retry solo por timeout
            if (esTimeout) return filaError(msisdn, "TIMEOUT", "Se agotaron los reintentos por timeout.", { intentos });
            ultimoErrorConexion = e.message || String(e);
            return filaError(msisdn, "ERROR", "Error de comunicación: " + ultimoErrorConexion, { intentos });
        }

        // 401/403: el token venció -> se renueva UNA vez y se repite sin gastar reintento.
        if ((resp.status === 401 || resp.status === 403) && !tokenRenovado) {
            tokenRenovado = true;
            gestorQdn.reset();
            intentos--; // no cuenta como intento fallido
            continue;
        }

        if (!resp.ok) {
            // Errores funcionales (400/401/403/404/5xx): NO se reintentan (sección 28).
            const msg = (resp.cuerpo && (resp.cuerpo.message || resp.cuerpo.messageCode))
                || (resp.texto || "").slice(0, 200) || ("HTTP " + resp.status);
            return filaError(msisdn, "ERROR", msg, { intentos, httpStatus: resp.status, raw: resp.cuerpo });
        }

        // El éxito real no es el HTTP 200: se evalúa el cuerpo (misma regla
        // que evaluar_negocio() de interfaz.py).
        const negocio = evaluarNegocio(resp.cuerpo);
        if (!negocio.ok) {
            const partes = [];
            if (negocio.codigo) partes.push("código " + negocio.codigo);
            if (negocio.codigoMsg) partes.push(negocio.codigoMsg);
            if (negocio.detalle) partes.push(negocio.detalle);
            return filaError(msisdn, "ERROR",
                `HTTP ${resp.status}, pero el cuerpo reporta fallo` +
                (partes.length ? ": " + partes.join(" · ") : "."),
                { intentos, httpStatus: resp.status, raw: resp.cuerpo });
        }

        if (!resp.cuerpo || !resp.cuerpo.result || !Array.isArray(resp.cuerpo.result.resourceCharacteristic)) {
            return filaError(msisdn, "ERROR",
                "La respuesta no tiene la estructura esperada (result.resourceCharacteristic).",
                { intentos, httpStatus: resp.status, raw: resp.cuerpo });
        }

        return procesarRespuestaQDN(msisdn, resp.cuerpo, { intentos, ms: resp.ms, httpStatus: resp.status });
    }
}

/* ---------------------------------------------------------------------
   7 · ESTADO DE LA HERRAMIENTA
--------------------------------------------------------------------- */
let filas = [];                 // resultado consolidado, en el orden de entrada
let dataTable = null;
let corriendo = false;
let cancelar = false;
const filtros = { estado: new Set(), bloqueo: new Set(), cincoG: new Set(), roaming: new Set(), proceso: new Set() };
const columnas = ["msisdn", "estado", "imsi", "imei", "cincoG", "telefonia", "sms",
    "datos", "roaming", "bloqueos", "desvio", "apn", "ip", "portabilidad", "detalle"];
const ETIQUETA_COLUMNA = {
    msisdn: "MSISDN", estado: "Estado", imsi: "IMSI", imei: "IMEI", cincoG: "5G",
    telefonia: "Telefonía", sms: "SMS", datos: "Datos", roaming: "Roaming",
    bloqueos: "Bloqueos", desvio: "Desvío", apn: "APN", ip: "IP",
    portabilidad: "Portabilidad", detalle: "Detalle"
};
const columnasOcultas = new Set();

/* ---------------------------------------------------------------------
   8 · DERIVADOS POR FILA (estado de tabla, texto de bloqueos)
--------------------------------------------------------------------- */
function estadoTabla(f) {
    if (f.estadoProceso !== "SUCCESS") return f.estadoProceso; // TIMEOUT | ERROR | INVALID | PENDING | PROCESSING
    return (f.operationalState || "desconocido").toUpperCase();
}

function textoBloqueos(f) {
    // Sin características de bloqueo en el response no se puede afirmar que la
    // línea está limpia: se dice "Sin datos", no "Sin bloqueos".
    if (!f.bloqueosEvaluados) return "Sin datos";
    const n = (f.bloqueosActivos || []).length;
    return n ? `⚠ ${n} bloqueo${n > 1 ? "s" : ""} activo${n > 1 ? "s" : ""}` : "Sin bloqueos";
}

/* ---------------------------------------------------------------------
   9 · CONSULTA INDIVIDUAL Y MASIVA (secciones 4, 25, 26)
--------------------------------------------------------------------- */
let lineasArchivo = null; // lo llena configurarArchivo() al leer Excel/CSV: mismo formato que parseMsisdns()

/**
 * MSISDN -> { imsi, iccid, ki } tomados de columnas OPCIONALES del archivo.
 * Solo lo consumen las operaciones de provisión (logica-qdn-operaciones.js):
 * la consulta QDN no necesita nada de esto.
 */
const datosArchivo = new Map();

/** Busca una columna por nombre normalizado (sin espacios, tildes ni signos). */
function columnaPorNombre(columnas, nombres) {
    const norm = s => MEUI.normalizar
        ? MEUI.normalizar(String(s || "")).replace(/[^a-z0-9]/g, "")
        : String(s || "").toLowerCase().replace(/[^a-z0-9]/g, "");
    return (columnas || []).find(c => nombres.indexOf(norm(c)) >= 0) || null;
}

function obtenerLineas() {
    if (lineasArchivo && lineasArchivo.lineas && lineasArchivo.lineas.length) return lineasArchivo;
    const el = MEUI.$("#inputLineas");
    return el ? parseMsisdns(el.value) : { lineas: [], invalidas: [], total: 0, duplicados: 0 };
}

function actualizarProgreso(hechas, total) {
    const wrap = MEUI.$("#progresoWrap");
    if (!wrap) return;
    wrap.style.display = total ? "" : "none";
    const pct = total ? Math.round((hechas / total) * 100) : 0;
    const contador = { SUCCESS: 0, TIMEOUT: 0, ERROR: 0, INVALID: 0 };
    filas.forEach(f => {
        if (f.estadoProceso === "SUCCESS") contador.SUCCESS++;
        else if (contador[f.estadoProceso] !== undefined) contador[f.estadoProceso]++;
    });
    const conBloqueo = filas.filter(f => f.estadoProceso === "SUCCESS" && (f.bloqueosActivos || []).length).length;
    MEUI.$("#progresoTexto").textContent =
        `Procesando: ${hechas} / ${total}  ·  Exitosas ${contador.SUCCESS} (${conBloqueo} con bloqueos)` +
        `  ·  Timeout ${contador.TIMEOUT}  ·  Errores ${contador.ERROR}  ·  Inválidas ${contador.INVALID}`;
    MEUI.$("#progresoPct").textContent = pct + "%";
    MEUI.$("#progresoBar").style.width = pct + "%";
}

async function consultar() {
    if (corriendo) return;
    const entrada = obtenerLineas();
    if (!entrada.lineas.length) {
        MEUI.toast("No hay líneas válidas para consultar.", "warn");
        return;
    }
    MEUI.log(`Registros recibidos: ${entrada.total}  ·  MSISDN válidos: ${entrada.lineas.length}  ·  ` +
        `Inválidos: ${entrada.invalidas.length}  ·  Duplicados: ${entrada.duplicados}`, "info");
    if (entrada.invalidas.length) {
        MEUI.log("Inválidos (no se consultan): " + entrada.invalidas.slice(0, 15).join(", ") +
            (entrada.invalidas.length > 15 ? "…" : ""), "warn");
    }

    corriendo = true; cancelar = false;
    const btn = MEUI.$("#btnConsultar");
    if (btn) btn.disabled = true;

    filas = entrada.lineas.map(m => ({ msisdn: m, estadoProceso: "PENDING", resumen: {}, categorias: {} }));
    entrada.invalidas.forEach(v => filas.push(filaError(v, "INVALID", "MSISDN con formato inválido.")));
    render();

    const cfg = cfgQdn;
    const concurrencia = Math.max(1, Math.min(15, Number(MEUI.$("#cfgConcurrencia").value) || 8));
    cfg.concurrencia = concurrencia;

    let hechas = 0;
    let ultimoRender = 0;
    const total = entrada.lineas.length;
    const porMsisdn = new Map(filas.map(f => [f.msisdn, f]));

    await ejecutarPool(entrada.lineas, concurrencia, async (msisdn) => {
        if (cancelar) return;
        const fila = porMsisdn.get(msisdn);
        fila.estadoProceso = "PROCESSING";
        const resultado = await consultarConReintentos(msisdn, cfg);
        Object.assign(fila, resultado);
        hechas++;
        actualizarProgreso(hechas, total);
        const ahora = performance.now();
        if (ahora - ultimoRender > 400 || hechas === total) { ultimoRender = ahora; render(); }
    });

    corriendo = false;
    if (btn) btn.disabled = false;
    render();

    const c = { SUCCESS: 0, TIMEOUT: 0, ERROR: 0, INVALID: 0, INCONSISTENTE: 0 };
    filas.forEach(f => { if (c[f.estadoProceso] !== undefined) c[f.estadoProceso]++; });
    const conBloqueo = filas.filter(f => f.estadoProceso === "SUCCESS" && (f.bloqueosActivos || []).length).length;
    // "Sin bloqueos" solo cuenta las líneas donde SÍ se pudieron evaluar.
    const sinBloqueo = filas.filter(f => f.estadoProceso === "SUCCESS"
        && f.bloqueosEvaluados && !(f.bloqueosActivos || []).length).length;
    const sinDatosBloqueo = c.SUCCESS - conBloqueo - sinBloqueo;
    MEUI.log(`Resultado de la consulta — Total: ${filas.length}  ·  Exitosas: ${c.SUCCESS}  ·  ` +
        `Con bloqueos: ${conBloqueo}  ·  Sin bloqueos: ${sinBloqueo}  ·  ` +
        `Sin datos de bloqueo: ${sinDatosBloqueo}  ·  Inconsistentes: ${c.INCONSISTENTE}  ·  ` +
        `Timeout: ${c.TIMEOUT}  ·  Errores: ${c.ERROR}  ·  Inválidas: ${c.INVALID}`, "ok");
    if (c.INCONSISTENTE) {
        MEUI.log(`⚠ ${c.INCONSISTENTE} respuesta(s) no corresponden a la línea consultada o vienen incompletas. ` +
            `Revísalas con la tarjeta «Revisar respuesta» antes de usarlas como evidencia.`, "warn");
    }
    MEUI.toast(`Consulta terminada: ${filas.length} líneas procesadas.`, "ok");
}

/* ---------------------------------------------------------------------
   10 · FILTROS Y KPIs
--------------------------------------------------------------------- */
const PROCESOS_FALLIDOS = ["ERROR", "TIMEOUT", "INVALID"];

function filaPasaFiltros(f) {
    if (filtros.proceso.size) {
        // "FALLIDAS" agrupa todo lo que no dejó un resultado utilizable.
        const agrupado = filtros.proceso.has("FALLIDAS")
            && PROCESOS_FALLIDOS.indexOf(f.estadoProceso) >= 0;
        if (!agrupado && !filtros.proceso.has(f.estadoProceso)) return false;
    }
    if (filtros.estado.size && !filtros.estado.has(estadoTabla(f))) return false;
    if (filtros.bloqueo.size) {
        const con = f.estadoProceso === "SUCCESS" && (f.bloqueosActivos || []).length > 0;
        if (filtros.bloqueo.has("CON") && !con) return false;
        if (filtros.bloqueo.has("SIN") && con) return false;
    }
    if (filtros.cincoG.size && !filtros.cincoG.has((f.resumen && f.resumen.cincoG) || "—")) return false;
    if (filtros.roaming.size) {
        const restringido = f.estadoProceso === "SUCCESS" &&
            f.resumen && f.resumen.roaming !== "Sin restricción" && f.resumen.roaming !== "—";
        if (filtros.roaming.has("RESTRINGIDO") && !restringido) return false;
        if (filtros.roaming.has("SIN_RESTRICCION") && restringido) return false;
    }
    return true;
}

function pintarFiltro(ul, dim, opciones) {
    if (!ul) return;
    ul.innerHTML = opciones.map(([valor, etiqueta, n]) => `
        <li class="form-check px-2">
            <input class="form-check-input" type="checkbox" value="${MEUI.esc(valor)}"
                id="f_${dim}_${MEUI.esc(valor)}" ${filtros[dim].has(valor) ? "checked" : ""}>
            <label class="form-check-label" for="f_${dim}_${MEUI.esc(valor)}">${MEUI.esc(etiqueta)} <small class="text-muted">(${n})</small></label>
        </li>`).join("") || `<li class="px-2 text-muted small">Sin datos aún.</li>`;
    ul.querySelectorAll("input").forEach(chk => chk.addEventListener("change", () => {
        if (chk.checked) filtros[dim].add(chk.value); else filtros[dim].delete(chk.value);
        render();
    }));
}

function actualizarFiltros() {
    const cont = v => filas.filter(f => estadoTabla(f) === v).length;
    const estados = [...new Set(filas.map(estadoTabla))].sort();
    pintarFiltro(MEUI.$("#fEstado"), "estado", estados.map(v => [v, v, cont(v)]));

    const conB = filas.filter(f => f.estadoProceso === "SUCCESS" && (f.bloqueosActivos || []).length).length;
    const sinB = filas.filter(f => f.estadoProceso === "SUCCESS").length - conB;
    pintarFiltro(MEUI.$("#fBloqueo"), "bloqueo",
        [["CON", "Con bloqueos activos", conB], ["SIN", "Sin bloqueos", sinB]]);

    const si5g = filas.filter(f => f.resumen && f.resumen.cincoG === "Sí").length;
    const no5g = filas.filter(f => f.resumen && f.resumen.cincoG === "No").length;
    pintarFiltro(MEUI.$("#f5g"), "cincoG", [["Sí", "Con 5G", si5g], ["No", "Sin 5G", no5g]]);

    const rRestr = filas.filter(f => f.estadoProceso === "SUCCESS" && f.resumen &&
        f.resumen.roaming !== "Sin restricción" && f.resumen.roaming !== "—").length;
    const rLibre = filas.filter(f => f.estadoProceso === "SUCCESS").length - rRestr;
    pintarFiltro(MEUI.$("#fRoaming"), "roaming",
        [["RESTRINGIDO", "Con restricción", rRestr], ["SIN_RESTRICCION", "Sin restricción", rLibre]]);
}

function actualizarKPIs() {
    const c = { SUCCESS: 0, TIMEOUT: 0, ERROR: 0, INVALID: 0, INCONSISTENTE: 0 };
    filas.forEach(f => { if (c[f.estadoProceso] !== undefined) c[f.estadoProceso]++; });
    const activas = filas.filter(f => estadoTabla(f) === "ACTIVE").length;
    const inactivas = filas.filter(f => estadoTabla(f) === "INACTIVE").length;
    const conBloqueo = filas.filter(f => f.estadoProceso === "SUCCESS" && (f.bloqueosActivos || []).length).length;
    MEUI.$("#kpiActivas").textContent = activas;
    MEUI.$("#kpiInactivas").textContent = inactivas;
    MEUI.$("#kpiBloqueos").textContent = conBloqueo;
    MEUI.$("#kpiRevisar").textContent = c.INCONSISTENTE;
    MEUI.$("#kpiErrores").textContent = c.ERROR + c.TIMEOUT + c.INVALID;
}

function alternarKpi(el) {
    const dim = el.dataset.fdim, val = el.dataset.fval;
    const activo = el.classList.toggle("kpi-activo");
    MEUI.$$(`.me-kpi[data-fdim="${dim}"]`).forEach(o => { if (o !== el) o.classList.remove("kpi-activo"); });
    filtros[dim].clear();
    if (activo) filtros[dim].add(val);
    render();
}

function limpiarFiltros() {
    Object.values(filtros).forEach(s => s.clear());
    MEUI.$$(".me-kpi.kpi-activo").forEach(k => k.classList.remove("kpi-activo"));
    render();
}

/* ---------------------------------------------------------------------
   11 · COLUMNAS (mostrar/ocultar)
--------------------------------------------------------------------- */
function pintarMenuColumnas() {
    const ul = MEUI.$("#menuColumnas");
    if (!ul) return;
    ul.innerHTML = columnas.map((c, i) => `
        <li class="form-check px-2">
            <input class="form-check-input" type="checkbox" data-col="${i}"
                id="col_${c}" ${columnasOcultas.has(c) ? "" : "checked"}>
            <label class="form-check-label" for="col_${c}">${ETIQUETA_COLUMNA[c]}</label>
        </li>`).join("");
    ul.querySelectorAll("input").forEach(chk => chk.addEventListener("change", () => {
        const c = columnas[Number(chk.dataset.col)];
        if (chk.checked) columnasOcultas.delete(c); else columnasOcultas.add(c);
        if (dataTable) { dataTable.column(Number(chk.dataset.col)).visible(chk.checked); MEUI.ajustarTablas(); }
    }));
}

/* ---------------------------------------------------------------------
   12 · TABLA (DataTables en modo data + columns)
--------------------------------------------------------------------- */
function celdaEstado(f) {
    const e = estadoTabla(f);
    const cls = { ACTIVE: "ok", ACTIVO: "ok", INACTIVE: "off", INACTIVO: "off",
        TIMEOUT: "warn", INCONSISTENTE: "warn", ERROR: "err", INVALID: "err",
        PENDING: "neutro", PROCESSING: "info" }[e] || "neutro";
    // Aviso visible en la propia tabla cuando el HLR dijo que el número no
    // está en base de datos, o cuando la respuesta no cuadra con la consulta.
    const avisos = [];
    if (f.notaUDC) avisos.push(f.notaUDC);
    (f.inconsistencias || []).forEach(t => avisos.push(t));
    const icono = avisos.length
        ? ` <span class="aviso-fila" title="${MEUI.esc(avisos.join(" · "))}">⚠</span>` : "";
    return `<span class="badge-estado ${cls}">${MEUI.esc(e)}</span>${icono}`;
}

function construirDataTable() {
    dataTable = new DataTable("#tablaResultados", MEUI.opcionesTabla({
        data: [],
        columns: [
            { data: "msisdn", title: "MSISDN", render: (v, t, f) => `<span class="me-mono">${MEUI.esc(v)}</span>` },
            { data: null, title: "Estado", render: (f) => celdaEstado(f) },
            { data: null, title: "IMSI", render: f => MEUI.esc((f.resumen && f.resumen.imsi) || "—") },
            { data: null, title: "IMEI", render: f => MEUI.esc((f.resumen && f.resumen.imei) || "—") },
            { data: null, title: "5G", render: f => MEUI.esc((f.resumen && f.resumen.cincoG) || "—") },
            { data: null, title: "Telefonía", render: f => MEUI.esc((f.resumen && f.resumen.telefonia) || "—") },
            { data: null, title: "SMS", render: f => MEUI.esc((f.resumen && f.resumen.sms) || "—") },
            { data: null, title: "Datos", render: f => MEUI.esc((f.resumen && f.resumen.datos) || "—") },
            { data: null, title: "Roaming", render: f => MEUI.esc((f.resumen && f.resumen.roaming) || "—") },
            {
                data: null, title: "Bloqueos", render: f => f.estadoProceso === "SUCCESS"
                    ? `<span class="${(f.bloqueosActivos || []).length ? "chip-bloqueo activo" : "chip-bloqueo"}">${MEUI.esc(textoBloqueos(f))}</span>`
                    : "—"
            },
            { data: null, title: "Desvío", render: f => MEUI.esc((f.resumen && f.resumen.desvio) || "—") },
            { data: null, title: "APN", render: f => MEUI.esc((f.resumen && f.resumen.apn) || "—") },
            { data: null, title: "IP", render: f => MEUI.esc((f.resumen && f.resumen.ip) || "—") },
            { data: null, title: "Portabilidad", render: f => MEUI.esc((f.resumen && f.resumen.portabilidad) || "—") },
            {
                data: null, title: "Detalle", orderable: false, className: "col-accion",
                render: f => `<button class="btn btn-sm btn-me-line btn-detalle" data-msisdn="${MEUI.esc(f.msisdn)}"
                    title="Ver detalle completo">👁</button>`
            }
        ]
    }));
    // DataTables reorganiza el DOM al activar scrollX/scrollY (separa cabecera
    // y cuerpo en tablas distintas): el binding delegado vía dataTable.on()
    // sigue funcionando porque apunta al nodo real, a diferencia de un
    // querySelector tomado una sola vez sobre el <tbody> original.
    dataTable.on("click", "button.btn-detalle", function (e) {
        e.stopPropagation();
        abrirDetalle(this.dataset.msisdn);
    });
    dataTable.on("click", "tbody tr", function () {
        const fila = dataTable.row(this).data();
        if (fila && fila.msisdn) abrirDetalle(fila.msisdn);
    });
    MEUI.registrarTabla(dataTable);
}

function render() {
    MEUI.prepararTabla("#tablaResultados");
    if (!dataTable) construirDataTable();
    const visibles = filas.filter(filaPasaFiltros);
    dataTable.clear();
    dataTable.rows.add(visibles);
    dataTable.draw(false);
    actualizarKPIs();
    actualizarFiltros();
    pintarMenuColumnas();
    MEUI.mostrarSiHayDatos("#tablaResultados", { vacio: "#msgVacio", tabla: dataTable });
    MEUI.resumenPaso(2, filas.length ? `${filas.length} líneas consultadas` : "");
    MEUI.ajustarTablas();
    // Cuántas líneas alcanzaría una operación masiva con los filtros puestos.
    if (typeof actualizarConteoMasivo === "function") actualizarConteoMasivo();
}

/* ---------------------------------------------------------------------
   13 · MODAL DE DETALLE (secciones 21-24)
--------------------------------------------------------------------- */
function filaDe(msisdn) { return filas.find(f => f.msisdn === msisdn); }

function grid(items) {
    if (!items || !items.length) return `<p class="me-hint mb-0">Sin datos en esta categoría.</p>`;
    return `<dl class="dl-grid mb-0">` + items.map(it => `
        <dt title="${MEUI.esc(it.name)}">${MEUI.esc(it.friendly || it.name)}</dt>
        <dd>${MEUI.esc(it.valor === null || it.valor === undefined || it.valor === "" ? "No Registra" : it.valor)}</dd>`
    ).join("") + `</dl>`;
}

function abrirDetalle(msisdn) {
    const f = filaDe(msisdn);
    if (!f) return;
    MEUI.$("#mdMsisdn").textContent = f.msisdn;
    MEUI.$("#mdImsi").textContent = (f.resumen && f.resumen.imsi) || "—";
    MEUI.$("#mdIccid").textContent = (f.resumen && f.resumen.iccid) || "—";

    // Las respuestas inconsistentes SÍ traen detalle parseado: se muestra
    // igual, pero encabezado por el aviso de por qué no es confiable.
    if (f.estadoProceso !== "SUCCESS" && f.estadoProceso !== "INCONSISTENTE") {
        MEUI.$("#mdResumen").innerHTML = `<div class="alert alert-warning mb-0">
            <b>${MEUI.esc(f.estadoProceso)}</b> — ${MEUI.esc(f.detalle || "Sin detalle adicional.")}
            ${f.intentos ? `<div class="me-hint mt-1">Intentos realizados: ${f.intentos}</div>` : ""}
        </div>`;
        MEUI.$("#mdCategorias").innerHTML = "";
        MEUI.$("#mdTecnico").innerHTML = "";
        MEUI.$("#mdJson").textContent = f.raw ? JSON.stringify(f.raw, null, 2) : "(sin respuesta)";
        new bootstrap.Modal("#modalDetalle").show();
        return;
    }

    const bloqueosHTML = (lista, cls) => !lista.length ? "" : `
        <ul class="mb-2">${lista.map(b => `<li><span class="badge-estado ${cls}">${MEUI.esc(b.grupo)}</span>
            ${MEUI.esc(b.etiqueta)} <span class="me-mono text-muted">(${MEUI.esc(b.name)} = ${MEUI.esc(b.valor)})</span></li>`).join("")}</ul>`;

    MEUI.$("#mdResumen").innerHTML = `
        ${(f.inconsistencias || []).length ? `<div class="alert alert-warning py-2 mb-2">
            <b>Respuesta inconsistente — no usar como evidencia sin verificar:</b>
            <ul class="mb-0">${f.inconsistencias.map(t => `<li>${MEUI.esc(t)}</li>`).join("")}</ul>
        </div>` : ""}
        <div class="d-flex flex-wrap gap-3 align-items-center">
            <span class="badge-estado ${f.operationalState === "active" ? "ok" : "off"}">${MEUI.esc((f.operationalState || "—").toUpperCase())}</span>
            <span class="${f.bloqueosActivos.length ? "chip-bloqueo activo" : "chip-bloqueo"}">${MEUI.esc(textoBloqueos(f))}</span>
            ${f.notaUDC ? `<span class="text-danger small">⚠ ${MEUI.esc(f.notaUDC)}</span>` : ""}
        </div>
        ${f.notas.length ? `<div class="me-hint mt-1">${f.notas.map(MEUI.esc).join(" · ")}</div>` : ""}
        <div class="mt-2">
            <div class="fw-bold small mb-1">Bloqueos activos</div>
            ${f.bloqueosActivos.length ? bloqueosHTML(f.bloqueosActivos, "err") : `<p class="me-hint mb-0">Sin bloqueos activos.</p>`}
            ${f.bloqueosHistoricos.length ? `<div class="fw-bold small mt-2 mb-1">Bloqueos históricos</div>${bloqueosHTML(f.bloqueosHistoricos, "warn")}` : ""}
        </div>`;

    MEUI.$("#mdCategorias").innerHTML = ORDEN_CATEGORIAS.filter(c => c !== "otros" || (f.categorias.otros || []).length)
        .map(c => `
        <div class="mb-3">
            <h6 class="fw-bold">${NOMBRES_CATEGORIA[c]} <small class="text-muted fw-normal">(${(f.categorias[c] || []).length})</small></h6>
            ${grid(f.categorias[c])}
        </div>`).join("");

    MEUI.$("#mdTecnico").innerHTML = grid([
        { name: "responseCode", friendly: "Response Code", valor: f.responseCode },
        { name: "messageCode", friendly: "Message Code", valor: f.messageCode },
        { name: "message", friendly: "Message", valor: f.message },
        { name: "legacy", friendly: "Legacy", valor: f.legacy },
        { name: "transactionId", friendly: "Transaction ID", valor: f.transactionId },
        { name: "timestamp", friendly: "Timestamp", valor: f.timestamp },
        { name: "startOperatingDate", friendly: "Start Operating Date", valor: f.startOperatingDate },
        { name: "intentos", friendly: "Intentos realizados", valor: f.intentos },
        { name: "ms", friendly: "Duración (ms)", valor: f.ms }
    ]);

    MEUI.$("#mdJson").textContent = JSON.stringify(f.raw, null, 2);
    // Operaciones de escritura: viven en logica-qdn-operaciones.js, que se
    // carga después de este archivo (de ahí la guarda).
    if (typeof pintarOperacionesLinea === "function") pintarOperacionesLinea(f);
    new bootstrap.Modal("#modalDetalle").show();
}

/* ---------------------------------------------------------------------
   14 · EXPORTACIÓN
--------------------------------------------------------------------- */
const CABECERA_EXPORT = ["MSISDN", "Estado", "IMSI", "IMEI", "5G", "Telefonía", "SMS", "Datos",
    "Roaming", "Bloqueos activos", "Desvío", "APN", "IP", "Portabilidad",
    "Response Code", "Message", "Transaction ID", "Timestamp", "Observaciones"];

function filasExport() {
    const rows = filas.filter(filaPasaFiltros).map(f => [
        f.msisdn, estadoTabla(f), (f.resumen && f.resumen.imsi) || "", (f.resumen && f.resumen.imei) || "",
        (f.resumen && f.resumen.cincoG) || "", (f.resumen && f.resumen.telefonia) || "",
        (f.resumen && f.resumen.sms) || "", (f.resumen && f.resumen.datos) || "",
        (f.resumen && f.resumen.roaming) || "", (f.bloqueosActivos || []).map(b => b.etiqueta).join(" | "),
        (f.resumen && f.resumen.desvio) || "", (f.resumen && f.resumen.apn) || "", (f.resumen && f.resumen.ip) || "",
        (f.resumen && f.resumen.portabilidad) || "", f.responseCode || "", f.message || f.detalle || "",
        f.transactionId || "", f.timestamp || "",
        [].concat(f.inconsistencias || [], f.notaUDC ? [f.notaUDC] : [],
            (f.estadoProceso === "SUCCESS" && !f.bloqueosEvaluados)
                ? ["Sin características de bloqueo en la respuesta: no se pudo evaluar."] : []
        ).join(" | ")
    ]);
    return { head: CABECERA_EXPORT, rows };
}

function filasParaExportar() {
    return filas.filter(filaPasaFiltros).map(f => ({
        msisdn: f.msisdn, estado: estadoTabla(f), resumen: f.resumen,
        bloqueosActivos: f.bloqueosActivos, bloqueosHistoricos: f.bloqueosHistoricos,
        responseCode: f.responseCode, messageCode: f.messageCode, message: f.message,
        transactionId: f.transactionId, timestamp: f.timestamp, raw: f.raw
    }));
}

/* ---------------------------------------------------------------------
   15 · PROBAR CONEXIÓN (paso 1)
--------------------------------------------------------------------- */
async function probarConexionQdn() {
    const btn = MEUI.$("#btnProbarQdn");
    try {
        await gestorQdn.obtener(cfgQdn, true);
        MEUI.toast("Token QDN obtenido correctamente.", "ok");
        MEUI.sesion.set("qdn", { usuario: cfgQdn.client_id, duracion: Math.round((gestorQdn.exp - Date.now()) / 1000) });
    } catch (e) {
        MEUI.toast("No se pudo obtener el token QDN.", "err");
        MEUI.log("✖ " + e.message, "err");
        MEUI.sesion.caida("qdn", e.message);
    } finally {
        if (btn) btn.disabled = false;
    }
}

function sincronizarCfgDesdeCampos() {
    const v = id => { const el = MEUI.$(id); return el ? el.value.trim() : ""; };
    cfgQdn.token_url = v("#cfgTokenUrl") || AMBIENTE_QDN.token_url;
    cfgQdn.client_id = v("#cfgClientId") || AMBIENTE_QDN.client_id;
    cfgQdn.client_secret = MEUI.$("#cfgClientSecret").value || AMBIENTE_QDN.client_secret;
    cfgQdn.base_apigw = v("#cfgBaseApigw") || AMBIENTE_QDN.base_apigw;
    cfgQdn.auth_en_cuerpo = MEUI.$("#cfgAuthEnCuerpo").checked;
}

/* ---------------------------------------------------------------------
   16 · CARGA DE ARCHIVO (Excel / CSV) — sección 4.2-B/C de la HU
--------------------------------------------------------------------- */
function configurarArchivo() {
    const zona = MEUI.$("#dropzone"), input = MEUI.$("#inputArchivo");
    const selHoja = MEUI.$("#selHoja"), selColumna = MEUI.$("#selColumna");
    const info = MEUI.$("#fileInfo"), btnQuitar = MEUI.$("#btnQuitarArchivo");
    let libro = null;

    function limpiar() {
        libro = null; lineasArchivo = null; datosArchivo.clear();
        input.value = "";
        selHoja.innerHTML = '<option value="">— carga un archivo —</option>'; selHoja.disabled = true;
        selColumna.innerHTML = '<option value="">— carga un archivo —</option>'; selColumna.disabled = true;
        info.textContent = ""; btnQuitar.classList.add("d-none");
    }

    function extraerColumna() {
        if (!libro || !selHoja.value || !selColumna.value) { lineasArchivo = null; datosArchivo.clear(); return; }
        const filasHoja = MEUI.filasDeHoja(libro.wb, selHoja.value);
        const valores = filasHoja.map(r => r[selColumna.value]).filter(v => v !== undefined && v !== "");
        lineasArchivo = parseMsisdns(valores.join("\n"));

        // Columnas OPCIONALES para las operaciones de provisión: si el archivo
        // trae imsi / iccid / ki se guardan junto al MSISDN. Sirven cuando el
        // QDN no devuelve el dato (la KI nunca la devuelve).
        datosArchivo.clear();
        const columnasHoja = filasHoja.length ? Object.keys(filasHoja[0]) : [];
        const colImsi = columnaPorNombre(columnasHoja, ["imsi"]);
        const colIccid = columnaPorNombre(columnasHoja, ["iccid", "serialsim", "seriesim"]);
        const colKi = columnaPorNombre(columnasHoja, ["ki"]);
        if (colImsi || colIccid || colKi) {
            filasHoja.forEach(r => {
                const clave = soloDigitos(r[selColumna.value]);
                if (!clave) return;
                datosArchivo.set(clave, {
                    imsi: colImsi ? soloDigitos(r[colImsi]) : "",
                    iccid: colIccid ? soloDigitos(r[colIccid]) : "",
                    ki: colKi ? String(r[colKi] || "").trim() : ""
                });
            });
        }
        const extras = [colImsi && "imsi", colIccid && "iccid", colKi && "ki"].filter(Boolean);

        info.innerHTML = `${filasHoja.length} filas · ${lineasArchivo.lineas.length} MSISDN válidos` +
            (lineasArchivo.invalidas.length ? ` · ${lineasArchivo.invalidas.length} inválidos` : "") +
            (lineasArchivo.duplicados ? ` · ${lineasArchivo.duplicados} duplicados` : "") +
            (extras.length ? ` · columnas para operaciones: ${extras.join(", ")}` : "");
    }

    function pintarColumnas() {
        const filasHoja = MEUI.filasDeHoja(libro.wb, selHoja.value);
        const columnasHoja = filasHoja.length ? Object.keys(filasHoja[0]) : [];
        selColumna.disabled = !columnasHoja.length;
        selColumna.innerHTML = columnasHoja.map(c => `<option value="${MEUI.esc(c)}">${MEUI.esc(c)}</option>`).join("");
        const auto = MEUI.detectarColumna(columnasHoja);
        if (auto) selColumna.value = auto;
        extraerColumna();
    }

    async function procesar(file) {
        try {
            libro = await MEUI.leerLibro(file);
            selHoja.disabled = false;
            selHoja.innerHTML = libro.hojas.map(h => `<option value="${MEUI.esc(h)}">${MEUI.esc(h)}</option>`).join("");
            selHoja.value = libro.hojas[0];
            pintarColumnas();
            btnQuitar.classList.remove("d-none");
            MEUI.log(`Archivo cargado: ${file.name} (${libro.hojas.length} hoja(s)).`, "ok");
        } catch (e) {
            MEUI.toast("No se pudo leer el archivo: " + e.message, "err");
            limpiar();
        }
    }

    zona.addEventListener("click", () => input.click());
    zona.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); input.click(); } });
    ["dragover", "dragenter"].forEach(ev => zona.addEventListener(ev, e => { e.preventDefault(); zona.classList.add("drag"); }));
    ["dragleave", "drop"].forEach(ev => zona.addEventListener(ev, e => { e.preventDefault(); zona.classList.remove("drag"); }));
    zona.addEventListener("drop", e => { if (e.dataTransfer.files[0]) procesar(e.dataTransfer.files[0]); });
    input.addEventListener("change", () => { if (input.files[0]) procesar(input.files[0]); });
    selHoja.addEventListener("change", pintarColumnas);
    selColumna.addEventListener("change", extraerColumna);
    btnQuitar.addEventListener("click", limpiar);
}

/* ---------------------------------------------------------------------
   17 · INICIALIZACIÓN — se ejecuta al cargar el script (el shell ya montó
   el DOM en MEUI.init(), que corre antes en el <script> inline del HTML).
--------------------------------------------------------------------- */
function inicializarQdn() {
    MEUI.$("#cfgTokenUrl").value = AMBIENTE_QDN.token_url;
    MEUI.$("#cfgClientId").value = AMBIENTE_QDN.client_id;
    MEUI.$("#cfgClientSecret").value = AMBIENTE_QDN.client_secret;
    MEUI.$("#cfgBaseApigw").value = AMBIENTE_QDN.base_apigw;
    MEUI.$("#cfgAuthEnCuerpo").checked = AMBIENTE_QDN.auth_en_cuerpo;

    MEUI.$("#btnProbarQdn").addEventListener("click", () => { sincronizarCfgDesdeCampos(); probarConexionQdn(); });
    MEUI.$("#btnConsultar").addEventListener("click", () => { sincronizarCfgDesdeCampos(); consultar(); });
    MEUI.$("#btnLimpiarFiltros").addEventListener("click", limpiarFiltros);
    MEUI.$$(".me-kpi.kpi-click").forEach(k => k.addEventListener("click", () => alternarKpi(k)));

    configurarArchivo();
    render();
}

/* ---------- logica-qdn-operaciones.js ---------- */
/* =====================================================================
   logica-qdn-operaciones.js · Operaciones de provisión sobre la línea
   ---------------------------------------------------------------------
   El validador QDN era de SOLO LECTURA. Aquí se agregan las operaciones
   que ESCRIBEN en la red de Claro: bloqueos, desbloqueos y conciliación.

   Todo sale de `interfaz.py` (consola de líneas), que es la referencia
   viva de estos servicios:

     · endpoint  PATCH {base_apigw}/APIMParOrdeProvision/.../ModifingService
     · payloads  process / action / level / relatedParty / tier / msisdn /
                 imsi / iccid / ki / features
     · reglas    `features` NUNCA viaja como "" (vacío -> " ");
                 el éxito real NO es el HTTP 200, se evalúa el cuerpo.

   Se carga DESPUÉS de logica-qdn.js y reusa lo que ya vive allí:
   `gestorQdn` (mismo OAuth2), `cfgQdn`, `evaluarNegocio()`, `filas`,
   `filaPasaFiltros()`, `consultarConReintentos()`, `ejecutarPool()` y
   `render()`. No duplica ni el token ni el parseo.

   POR QUÉ LA DOBLE CONFIRMACIÓN
   Estas llamadas afectan líneas REALES en PRODUCCIÓN y no se deshacen
   solas. Bloquear y conciliar piden dos pasos (revisar -> "seguro?");
   desbloquear pide uno. En masivo se listan TODAS las líneas antes de
   ejecutar. Cada ejecución queda con el usuario que la hizo en la
   bitácora, el registro y la exportación.
===================================================================== */

/* ---------------------------------------------------------------------
   1 · ENDPOINT Y CONSTANTES (mismos valores que interfaz.py)
--------------------------------------------------------------------- */
const RUTA_MODIFYING = "/APIMParOrdeProvision/MSParOrdeProvision/SVC/Service/RSParOrdeProvision/V1/ModifingService";
const RELATED_PARTY = [{ id: "EXITO", role: "ServiceProvider", name: "MOVIL EXITO" }];
const TIER_OPERACION = "prepaid";
const NIVEL_LOCKALL = "2";
const CONCURRENCIA_OPERACION = 3;   // más bajo que en consulta: son escrituras

/**
 * `features` no admite cadena vacía: el servicio la rechaza. Vacío -> " ".
 * Varios valores se separan con pipe. Misma regla que normalizar_features().
 */
function normalizarFeatures(texto) {
    const partes = String(texto === null || texto === undefined ? "" : texto)
        .split("|").map(p => p.trim()).filter(Boolean);
    return partes.length ? partes.join("|") : " ";
}

/* ---------------------------------------------------------------------
   2 · CATÁLOGO DE OPERACIONES
   ---------------------------------------------------------------------
   `tipo` decide cuánta fricción pide la interfaz:
     bloqueo / conciliacion -> doble confirmación (revisar + "seguro?")
     desbloqueo             -> confirmación simple
   Desactivar roaming es una restricción, así que cuenta como bloqueo.
--------------------------------------------------------------------- */
const OPERACIONES = [
    { id: "lockall", grupo: "Bloqueo total", etiqueta: "Bloqueo TOTAL de la línea", tipo: "bloqueo", proceso: "lockall" },
    { id: "unlockall", grupo: "Bloqueo total", etiqueta: "Desbloqueo TOTAL de la línea", tipo: "desbloqueo", proceso: "unlockall" },

    { id: "blqinccl_on", grupo: "Bloqueos individuales", etiqueta: "Bloquear llamada ENTRANTE", tipo: "bloqueo", proceso: "blqinccl", accion: "activate" },
    { id: "blqinccl_off", grupo: "Bloqueos individuales", etiqueta: "Desbloquear llamada ENTRANTE", tipo: "desbloqueo", proceso: "blqinccl", accion: "deactivate" },
    { id: "blqoutcl_on", grupo: "Bloqueos individuales", etiqueta: "Bloquear llamada SALIENTE", tipo: "bloqueo", proceso: "blqoutcl", accion: "activate" },
    { id: "blqoutcl_off", grupo: "Bloqueos individuales", etiqueta: "Desbloquear llamada SALIENTE", tipo: "desbloqueo", proceso: "blqoutcl", accion: "deactivate" },
    { id: "blqincsms_on", grupo: "Bloqueos individuales", etiqueta: "Bloquear SMS ENTRANTE", tipo: "bloqueo", proceso: "blqincsms", accion: "activate" },
    { id: "blqincsms_off", grupo: "Bloqueos individuales", etiqueta: "Desbloquear SMS ENTRANTE", tipo: "desbloqueo", proceso: "blqincsms", accion: "deactivate" },
    { id: "blqoutsms_on", grupo: "Bloqueos individuales", etiqueta: "Bloquear SMS SALIENTE", tipo: "bloqueo", proceso: "blqoutsms", accion: "activate" },
    { id: "blqoutsms_off", grupo: "Bloqueos individuales", etiqueta: "Desbloquear SMS SALIENTE", tipo: "desbloqueo", proceso: "blqoutsms", accion: "deactivate" },

    // La colección manda features="roaming" en estas dos (no el valor general).
    { id: "roaming_on", grupo: "Roaming", etiqueta: "Activar ROAMING", tipo: "desbloqueo", proceso: "roaming", accion: "activate", features: "roaming" },
    { id: "roaming_off", grupo: "Roaming", etiqueta: "Desactivar ROAMING", tipo: "bloqueo", proceso: "roaming", accion: "deactivate", features: "roaming" },

    { id: "conciliation", grupo: "Procesos", etiqueta: "Conciliación de línea", tipo: "conciliacion", proceso: "conciliation" }
];

const GRUPOS_OPERACION = ["Bloqueo total", "Bloqueos individuales", "Roaming", "Procesos"];
const operacionPorId = id => OPERACIONES.find(o => o.id === id) || null;
const pideDobleConfirmacion = op => op.tipo === "bloqueo" || op.tipo === "conciliacion";

/* ---------------------------------------------------------------------
   3 · DATOS DE LA LÍNEA (IMSI / ICCID / KI) Y DE DÓNDE SALEN
   ---------------------------------------------------------------------
   El PATCH necesita el IMSI; la conciliación además el ICCID. Hay cuatro
   orígenes posibles, y el que se use SIEMPRE se muestra en pantalla para
   que nadie envíe un dato creyendo que lo dijo el HLR:

     1. manual    lo escribió el analista en el modal de la operación
     2. archivo   columna opcional imsi / iccid / ki del Excel o CSV
     3. QDN       lo devolvió la consulta (UDC_PRSSIMCD-imsi, COTA_…-iccid)
     4. derivado  ICCID = 8957 + IMSI (regla del operador; solo si falta)

   Manual gana sobre archivo, y archivo sobre QDN: si alguien se tomó el
   trabajo de escribirlo o cargarlo, no se le sobreescribe en silencio.
   La KI no la devuelve el QDN nunca: o viene del archivo, o se escribe,
   o va vacía (el servicio la acepta así).
--------------------------------------------------------------------- */
const SIN_DATO = new Set(["—", "", "No Registra", null, undefined]);
const PREFIJO_ICCID = "8957";
const LARGO_IMSI = 15;

function valorQdn(f, campo) {
    const v = f && f.resumen ? f.resumen[campo] : null;
    return SIN_DATO.has(v) ? "" : String(v).trim();
}

/** ICCID = 8957 + IMSI (p. ej. 732157001050037 -> 8957732157001050037). */
function iccidDesdeImsi(imsi) {
    const d = String(imsi || "").replace(/\D/g, "");
    return d.length === LARGO_IMSI ? PREFIJO_ICCID + d : "";
}

/** Correcciones escritas a mano en el modal: msisdn -> {imsi, iccid, ki}. */
const datosManuales = new Map();

/**
 * Resuelve los tres campos con su procedencia.
 * Devuelve { imsi:{valor,origen}, iccid:{…}, ki:{…} }.
 */
function datosOperacion(f) {
    const manual = datosManuales.get(f.msisdn) || {};
    const archivo = (typeof datosArchivo !== "undefined" && datosArchivo.get(f.msisdn)) || {};
    const elegir = (campo, origenQdn) => {
        if (manual[campo]) return { valor: manual[campo], origen: "manual" };
        if (archivo[campo]) return { valor: archivo[campo], origen: "archivo" };
        const qdn = origenQdn ? valorQdn(f, campo) : "";
        if (qdn) return { valor: qdn, origen: "QDN" };
        return { valor: "", origen: "" };
    };

    const imsi = elegir("imsi", true);
    const iccid = elegir("iccid", true);
    if (!iccid.valor && imsi.valor) {
        const derivado = iccidDesdeImsi(imsi.valor);
        if (derivado) { iccid.valor = derivado; iccid.origen = "derivado 8957+IMSI"; }
    }
    // La KI no existe en el QDN: solo manual o archivo.
    const ki = elegir("ki", false);

    return { imsi, iccid, ki };
}

/** Compatibilidad con el resto del archivo: solo el valor resuelto. */
function datoLinea(f, campo) {
    const d = datosOperacion(f)[campo];
    return d ? d.valor : "";
}

/** Campos que la operación exige. La KI nunca es obligatoria. */
function camposRequeridos(op) {
    return op && op.proceso === "conciliation" ? ["imsi", "iccid"] : ["imsi"];
}

/**
 * Motivo por el que una línea NO se puede operar ni pidiendo datos, o ""
 * si es operable (aunque haya que completar campos a mano).
 */
function motivoNoOperable(f, op) {
    if (f.estadoProceso !== "SUCCESS" && f.estadoProceso !== "INCONSISTENTE") {
        return "la consulta QDN no devolvió un resultado utilizable";
    }
    if (f.estadoProceso === "INCONSISTENTE") {
        return "la respuesta QDN quedó marcada como inconsistente";
    }
    return "";
}

/** Campos obligatorios que todavía están vacíos para esta línea. */
function faltantesDe(f, op) {
    const datos = datosOperacion(f);
    return camposRequeridos(op).filter(c => !datos[c].valor);
}

/** Cuerpo del PATCH, con la misma forma exacta que arma interfaz.py. */
function payloadOperacion(op, f) {
    const datos = datosOperacion(f);
    const cuerpo = { process: op.proceso };
    if (op.proceso === "lockall") cuerpo.level = NIVEL_LOCKALL;
    if (op.accion) cuerpo.action = op.accion;
    cuerpo.relatedParty = RELATED_PARTY;
    cuerpo.tier = TIER_OPERACION;
    cuerpo.msisdn = f.msisdn;
    cuerpo.imsi = datos.imsi.valor;
    if (op.proceso === "conciliation") {
        cuerpo.iccid = datos.iccid.valor;
        cuerpo.ki = datos.ki.valor;   // vacía si nadie la aportó: el servicio la acepta
    }
    cuerpo.features = normalizarFeatures(op.features || "");
    return cuerpo;
}

/* ---------------------------------------------------------------------
   4 · QUIÉN EJECUTA (para la bitácora)
   ---------------------------------------------------------------------
   El token de QDN es de servicio (client_credentials MOVILEXITO): no
   identifica a nadie. La persona sale de la sesión que dejó el lanzador,
   CM (Keycloak) o SIME.
--------------------------------------------------------------------- */
function usuarioOperador() {
    const nombres = [];
    ["cm", "sime"].forEach(clave => {
        const st = MEUI.sesion.estado(clave);
        if (st && st.usuario) nombres.push(`${st.usuario} (${clave.toUpperCase()})`);
    });
    return nombres.length ? nombres.join(" · ") : "sin sesión identificada";
}

/* ---------------------------------------------------------------------
   5 · BITÁCORA
   ---------------------------------------------------------------------
   Queda EN LA HERRAMIENTA, no en el payload: el servicio de provisión no
   define un campo de nota en ModifingService y no se inventa uno. Se ve
   en el registro y sale en la exportación de operaciones.
--------------------------------------------------------------------- */
const bitacoraOperaciones = [];

function anotarBitacora(entrada) {
    bitacoraOperaciones.push(entrada);
    MEUI.log(
        `${entrada.ok ? "✔" : "✖"} ${entrada.operacion} · ${entrada.msisdn} · ` +
        `HTTP ${entrada.httpStatus} · código ${entrada.codigo === null ? "—" : entrada.codigo}` +
        `${entrada.detalle ? " · " + entrada.detalle : ""} · por ${entrada.usuario}`,
        entrada.ok ? "ok" : "err");
}

const CABECERA_BITACORA = ["Fecha/hora", "Usuario", "MSISDN", "Operación", "process", "action",
    "IMSI", "ICCID", "HTTP", "Resultado", "Código", "Message Code", "Detalle", "Transaction ID"];

function bitacoraExport() {
    return {
        head: CABECERA_BITACORA,
        rows: bitacoraOperaciones.map(b => [
            b.hora, b.usuario, b.msisdn, b.operacion, b.proceso, b.accion || "",
            b.imsi || "", b.iccid || "", b.httpStatus, b.ok ? "OK" : "FALLA",
            b.codigo === null || b.codigo === undefined ? "" : b.codigo,
            b.codigoMsg || "", b.detalle || "", b.transactionId || ""
        ])
    };
}

/* ---------------------------------------------------------------------
   6 · EJECUCIÓN DEL PATCH
--------------------------------------------------------------------- */
function idTransaccion() {
    return (crypto && crypto.randomUUID) ? crypto.randomUUID()
        : String(Date.now()) + Math.floor(Math.random() * 1e6);
}

async function patchUnaVez(url, payload, cfg, token) {
    const controlador = new AbortController();
    const temporizador = setTimeout(() => controlador.abort(), cfg.timeoutMs);
    const transactionId = idTransaccion();
    const t0 = performance.now();
    try {
        const r = await fetch(url, {
            method: "PATCH", signal: controlador.signal,
            headers: {
                "Accept": "application/json",
                "Content-Type": "application/json",
                "Authorization": "Bearer " + token,
                "transactionId": transactionId
            },
            body: JSON.stringify(payload)
        });
        const texto = await r.text();
        let cuerpo = null;
        try { cuerpo = texto ? JSON.parse(texto) : null; } catch (e) { /* no era JSON */ }
        return {
            ok: r.ok, status: r.status, cuerpo, texto, transactionId,
            ms: Math.round(performance.now() - t0)
        };
    } finally {
        clearTimeout(temporizador);
    }
}

/**
 * Ejecuta una operación sobre UNA línea y devuelve el registro de bitácora.
 * El éxito real se lee del cuerpo con `evaluarNegocio()` (logica-qdn.js):
 * un HTTP 200 con `success:false` o `responseCode>=400` es una FALLA.
 */
async function ejecutarOperacion(op, f, cfg) {
    const hora = new Date().toISOString().replace("T", " ").slice(0, 19);
    const usuario = usuarioOperador();
    const datos = datosOperacion(f);
    const base = {
        hora, usuario, msisdn: f.msisdn, operacion: op.etiqueta,
        proceso: op.proceso, accion: op.accion || "",
        imsi: datos.imsi.valor, iccid: datos.iccid.valor,
        origenImsi: datos.imsi.origen, origenIccid: datos.iccid.origen
    };

    const impedimento = motivoNoOperable(f, op)
        || (faltantesDe(f, op).length ? "falta " + faltantesDe(f, op).join(" y ") : "");
    if (impedimento) {
        return Object.assign(base, {
            ok: false, httpStatus: "—", codigo: "no-operable", codigoMsg: "",
            detalle: "No se envió nada: " + impedimento, payload: null, cuerpo: null
        });
    }

    const payload = payloadOperacion(op, f);
    const url = cfg.base_apigw.replace(/\/$/, "") + RUTA_MODIFYING;

    let tokenRenovado = false;
    while (true) {
        let token;
        try {
            token = await gestorQdn.obtener(cfg, tokenRenovado);
        } catch (e) {
            return Object.assign(base, {
                ok: false, httpStatus: "—", codigo: "auth", codigoMsg: "",
                detalle: "No se pudo autenticar: " + (e.message || e), payload, cuerpo: null
            });
        }

        let resp;
        try {
            resp = await patchUnaVez(url, payload, cfg, token);
        } catch (e) {
            const esTimeout = e && e.name === "AbortError";
            return Object.assign(base, {
                ok: false, httpStatus: esTimeout ? "timeout" : "—",
                codigo: esTimeout ? "timeout" : "conn-err", codigoMsg: "",
                // Un timeout NO se reintenta: la operación pudo haberse
                // aplicado y repetirla la duplicaría. Se verifica con el QDN.
                detalle: esTimeout
                    ? "Tiempo de espera agotado. NO se reintenta: verifica con una consulta antes de repetir."
                    : "Error de comunicación: " + (e.message || e),
                payload, cuerpo: null
            });
        }

        // 401/403: el token venció -> se renueva UNA vez y se repite.
        if ((resp.status === 401 || resp.status === 403) && !tokenRenovado) {
            tokenRenovado = true;
            gestorQdn.reset();
            continue;
        }

        const negocio = resp.cuerpo
            ? evaluarNegocio(resp.cuerpo)
            : { ok: resp.ok, codigo: resp.status, codigoMsg: null, detalle: (resp.texto || "").slice(0, 300) };
        if (!resp.ok) negocio.ok = false;

        return Object.assign(base, {
            ok: negocio.ok, httpStatus: resp.status, ms: resp.ms,
            codigo: negocio.codigo, codigoMsg: negocio.codigoMsg,
            detalle: negocio.detalle || "", transactionId: resp.transactionId,
            payload, cuerpo: resp.cuerpo, texto: resp.texto
        });
    }
}

/**
 * Vuelve a consultar el QDN de las líneas tocadas y refresca sus filas.
 * Es el mismo `qdn -> operación -> qdn` de los escenarios de interfaz.py:
 * sin esto la tabla seguiría mostrando el estado ANTERIOR a la operación.
 */
async function reconsultar(msisdns, cfg) {
    await ejecutarPool(msisdns, CONCURRENCIA_OPERACION, async (msisdn) => {
        const i = filas.findIndex(x => x.msisdn === msisdn);
        if (i < 0) return;
        const fresca = await consultarConReintentos(msisdn, cfg);
        filas[i] = Object.assign({}, filas[i], fresca);
    });
    render();
}

/* ---------------------------------------------------------------------
   7 · INTERFAZ · lista de operaciones (misma forma en modal y masivo)
--------------------------------------------------------------------- */
function claseTipo(tipo) {
    return tipo === "bloqueo" ? "err" : tipo === "conciliacion" ? "warn" : "ok";
}

/**
 * `contexto` = "linea" (modal de detalle) o "masivo" (barra de acciones).
 * En "linea" se deshabilita lo que esa línea no puede ejecutar y se explica
 * por qué; en masivo el filtro por línea se hace al confirmar.
 */
function listaOperacionesHTML(contexto, f) {
    return GRUPOS_OPERACION.map(grupo => {
        const ops = OPERACIONES.filter(o => o.grupo === grupo);
        if (!ops.length) return "";
        return `
        <div class="mb-2">
            <div class="fw-bold small text-muted mb-1">${MEUI.esc(grupo)}</div>
            <div class="d-flex flex-wrap gap-2">
                ${ops.map(op => {
                    const impedimento = contexto === "linea" ? motivoNoOperable(f, op) : "";
                    return `<button type="button"
                        class="btn btn-sm btn-me-line btn-operacion"
                        data-op="${MEUI.esc(op.id)}" data-contexto="${contexto}"
                        ${impedimento ? `disabled title="No disponible: ${MEUI.esc(impedimento)}"` : ""}>
                        <span class="badge-estado ${claseTipo(op.tipo)}">${op.tipo === "desbloqueo" ? "↑" : "↓"}</span>
                        ${MEUI.esc(op.etiqueta)}
                    </button>`;
                }).join("")}
            </div>
        </div>`;
    }).join("");
}

/** Bloque de operaciones dentro del modal de detalle de una línea. */
function pintarOperacionesLinea(f) {
    const cont = MEUI.$("#mdOperaciones");
    if (!cont) return;
    const impedimentoGeneral = motivoNoOperable(f, null);
    const datos = datosOperacion(f);
    const dato = (etq, d) => `${etq} <span class="me-mono">${MEUI.esc(d.valor || "—")}</span>` +
        `${d.origen ? ` <small class="text-muted">(${MEUI.esc(d.origen)})</small>` : ""}`;
    cont.innerHTML = `
        <div class="me-hint mb-2">
            Estas operaciones <b>escriben en producción</b> sobre
            <span class="me-mono">${MEUI.esc(f.msisdn)}</span> ·
            ${dato("IMSI", datos.imsi)} · ${dato("ICCID", datos.iccid)}.
            Lo que falte se pide al confirmar y todo se puede corregir ahí.
            Quedan registradas a nombre de <b>${MEUI.esc(usuarioOperador())}</b>.
        </div>
        ${impedimentoGeneral ? `<div class="alert alert-warning py-2 mb-2">
            No se puede operar esta línea: ${MEUI.esc(impedimentoGeneral)}.</div>` : ""}
        ${listaOperacionesHTML("linea", f)}`;
    cont.querySelectorAll("button.btn-operacion").forEach(b => {
        b.addEventListener("click", () => abrirConfirmacion(b.dataset.op, [f.msisdn]));
    });
}

/** Menú de operaciones masivas en la barra de acciones. */
function pintarMenuOperaciones() {
    const ul = MEUI.$("#menuOperaciones");
    if (!ul) return;
    ul.innerHTML = `<li class="px-2 pb-2 me-hint" style="max-width:320px">
            Se aplica a las <b id="opMasivoConteo">0</b> líneas que quedaron
            visibles tras los filtros. Antes de ejecutar se listan todas.
        </li>` + GRUPOS_OPERACION.map(grupo => `
        <li class="px-2 pt-1 fw-bold small text-muted">${MEUI.esc(grupo)}</li>
        ${OPERACIONES.filter(o => o.grupo === grupo).map(op => `
            <li><button type="button" class="dropdown-item btn-operacion small"
                data-op="${MEUI.esc(op.id)}" data-contexto="masivo">
                <span class="badge-estado ${claseTipo(op.tipo)}">${op.tipo === "desbloqueo" ? "↑" : "↓"}</span>
                ${MEUI.esc(op.etiqueta)}</button></li>`).join("")}`).join("");

    ul.querySelectorAll("button.btn-operacion").forEach(b => {
        b.addEventListener("click", () => {
            const visibles = filas.filter(filaPasaFiltros).map(f => f.msisdn);
            abrirConfirmacion(b.dataset.op, visibles);
        });
    });
    actualizarConteoMasivo();
}

function actualizarConteoMasivo() {
    const el = MEUI.$("#opMasivoConteo");
    if (el) el.textContent = filas.filter(filaPasaFiltros).length;
}

/* ---------------------------------------------------------------------
   8 · CONFIRMACIÓN (revisar -> "seguro?") Y EJECUCIÓN
--------------------------------------------------------------------- */
let operacionEnCurso = null;   // { op, objetivo: [filas], bloqueadas: [...] }

function abrirConfirmacion(opId, msisdns) {
    const op = operacionPorId(opId);
    if (!op) return;

    const candidatas = msisdns.map(m => filaDe(m)).filter(Boolean);
    const objetivo = [], bloqueadas = [];
    candidatas.forEach(f => {
        const motivo = motivoNoOperable(f, op);
        if (motivo) bloqueadas.push({ msisdn: f.msisdn, motivo });
        else objetivo.push(f);
    });

    operacionEnCurso = { op, objetivo, bloqueadas };
    const requeridos = camposRequeridos(op);

    MEUI.$("#opTitulo").textContent = op.etiqueta;
    MEUI.$("#opResultado").innerHTML = "";
    MEUI.$("#opPaso2").hidden = true;
    MEUI.$("#opPaso1").hidden = false;

    const muestra = objetivo[0] ? payloadOperacion(op, objetivo[0]) : null;
    MEUI.$("#opCuerpo").innerHTML = `
        <div class="d-flex flex-wrap gap-3 align-items-center mb-2">
            <span class="badge-estado ${claseTipo(op.tipo)}">${MEUI.esc(op.tipo.toUpperCase())}</span>
            <span class="me-mono text-muted">process=${MEUI.esc(op.proceso)}${op.accion ? " · action=" + MEUI.esc(op.accion) : ""}${op.proceso === "lockall" ? " · level=" + NIVEL_LOCKALL : ""}</span>
            <span class="text-muted small">Ejecuta: <b>${MEUI.esc(usuarioOperador())}</b></span>
        </div>

        <div class="alert ${objetivo.length > 1 ? "alert-danger" : "alert-warning"} py-2">
            Se va a ejecutar en <b>PRODUCCIÓN</b> sobre
            <b>${objetivo.length}</b> línea${objetivo.length === 1 ? "" : "s"}.
            Esta acción no se deshace sola.
        </div>

        <div class="fw-bold small mb-1">Líneas afectadas (${objetivo.length})</div>
        <div class="me-hint mb-1">
            Los campos vienen del archivo, de la consulta QDN o derivados
            (<span class="me-mono">ICCID = ${PREFIJO_ICCID} + IMSI</span>).
            Se pueden corregir aquí; el origen de cada valor queda debajo.
        </div>
        ${objetivo.length ? `<div style="max-height:260px;overflow:auto">
            <table class="table table-sm mb-0 tabla-operacion">
                <thead><tr>
                    <th>MSISDN</th><th>Estado</th><th>IMSI</th>
                    ${requeridos.indexOf("iccid") >= 0 ? "<th>ICCID</th><th>KI <small>(opcional)</small></th>" : ""}
                </tr></thead>
                <tbody>${objetivo.map(f => campoLineaHTML(op, f, requeridos)).join("")}</tbody>
            </table></div>`
        : `<div class="alert alert-danger py-2 mb-0">Ninguna línea de la selección se puede operar.</div>`}

        ${bloqueadas.length ? `
            <div class="fw-bold small mt-3 mb-1">Se omiten (${bloqueadas.length})</div>
            <ul class="me-hint mb-0" style="max-height:140px;overflow:auto">
                ${bloqueadas.map(b => `<li><span class="me-mono">${MEUI.esc(b.msisdn)}</span> — ${MEUI.esc(b.motivo)}</li>`).join("")}
            </ul>` : ""}

        <div id="opAvisoFaltantes"></div>

        ${muestra ? `<div class="fw-bold small mt-3 mb-1">Cuerpo que se envía${objetivo.length > 1 ? " (ejemplo de la primera línea)" : ""}</div>
            <pre class="json me-mono mb-0" id="opPayload">${MEUI.esc(JSON.stringify(muestra, null, 2))}</pre>` : ""}`;

    // Cada input escribe en `datosManuales` y revalida en caliente.
    MEUI.$("#opCuerpo").querySelectorAll("input[data-campo]").forEach(inp => {
        inp.addEventListener("input", () => {
            const msisdn = inp.dataset.msisdn, campo = inp.dataset.campo;
            const previo = datosManuales.get(msisdn) || {};
            const limpio = campo === "ki" ? inp.value.trim() : inp.value.replace(/\D/g, "");
            if (limpio) previo[campo] = limpio; else delete previo[campo];
            datosManuales.set(msisdn, previo);
            // Escribir el IMSI vuelve a derivar el ICCID si no lo pusieron a mano.
            if (campo === "imsi") refrescarIccidDerivado(msisdn);
            revalidarConfirmacion();
        });
    });

    MEUI.$("#btnOpVolver").hidden = true;
    MEUI.$("#btnOpSeguro").hidden = true;
    const btn = MEUI.$("#btnOpGuardar");
    btn.hidden = false;
    btn.textContent = pideDobleConfirmacion(op) ? "Guardar" : "Ejecutar";
    btn.className = "btn btn-sm " + (pideDobleConfirmacion(op) ? "btn-warning" : "btn-me");
    revalidarConfirmacion();

    new bootstrap.Modal("#modalOperacion").show();
}

/** Una fila de la tabla de confirmación, con sus inputs y el origen del dato. */
function campoLineaHTML(op, f, requeridos) {
    const datos = datosOperacion(f);
    const celda = campo => {
        const d = datos[campo];
        const obligatorio = requeridos.indexOf(campo) >= 0;
        return `<td>
            <input type="text" inputmode="numeric"
                class="form-control form-control-sm me-mono ${obligatorio && !d.valor ? "is-invalid" : ""}"
                data-msisdn="${MEUI.esc(f.msisdn)}" data-campo="${campo}"
                value="${MEUI.esc(d.valor)}"
                placeholder="${obligatorio ? "obligatorio" : "opcional"}">
            <div class="me-hint">${d.origen ? MEUI.esc(d.origen) : (obligatorio ? "sin dato: escríbelo" : "sin dato")}</div>
        </td>`;
    };
    return `<tr>
        <td class="me-mono align-middle">${MEUI.esc(f.msisdn)}</td>
        <td class="align-middle">${MEUI.esc((f.operationalState || "—").toUpperCase())}</td>
        ${celda("imsi")}
        ${requeridos.indexOf("iccid") >= 0 ? celda("iccid") + celda("ki") : ""}
    </tr>`;
}

/** Al cambiar el IMSI se recalcula el ICCID derivado (no el escrito a mano). */
function refrescarIccidDerivado(msisdn) {
    const inp = MEUI.$(`#opCuerpo input[data-campo="iccid"][data-msisdn="${msisdn}"]`);
    if (!inp) return;
    const manual = datosManuales.get(msisdn) || {};
    if (manual.iccid) return;                       // lo escribieron: no se toca
    const f = filaDe(msisdn);
    if (!f) return;
    const datos = datosOperacion(f);
    inp.value = datos.iccid.valor;
    const pie = inp.parentElement.querySelector(".me-hint");
    if (pie) pie.textContent = datos.iccid.origen || "sin dato: escríbelo";
    inp.classList.toggle("is-invalid", !datos.iccid.valor);
}

/** Habilita o bloquea el botón según falten campos obligatorios. */
function revalidarConfirmacion() {
    if (!operacionEnCurso) return;
    const { op, objetivo } = operacionEnCurso;
    const incompletas = objetivo.filter(f => faltantesDe(f, op).length);

    const aviso = MEUI.$("#opAvisoFaltantes");
    if (aviso) {
        aviso.innerHTML = incompletas.length
            ? `<div class="alert alert-warning py-2 mt-2 mb-0">
                 Faltan datos obligatorios en <b>${incompletas.length}</b> línea(s):
                 ${MEUI.esc(incompletas.slice(0, 8).map(f => f.msisdn).join(", "))}${incompletas.length > 8 ? "…" : ""}.
                 Complétalos arriba para poder continuar.
               </div>`
            : "";
    }

    const payload = MEUI.$("#opPayload");
    if (payload && objetivo.length && !faltantesDe(objetivo[0], op).length) {
        payload.textContent = JSON.stringify(payloadOperacion(op, objetivo[0]), null, 2);
    }

    const btn = MEUI.$("#btnOpGuardar");
    if (btn) btn.disabled = !objetivo.length || incompletas.length > 0;
}

/** Paso 1 -> paso 2 en bloqueo y conciliación; ejecución directa si no. */
function confirmarPaso1() {
    if (!operacionEnCurso) return;
    const { op, objetivo } = operacionEnCurso;
    if (!objetivo.length) return;

    if (objetivo.some(f => faltantesDe(f, op).length)) { revalidarConfirmacion(); return; }
    if (!pideDobleConfirmacion(op)) { correrOperacion(); return; }

    MEUI.$("#opPaso1").hidden = true;
    MEUI.$("#opPaso2").hidden = false;
    MEUI.$("#btnOpGuardar").hidden = true;
    MEUI.$("#btnOpVolver").hidden = false;
    MEUI.$("#btnOpSeguro").hidden = false;
    MEUI.$("#opSeguroTexto").innerHTML =
        `¿Seguro? Vas a <b>${MEUI.esc(op.etiqueta.toLowerCase())}</b> en producción sobre ` +
        `<b>${objetivo.length}</b> línea${objetivo.length === 1 ? "" : "s"}` +
        `${objetivo.length === 1 ? ` (<span class="me-mono">${MEUI.esc(objetivo[0].msisdn)}</span>)` : ""}. ` +
        `Queda registrado a nombre de <b>${MEUI.esc(usuarioOperador())}</b>.`;
}

function volverPaso1() {
    MEUI.$("#opPaso2").hidden = true;
    MEUI.$("#opPaso1").hidden = false;
    MEUI.$("#btnOpSeguro").hidden = true;
    MEUI.$("#btnOpVolver").hidden = true;
    MEUI.$("#btnOpGuardar").hidden = false;
}

async function correrOperacion() {
    if (!operacionEnCurso) return;
    const { op, objetivo } = operacionEnCurso;
    const cfg = cfgQdn;

    MEUI.$("#opPaso1").hidden = true;
    MEUI.$("#opPaso2").hidden = true;
    MEUI.$("#btnOpGuardar").hidden = true;
    MEUI.$("#btnOpVolver").hidden = true;
    MEUI.$("#btnOpSeguro").hidden = true;
    const salida = MEUI.$("#opResultado");
    salida.innerHTML = `<div class="me-hint">Ejecutando <b>${MEUI.esc(op.etiqueta)}</b> sobre ${objetivo.length} línea(s)…</div>`;

    MEUI.log(`▶ ${op.etiqueta} sobre ${objetivo.length} línea(s) · ejecuta ${usuarioOperador()}`, "warn");

    const resultados = [];
    await ejecutarPool(objetivo, CONCURRENCIA_OPERACION, async (f) => {
        const r = await ejecutarOperacion(op, f, cfg);
        anotarBitacora(r);
        resultados.push(r);
        salida.innerHTML = `<div class="me-hint">Ejecutando… ${resultados.length} / ${objetivo.length}</div>`;
    });
    resultados.sort((a, b) => objetivo.findIndex(f => f.msisdn === a.msisdn) - objetivo.findIndex(f => f.msisdn === b.msisdn));

    const ok = resultados.filter(r => r.ok).length;
    salida.innerHTML = `
        <div class="alert ${ok === resultados.length ? "alert-success" : "alert-warning"} py-2">
            <b>${ok} de ${resultados.length}</b> operación(es) con resultado exitoso.
            ${ok === resultados.length ? "" : "Revisa el detalle: un HTTP 200 con error en el cuerpo cuenta como falla."}
        </div>
        <div style="max-height:260px;overflow:auto">
        <table class="table table-sm table-striped mb-0">
            <thead><tr><th>MSISDN</th><th>Resultado</th><th>HTTP</th><th>Código</th><th>Detalle</th></tr></thead>
            <tbody>${resultados.map(r => `<tr>
                <td class="me-mono">${MEUI.esc(r.msisdn)}</td>
                <td><span class="badge-estado ${r.ok ? "ok" : "err"}">${r.ok ? "OK" : "FALLA"}</span></td>
                <td class="me-mono">${MEUI.esc(String(r.httpStatus))}</td>
                <td class="me-mono">${MEUI.esc(String(r.codigo === null || r.codigo === undefined ? "—" : r.codigo))}</td>
                <td>${MEUI.esc([r.codigoMsg, r.detalle].filter(Boolean).join(" · ") || "—")}</td>
            </tr>`).join("")}</tbody>
        </table></div>
        <div class="me-hint mt-2">Verificando el estado real con una consulta QDN…</div>`;

    MEUI.toast(`${op.etiqueta}: ${ok}/${resultados.length} con éxito.`, ok === resultados.length ? "ok" : "warn");

    // Verificación: la tabla debe reflejar el estado DESPUÉS de la operación.
    await reconsultar(objetivo.map(f => f.msisdn), cfg);
    salida.insertAdjacentHTML("beforeend",
        `<div class="me-hint">Consulta de verificación terminada: la tabla ya muestra el estado actual.</div>`);
    operacionEnCurso = null;
}

/* ---------------------------------------------------------------------
   9 · INICIALIZACIÓN
--------------------------------------------------------------------- */
function inicializarOperaciones() {
    const guardar = MEUI.$("#btnOpGuardar");
    const seguro = MEUI.$("#btnOpSeguro");
    const volver = MEUI.$("#btnOpVolver");
    if (guardar) guardar.addEventListener("click", confirmarPaso1);
    if (seguro) seguro.addEventListener("click", correrOperacion);
    if (volver) volver.addEventListener("click", volverPaso1);

    const bitacora = MEUI.$("#btnBitacora");
    if (bitacora) bitacora.addEventListener("click", () => {
        if (!bitacoraOperaciones.length) { MEUI.toast("Todavía no se ha ejecutado ninguna operación.", "warn"); return; }
        const { head, rows } = bitacoraExport();
        MEUI.exportarCSV(head, rows, "bitacora_operaciones");
    });

    pintarMenuOperaciones();
}

// Diferido hasta que la pestaña "Claro" se monte de verdad (ver
// me-hlr-hss-puente.js) — misma razon que en los otros dos motores.
window.MotorClaro = {
    iniciar: function () { inicializarQdn(); inicializarOperaciones(); },
    reiniciar: function () { dataTable = null; }
};
})();
