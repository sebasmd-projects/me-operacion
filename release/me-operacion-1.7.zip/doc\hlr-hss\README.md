# HLR/HSS · Claro y Tigo — Documentación técnica

> **Versión: v1.0** · Convención de versionado: *fix* `+0.1` · *feature* `+1.0`.
> Base compartida: ver `doc/lanzador/README.md`.

Junta en **una sola página con pestañas** lo que antes eran **tres herramientas separadas**:

| Pestaña | Reemplaza a | Qué hace |
| --- | --- | --- |
| **Tigo** | Consulta QDN · Tigo | Consulta el HLR/HSS de Tigo por autogestión. Solo lectura. |
| **Claro** | Validador QDN · Claro | Consulta el QDN de Claro y **opera la línea** (bloqueo/desbloqueo/conciliación), con doble confirmación. Escribe en producción. |
| **Ambos** | ¿En qué HLR está? | Consulta Claro y Tigo **en paralelo** y concluye en cuál de las dos redes está la línea. Solo lectura. |

Cada pestaña es **la misma herramienta de antes, sin cambios de lógica** — ver «Por qué» más abajo. El detalle forense completo de cada operador (catálogo de RETCODE, interpretación de bloqueos, heurísticas del perfil HLR, reglas de las operaciones de escritura) sigue viviendo en la documentación original de cada uno, enlazada al final de este documento.

---

## Por qué se fusionaron

Las tres herramientas consultaban cosas relacionadas (HLR/HSS por operador) pero vivían en pestañas del menú distintas, obligando a abrir una, anotar, cerrar, abrir la siguiente. Juntarlas bajo un solo punto de entrada con pestañas internas reduce ese salto sin tocar ninguna regla de negocio ya probada en producción.

**Cómo se hizo, con el mínimo riesgo posible:**

1. Cada motor (`logica-qdn.js`, `logica-qdn-tigo.js`, `logica-hlr-cruzado.js`, y `logica-qdn-operaciones.js` para las operaciones de escritura de Claro) se copió **tal cual, sin tocar una sola línea de sus reglas de negocio**, envuelto en su propio `(function(){ ... })()`.
2. El envoltorio es necesario porque los tres motores declaran los mismos nombres de nivel superior (`filas`, `render`, `consultar`, `dataTable`, `ejecutarPool`...) — al vivir antes en páginas separadas nunca chocaban; en una sola página sí lo harían.
3. `logica-qdn.js` y `logica-qdn-operaciones.js` (Claro) van en un **mismo IIFE compartido**, no en dos separados: `logica-qdn-operaciones.js` referencia variables de `logica-qdn.js` por nombre suelto (`gestorQdn`, `cfgQdn`, `filas`, `render`, etc.), exactamente como cuando eran dos `<script>` de una misma página. Un cierre compartido preserva ese acople intacto.
4. El marcado (KPIs, pasos, tabla, modal) de cada herramienta original se copió, también tal cual, dentro de un `<template>` propio. Un `<template>` no forma parte del DOM activo, así que los tres pueden convivir en el archivo sin que sus ids choquen.
5. Al cambiar de pestaña, `me-hlr-hss-puente.js` **desmonta por completo** la pestaña anterior antes de montar la siguiente — nunca hay más de un `<template>` clonado en el documento a la vez. Es necesario porque los tres motores comparten ids (`#tablaResultados`, `#inputLineas`, `#modalDetalle`...); tenerlos montados a la vez duplicaría esos ids y solo el primero respondería.

**Verificación de fidelidad**: el contenido de cada motor envuelto se comparó línea por línea (`diff`) contra el archivo original antes de esta fusión — la única diferencia son los comentarios nuevos explicando el envoltorio.

---

## Arquitectura y archivos

| Archivo | Qué contiene |
| --- | --- |
| `herramientas/hlr_hss.html` | Solo marcado: pestañas, y un `<template>` por operador con el marcado original de esa herramienta. |
| `assets/logica-hlr-hss-tigo.js` | Motor Tigo = copia envuelta de `logica-qdn-tigo.js`. |
| `assets/logica-hlr-hss-claro.js` | Motor Claro = copia envuelta de `logica-qdn.js` + `logica-qdn-operaciones.js` (mismo IIFE). |
| `assets/logica-hlr-hss-ambos.js` | Motor Ambos = copia envuelta de `logica-hlr-cruzado.js`. |
| `assets/me-hlr-hss-puente.js` | Interruptor de pestañas: monta/desmonta el `<template>` activo y llama a `MotorX.iniciar()` (y `MotorX.reiniciar()` si ya se había visitado esa pestaña, para no reusar un `DataTable` apuntando a una tabla ya desmontada). |
| `assets/me-ui.js` / `me-ui.css` | Shell, tablas y exportación. **Común.** |

Cada motor expone un objeto global mínimo:

```js
window.MotorTigo  = { iniciar, reiniciar };
window.MotorClaro = { iniciar, reiniciar };   // iniciar() llama a inicializarQdn() + inicializarOperaciones()
window.MotorAmbos = { iniciar, reiniciar };
```

`iniciar()` es exactamente la función que antes se auto-ejecutaba sola al cargar el script (`inicializarQdn();` / `inicializarTigo();` / `inicializarCruce();`); aquí se difiere hasta que esa pestaña se monta de verdad en el DOM, porque antes de eso `MEUI.$("#tablaResultados")` y compañía no encontrarían nada.

---

## Cambiar de pestaña reinicia esa consulta

Al volver a Tigo después de haber estado en Claro, la pestaña Tigo **empieza vacía otra vez** — no se guardan los resultados de una pestaña mientras se está en otra. Es consecuencia directa de desmontar/remontar el `<template>`: cada motor mantiene su tabla y sus filas en variables privadas de su propio cierre, y esas variables no sobreviven a que su `<table>` se haya ido del documento.

Si esto resulta molesto en el uso diario, la mejora natural sería que cada motor exponga también un `guardarEstado()`/`restaurarEstado()` — no se hizo en esta primera versión para no tocar más de lo necesario la lógica ya probada.

---

## Riesgos y límites

- **Claro escribe en producción.** El motor Claro incluye bloqueo, desbloqueo y conciliación de línea, con doble confirmación — igual que antes de la fusión. No cambió nada de esa lógica ni de sus validaciones.
- **Un solo `<template>` montado a la vez.** Es la pieza que hace posible la fusión sin renombrar ids; si algún día se quisiera ver dos pestañas simultáneamente (por ejemplo, para comparar), habría que namespacing real de ids, que sí toca la lógica de cada motor.
- **Los archivos originales siguen en el repositorio** (`validador_qdn.html`, `logica-qdn.js`, `logica-qdn-operaciones.js`, `me-qdn-puente.js`, `validador_qdn_tigo.html`, `logica-qdn-tigo.js`, `me-qdn-tigo-puente.js`, `validador_hlr_cruzado.html`, `logica-hlr-cruzado.js`, `me-hlr-cruzado-puente.js`), pero **ya no están en el menú ni en la portada**: quedaron ahí a propósito, como respaldo, hasta confirmar que `hlr_hss.html` funciona igual en un equipo real. Una vez confirmado, se pueden borrar (avísalo para hacerlo).
- **Distribución**: igual que las demás herramientas de esta suite — se descargan y ejecutan localmente en los PC administrados, no se publican en un servidor.

---

## Documentación de cada motor (detalle forense completo)

Estos tres documentos **no se duplicaron aquí**: siguen siendo la referencia técnica completa de cada motor (catálogo de RETCODE, interpretación de bloqueos, heurísticas del perfil HLR, reglas de las operaciones de escritura de Claro). Este README solo documenta la fusión; para las reglas de negocio de cada pestaña, ir a:

- **[doc/consulta-qdn-tigo/README.md](../consulta-qdn-tigo/README.md)** — pestaña Tigo.
- **[doc/validador-qdn/README.md](../validador-qdn/README.md)** — pestaña Claro, incluidas las operaciones de escritura.
- **[doc/hlr-cruzado/README.md](../hlr-cruzado/README.md)** — pestaña Ambos.

---

## Historial de cambios

| Versión | Cambios |
|---|---|
| **1.0** | Primera versión: fusiona Validador QDN · Claro, Consulta QDN · Tigo y ¿En qué HLR está? en una sola herramienta con pestañas, reusando los tres motores sin cambios de lógica. |
