/* =====================================================================
   me-hlr-hss-puente.js · Interruptor de pestañas de hlr_hss.html
   ---------------------------------------------------------------------
   No es un puente como los demás (no conecta UNA lógica con el shell):
   conecta TRES motores independientes (logica-hlr-hss-tigo.js, -claro.js,
   -ambos.js) con un único documento, montando y desmontando el
   <template> de la pestaña activa.

   Por qué desmontar y no solo ocultar con CSS: los tres motores fueron
   escritos como páginas independientes y comparten (por diseño, de
   antes de esta fusión) los mismos ids -#tablaResultados, #inputLineas,
   #modalDetalle, #logConexion...-. Si dos pestañas estuvieran montadas a
   la vez (aunque una estuviera oculta con `hidden`), habría DOS
   elementos con el mismo id en el documento, y `MEUI.$("#id")` /
   `document.getElementById` solo encuentran el primero: la pestaña
   "de atrás" quedaría rota. Por eso solo la pestaña activa vive en el
   DOM en cada momento.

   Va SIEMPRE al final del <body>, después de los tres motores:

       <script src="assets/logica-hlr-hss-tigo.js"></script>
       <script src="assets/logica-hlr-hss-claro.js"></script>
       <script src="assets/logica-hlr-hss-ambos.js"></script>
       <script src="assets/me-hlr-hss-puente.js"></script>
===================================================================== */
(function () {
    "use strict";

    const MOTORES = {
        tigo: { template: "panelTigo", motor: () => window.MotorTigo, etiqueta: "Tigo" },
        claro: { template: "panelClaro", motor: () => window.MotorClaro, etiqueta: "Claro" },
        ambos: { template: "panelAmbos", motor: () => window.MotorAmbos, etiqueta: "Ambos" }
    };

    const montado = document.getElementById("panelMontado");
    let actual = null;

    function montar(clave) {
        const cfg = MOTORES[clave];
        if (!cfg) return;
        if (actual === clave) return;   // ya está esta pestaña activa

        // Se desmonta TODO lo anterior antes de montar lo nuevo (ver el
        // porqué en el encabezado del archivo).
        montado.innerHTML = "";

        const tpl = document.getElementById(cfg.template);
        if (!tpl) {
            MEUI.log(`No se encontró la plantilla "${cfg.template}" para la pestaña ${cfg.etiqueta}.`, "err");
            return;
        }
        montado.appendChild(tpl.content.cloneNode(true));

        document.querySelectorAll("[data-tab]").forEach(b => {
            const activa = b.dataset.tab === clave;
            b.classList.toggle("activa", activa);
            b.setAttribute("aria-selected", activa ? "true" : "false");
        });
        actual = clave;

        // MEUI.montarPasos() (el plegado de las secciones [data-me-paso])
        // solo corre una vez, dentro de MEUI.init(); el marcado que se
        // acaba de clonar no ha pasado por ahí todavía. Se repite aquí
        // para esta tanda de elementos nuevos -montarPasos() ya se
        // encarga de no tocar dos veces lo que ya estaba montado.
        MEUI.montarPasos();
        MEUI.aplicarAperturaPasos();

        const motor = cfg.motor();
        if (!motor || typeof motor.iniciar !== "function") {
            MEUI.log(`No se pudo iniciar el motor "${cfg.etiqueta}": revisa que su script haya cargado sin errores (ver más arriba en este registro).`, "err");
            MEUI.toast(`La pestaña ${cfg.etiqueta} no cargó. Mira el registro.`, "err");
            return;
        }
        try {
            // reiniciar() limpia el dataTable de la visita anterior a esta
            // MISMA pestaña (si la hubo): sin esto, construirDataTable()
            // vería su variable ya asignada y no crearía una tabla nueva
            // sobre el <table> recién clonado, que quedaría en blanco.
            if (typeof motor.reiniciar === "function") motor.reiniciar();
            motor.iniciar();
            MEUI.log(`Pestaña "${cfg.etiqueta}" lista.`, "ok");
        } catch (e) {
            MEUI.log(`Error iniciando la pestaña "${cfg.etiqueta}": ${e.message}`, "err");
            MEUI.toast(`No se pudo iniciar la pestaña ${cfg.etiqueta}. Mira el registro.`, "err");
        }
        setTimeout(MEUI.ajustarTablas, 250);
    }

    document.querySelectorAll("[data-tab]").forEach(b =>
        b.addEventListener("click", () => montar(b.dataset.tab)));

    // Arranca en "Tigo": es la pestaña de solo lectura y menor riesgo -no
    // tiene sentido que el primer vistazo a la herramienta aterrice en
    // Claro, que trae operaciones de escritura sobre la línea.
    montar("tigo");
})();
